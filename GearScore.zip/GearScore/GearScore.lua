

-------------------------------------------------------------------------------
--                              GearScore                                    --
--                            Version 3.1.20                                --
--								Mirrikat45                                   --
-------------------------------------------------------------------------------

-- Fixed a bug with the CharactherStat pane not loading correctly.
-- Added Spirit to list of approved stats for Paladins - The spec checking should still be ignored.
-- Added a check which will cause the addon to fail to load when Cataclysm is released.

------------------------------------------------------------------------------
function GearScore_OnUpdate(self, elapsed)
--Code use to Function Timing of Transmition Information--
	if not GSX_Timer then GSX_Timer = 0; end
	GSX_Timer = GSX_Timer + elapsed
	if GSX_Timer >= 0.5 then
		GSX_Timer = 0
		self:Hide()
  		GearScore_ContinueExchange()
	end
end

function GearScore_ThrottleUpdate(self, elapsed)
--Code use to Function Timing of Transmition Information--
	if not GS_ThrottleTimer then GS_ThrottleTimer = 0; end
	GS_ThrottleTimer = GS_ThrottleTimer + elapsed
	if GS_ThrottleTimer >= 1 then
	    GearScoreChatMessageThrottle = 0
		GS_ThrottleTimer = 0
	end
end

function GearScore_OnEvent(GS_Nil, GS_EventName, GS_Prefix, GS_AddonMessage, GS_Whisper, GS_Sender)
	if ( GS_EventName == "PLAYER_REGEN_ENABLED" ) then GS_PlayerIsInCombat = false; return; end
	if ( GS_EventName == "PLAYER_REGEN_DISABLED" ) then GS_PlayerIsInCombat = true; return; end
	if ( GS_EventName == "EQUIPMENT_SWAP_PENDING" ) then GS_PlayerIsSwitchingGear = true; GS_PlayerSwappedGear = 0 return; end
	if ( GS_EventName == "EQUIPMENT_SWAP_FINISHED" ) then
    	GearScore_GetScore(UnitName("player"), "player");
		GearScore_Send(UnitName("player"), "ALL")
		local Red, Blue, Green = GearScore_GetQuality(GS_Data[GetRealmName()].Players[UnitName("player")].GearScore)
    	PersonalGearScore:SetText(GS_Data[GetRealmName()].Players[UnitName("player")].GearScore); PersonalGearScore:SetTextColor(Red, Green, Blue, 1)
        GS_PlayerIsSwitchingGear = nil;
	return
	end

	if ( GS_EventName == "CHAT_MSG_CHANNEL" ) then
	    local Who = GS_AddonMessage; local Message = GS_Prefix; local ExtraMessage = ""; local ColorClass = ""; local Channel = GS_Sender
	    if GS_Data[GetRealmName()].Players[Who] then
            ColorClass = "|cff"..string.format("%02x%02x%02x", GS_ClassInfo[GS_Classes[GS_Data[GetRealmName()].Players[Who].Class]].Red * 255, GS_ClassInfo[GS_Classes[GS_Data[GetRealmName()].Players[Who].Class]].Green * 255, GS_ClassInfo[GS_Classes[GS_Data[GetRealmName()].Players[Who].Class]].Blue * 255)
			local Red, Green, Blue = GearScore_GetQuality(GS_Data[GetRealmName()].Players[Who].GearScore)
			local ColorGearScore = "|cff"..string.format("%02x%02x%02x", Red * 255, Blue * 255, Green * 255)
            ExtraMessage = "("..ColorGearScore..tostring(GS_Data[GetRealmName()].Players[Who].GearScore).."|r)" ;

		end

		if string.find(Channel, "Trade") then
		    --print("StringFound!")
			local A, B = string.find(Channel, "Trade"); Channel = string.sub(Channel, 1, B)
		end
		Channel = "["..Channel.."] "

	    local NewMessage = Channel..ExtraMessage.."|Hplayer:"..Who.."|h["..ColorClass..Who.."|r]|h: "..Message
	    --print(NewMessage)

	end

	if ( GS_EventName == "PLAYER_EQUIPMENT_CHANGED" ) then
		
	    if ( GS_PlayerIsSwitchingGear == true ) then GS_PlayerSwappedGear = GS_PlayerSwappedGear + 1 return; end
	    if ( GS_PlayerSwappedGear ) then GS_PlayerSwappedGear = GS_PlayerSwappedGear - 1; if ( GS_PlayerSwappedGear == 0 ) then GS_PlayerSwappedGear = nil; end; return; end
	    GearScore_GetScore(UnitName("player"), "player");
		GearScore_RequestSelfServerItemData(1)
		--GearScore_Send(UnitName("player"), "ALL")
		local Red, Blue, Green = GearScore_GetQuality(GS_Data[GetRealmName()].Players[UnitName("player")].GearScore)
    	PersonalGearScore:SetText(GS_Data[GetRealmName()].Players[UnitName("player")].GearScore); PersonalGearScore:SetTextColor(Red, Green, Blue, 1)
  	end
	if ( GS_EventName == "PLAYER_TARGET_CHANGED" ) then
		if UnitName("target") then 	GS_Data[GetRealmName()]["CurrentPlayer"] = {}; end
		if UnitName("target") and UnitIsPlayer("target") then
			GearScore_RequestServerItemData(UnitName("target"))
		end
		if ( GS_DisplayFrame:IsVisible() ) then
			if UnitName("target") then  
				if CanInspect("target") then NotifyInspect("target"); end
				GearScore_RequestOrScan(UnitName("target"), "target")
				--ClearAchievementComparisonUnit(); SetAchievementComparisonUnit("target")				
				--GearScore_DisplayUnit(UnitName("target"), 1); 
				
				GS_SCANSET(UnitName("target"));
			end			
		end
			GS_Data["CurrentTarget"] = {}
			for i = 1, 18 do
				GS_Data["CurrentTarget"][i] = GetInventoryItemLink("target", i)
			end		
	end
	if ( GS_EventName == "CHAT_MSG_ADDON" ) then
			if ( GS_Prefix == GS_ServerItemReplyPrefix ) and ( GS_Whisper == "WHISPER" ) then
				GearScore_HandleServerItemReply(GS_AddonMessage, GS_Sender)
				return
			end
			if not (GS_Whisper == "GUILD") then return; end
			if GS_Settings["BlackList"] then if GS_Settings["BlackList"][GS_Sender] then return; end; end
	    if not ( GearScoreChatMessageThrottle ) then GearScoreChatMessageThrottle = 0; end
        GearScoreChatMessageThrottle = GearScoreChatMessageThrottle + 1
		if not ( GSMega ) then GSMega = 1; end
		if ( GS_Prefix == "GSY_Version" ) and ( tonumber(GS_AddonMessage) ) and ( GS_Settings["OldVer"] ) then
			if ( tonumber(GS_AddonMessage) > GS_Settings["OldVer"] ) then print("There is a newer version of GearScore. Go to www.GearScoreAddon.com to update."); GS_Settings["OldVer"] = tonumber(GS_AddonMessage); end
		end
		if ( GS_Prefix == "GSY_Request" ) and ( GS_Settings["Communication"] == 1 ) and ( GS_Sender ~= UnitName("player") ) then
				if not ( GearScoreChatMessageThrottle ) then GearScoreChatMessageThrottle = 0; end
			    if ( GearScoreChatMessageThrottle >= 1 ) then return; end
				if ( GS_Data[GetRealmName()].Players[GS_AddonMessage] ) then GearScore_Send(GS_AddonMessage, "GUILD", GS_Sender); end
		end
		if ( GS_Prefix == "GSY" ) and ( GS_Settings["Communication"] == 1 ) and ( GS_Sender ~= UnitName("player") ) then
			if ( GS_Whisper == "RAID" ) then GS_Whisper = "PARTY"; end
			local tbl = {}
			for v in string.gmatch(GS_AddonMessage, "[^$]+") do
 				tinsert(tbl, v)
			end
			if ( tbl[1] == UnitName("player") ) or (( tbl[11] ~= GS_Sender ) and ( tbl[11] ~= " ") ) then return; end
			if ( tbl[1] ) and ( tbl[2] ) and ( tbl[3] ) then
				--IF No GearScore Record was Found
				if not ( GS_Data[GetRealmName()].Players[tbl[1]] ) then
					local TestAuthenticity = GearScore_ComposeRecord(tbl, GS_Sender)
					if TestAuthenticity then return end
					if ( UnitName("mouseover") == tbl[1] ) then GameTooltip:SetUnit(tbl[1]); end
					if ( GS_DisplayPlayer == tbl[1] ) and ( GS_DisplayFrame:IsVisible() ) then GearScore_DisplayUnit(tbl[1], 1); end
					if ( ( GS_Factions[GS_Data[GetRealmName()].Players[tbl[1]].Faction] ~= UnitFactionGroup("player") ) and ( GS_Settings["KeepFaction"] == -1 ) ) or ( ( GS_Data[GetRealmName()].Players[tbl[1]].Level < GS_Settings["MinLevel"] ) and ( tbl[1] ~= UnitName("player") ) ) then GS_Data[GetRealmName()].Players[tbl[1]] = nil; end
					if ( (type(tonumber(tbl[10]))) == "number" ) then GS_Data[GetRealmName()].Players[tbl[1]] = nil; end
					return
				end

				--If GearScore Record Needs Updating
				--if  ( tonumber(GS_Data[GetRealmName()].Players[tbl[1]].GearScore) ~= tonumber(tbl[2]) ) or ( tonumber(GS_Data[GetRealmName()].Players[tbl[1]].Date) ~= tonumber(tbl[3]) ) then
				if not ( tonumber(GS_Data[GetRealmName()].Players[tbl[1]].Date) >= tonumber(tbl[3]) ) then
					if ( tonumber(tbl[3]) > GearScore_GetTimeStamp() ) then return; end
				--not ( GS_Data[GetRealmName()].Players[tbl[1]].Date > tonumber(tbl[3]) ) then
					local PreviousRecord = GS_Data[GetRealmName()].Players[tbl[1]]
					local TestAuthenticity = GearScore_ComposeRecord(tbl, GS_Sender)
					if TestAuthenticity then return end
					local CurrentRecord = GS_Data[GetRealmName()].Players[tbl[1]]
					if ( GS_DisplayPlayer == tbl[1] ) and ( GS_DisplayFrame:IsVisible() ) then GearScore_DisplayUnit(tbl[1], 1); end
                    if ( ( GS_Factions[GS_Data[GetRealmName()].Players[tbl[1]].Faction] ~= UnitFactionGroup("player") ) and ( GS_Settings["KeepFaction"] == -1 ) ) or ( ( GS_Data[GetRealmName()].Players[tbl[1]].Level < GS_Settings["MinLevel"] ) and ( tbl[1] ~= UnitName("player") ) ) then GS_Data[GetRealmName()].Players[tbl[1]] = nil; end
					if ( (type(tonumber(tbl[10]))) == "number" ) then GS_Data[GetRealmName()].Players[tbl[1]] = nil; end
					return
				end
			end
        end
	end


	if ( GS_EventName == "ADDON_LOADED" ) then
		if ( GS_Prefix == "GearScore" ) then
      		if not ( GS_Settings ) then	GS_Settings = GS_DefaultSettings; GS_Talent = {}; GS_TimeStamp = {}; end
			GS_PVP = {}; GS_EquipTBL = {}; GS_Bonuses = {}; GS_Timer = {}; GS_Request = {}; GS_Average = {}
			if not ( GS_Data ) then GS_Data = {}; end; if not ( GS_Data[GetRealmName()] ) then GS_Data[GetRealmName()] = { ["Players"] = {} }; end
  			GS_Settings["Developer"] = 0; GS_VersionNum = 30119; GS_Settings["OldVer"] = GS_VersionNum
  			for i, v in pairs(GS_DefaultSettings) do if not ( GS_Settings[i] ) then GS_Settings[i] = GS_DefaultSettings[i]; end; end
  			if ( GS_Settings["AutoPrune"] == 1 ) then GearScore_Prune(); end
			if ( GS_Settings["Developer"] == 0 ) then print("Welcome to GearScore 3.1.20. Type /gs to visit options and turn off help."); end
			print("|cffFF1E00GearScore:|r There is currently a bug in which the UI will stop responding to inspection requests. This is not a bug caused by GearScore, but is a bug in the client. Blizzard is aware of the bug and a fix should be implimented shortly.");
			if ( GS_Settings["Developer"] == 1 ) then print("Welcome to GearScore 3.1.20. This is a test version. Please provide feedback at www.GearScoreAddon.com"); end
  			if ( GS_Settings["Restrict"] == 1 ) then GearScore_SetNone(); end
  			if ( GS_Settings["Restrict"] == 2 ) then GearScore_SetLight(); end
  			if ( GS_Settings["Restrict"] == 3 ) then GearScore_SetHeavy(); end
  			if ( GetGuildInfo("player") ) then GuildRoster(); end
  			GearScore_GetScore(UnitName("player"), "player"); GearScore_RequestSelfServerItemData(1); GearScore_Send(UnitName("player"), "ALL")
       	  	if ( GetGuildInfo("player") ) and ( GS_Settings["Developer"] ~= 1 )then SendAddonMessage( "GSY_Version", GS_Settings["OldVer"], "GUILD"); end
--       	  	if ( GetBuildInfo() == "4.0.3") then 
--       	  		print("ERROR: This version of GearScore is incompatible with Cataclysm. Please update at www.GearScoreAddon.com"); 
--       	  		GS_DisplayFrame = nil;
--       	  		GS_Settings = nil;
--       	  		GS_Database = nil;
--       	  	end;
        end
        if ( GS_Prefix == "GearScoreRecount" ) then
            local f = CreateFrame("Frame", "GearScoreRecountErrorFrame", UIParent);
            f:CreateFontString("GearScoreRecountWarning")
			f:SetFrameStrata("TOOLTIP")
			local s = GearScoreRecountWarning; s:SetFont("Fonts\\FRIZQT__.TTF", 30); s:SetText("WARNING! GearScoreRecount MUST be disabled to use GearScore. 3.1.x")
			s:SetPoint("BOTTOMLEFT",UIParent,"CENTER",-600,200)
			s:Show();f:Show()
			print("WARNING! GearScoreRecount MUST be disabled to use GearScore. Please turn it off or remove it from your addons folder, Sorry for the inconvience")
			--error("WARNING! GearScoreRecount MUST be disabled to use GearScore. Please turn it off or remove it from your addons folder, Sorry for the inconvience")
   		end
		
	end
end

function GearScore_CheckPartyGuild(Name)
	local Group = "party"
	if UnitName("raid1") then Group = "raid"; else Group = "party"; end
	for i = 1, 40 do
		if ( UnitName(Group..i) == Name ) then return true; end
	end
	return false
end

function GearScore_ComposeRecord(tbl, GS_Sender)
	local Name, GearScore, Date, Class, Average, Race, Faction, Location, Level, Sex, Guild, Scanned, Equip = tbl[1], tonumber(tbl[2]), tonumber(tbl[3]), tbl[4], tonumber(tbl[5]), tbl[6], tbl[7], tbl[8], tostring(tbl[9]), 1, tbl[10], GS_Sender, {}
--	print(Name, GearScore, Date, Class, Average, Race, Faction, Location, Level, Sex, Guild, Scanned)
	if Scanned == "LOLGearScore" or Scanned == "GearScoreBreaker" then return "InValid"; end
	if ( Scanned == " " ) then Scanned = "Unknown"; end
	for i = 12, 30 do
		if ( i ~= 15 ) then Equip[i-11] = tbl[i]; end
	end	
	local StatString = nil
	if ( GS_Data[GetRealmName()].Players[Name] ) then StatString = GS_Data[GetRealmName()].Players[Name].StatString; end
	GS_Data[GetRealmName()].Players[Name] = { ["Name"] = Name, ["GearScore"] = GearScore, ["PVP"] = 1, ["Level"] = tonumber(Level), ["Faction"] = Faction, ["Sex"] = Sex, ["Guild"] = Guild,
    ["Race"] = Race, ["Class"] =  Class, ["Spec"] = 1, ["Location"] = Location, ["Scanned"] = Scanned, ["Date"] = Date, ["Average"] = Average, ["Equip"] = Equip, ["StatString"] = StatString}
end

function GearScore_Prune()
		--local time, monthago = GearScore_GetTimeStamp()
  		for i, v in pairs(GS_Data[GetRealmName()].Players) do 
			--if ( tonumber(v.Level) < GS_Settings["MinLevel"] ) then GS_Data[GetRealmName()].Players[i] = nil; end;
  			if ( v.Scanned ~= "Server" ) and ( ( ( GS_Factions[v.Faction] ~= UnitFactionGroup("player") ) and ( GS_Settings["KeepFaction"] == -1 ) ) or ( ( tonumber(v.Level) < GS_Settings["MinLevel"] ) and ( v.Name ~= UnitName("player") ) ) ) then GS_Data[GetRealmName()].Players[v.Name] = nil; end
			if not v.GearScore or not v.Name or not v.Sex or not v.Equip or not v.Location or not v.Level or not v.Faction or not v.Guild or not v.Race or not v.Class or not v.Date or not v.Average or not v.Scanned then GS_Data[GetRealmName()].Players[i] = nil; end
			if ( string.find(v.Scanned, "<") ) then GS_Data[GetRealmName()].Players[v.Name] = nil; end
            if v.Guild == "<>" or v.Guild == "" then GS_Data[GetRealmName()].Players[v.Name].Guild = "*"; end
			if ( string.find(v.Guild, "<") ) then GS_Data[GetRealmName()].Players[v.Name].Guild = string.sub(v.Guild, 2, strlen(v.Guild) - 1); end
  			if ( (type(tonumber(v.Guild))) == "number" ) then GS_Data[GetRealmName()].Players[v.Name] = nil; end
  			if v.Scanned == "LOLGearScore" then GS_Data[GetRealmName()].Players[v.Name] = nil; end
  			--if ( GearScore_GetDate(v.Date) > 30 )
			   --if ( GearScore_GetDate(v.Date) > 30 ) then print("Old Record Found     "..i); end
			  --if v.Guild == "<>" then GS_Data[GetRealmName()].Players[v.Name].Guild = "*"; end
		end
end


function GearScore_GetItemCode(ItemLink)
	if not ( ItemLink ) then return nil; end
	local found, _, ItemString = string.find(ItemLink, "^|c%x+|H(.+)|h%[.*%]")
	if not ItemString then return nil; end
	local ItemCode = string.match(ItemString, "^item:(.+)$") or ItemString
	local ItemId = string.match(ItemCode, "^([^:]+)")
	return ItemCode, ItemId
end

GS_ServerItemPrefix = "GSTMOG"
GS_ServerItemReplyPrefix = "GSTMOGR"
GS_ServerCacheTTL = 15
GS_ServerBridgeVersion = 3
GS_TransmogSetDebug = GS_TransmogSetDebug or nil
GS_TransmogSetVerboseDebug = GS_TransmogSetVerboseDebug or nil
GS_DefaultArmorSetTooltipSlots = { 10, 1, 7, 3, 5 }
GS_SetRefreshThrottle = GS_SetRefreshThrottle or {}
GS_ServerStatColumns = {
	{
		{ Key = "strength", Label = "Сила" },
		{ Key = "agility", Label = "Спритність" },
		{ Key = "stamina", Label = "Витривалість" },
		{ Key = "intellect", Label = "Інтелект" },
		{ Key = "spirit", Label = "Дух" },
		{ Key = "armor", Label = "Броня" },
	},
}

function GearScore_TransmogSetDebug(Message)
	if not GS_TransmogSetDebug then return; end
	if DEFAULT_CHAT_FRAME then
		DEFAULT_CHAT_FRAME:AddMessage("|cffffd100GSTSet:|r "..tostring(Message))
	end
end

function GearScore_TransmogSetVerbose(Message)
	if not GS_TransmogSetDebug or not GS_TransmogSetVerboseDebug then return; end
	if DEFAULT_CHAT_FRAME then
		DEFAULT_CHAT_FRAME:AddMessage("|cff80dfffGSTSetV:|r "..tostring(Message))
	end
end

function GearScore_ShortSignature(Signature)
	if not Signature then return "nil"; end
	local Length = string.len(Signature)
	if Length <= 42 then return Signature; end
	return string.sub(Signature, 1, 42).."..("..tostring(Length)..")"
end
GS_ServerStatsMelee = {
	{ Key = "damage", Label = "Шкода" },
	{ Key = "speed", Label = "Швидкість", Digits = 2 },
	{ Key = "ap", Label = "Сила атаки" },
	{ Key = "hit", Label = "Влучання" , Percent = 1 },
	{ Key = "crit", Label = "Крит. удар" , Percent = 1 },
	{ Key = "expertise", Label = "Майстерність" },
}
GS_ServerStatsRanged = {
	{ Key = "ranged_damage", Label = "Шкода" },
	{ Key = "ranged_speed", Label = "Швидкість", Digits = 2 },
	{ Key = "ranged_ap", Label = "Сила атаки" },
	{ Key = "hit_ranged", Label = "Влучання", Percent = 1 },
	{ Key = "crit_ranged", Label = "Крит. удар", Percent = 1 },
}
GS_ServerStatsCaster = {
	{ Key = "spellpower", Label = "Доп. шкода" },
	{ Key = "healpower", Label = "Доп. лікування" },
	{ Key = "hit_spell", Label = "Влучання", Percent = 1 },
	{ Key = "crit_spell", Label = "Крит. удар", Percent = 1 },
	{ Key = "haste_spell", Label = "Швидкість", Percent = 1 },
	{ Key = "mp5", Label = "Відн. мани" },
}
GS_ServerStatsDefense = {
	{ Key = "armor", Label = "Броня" },
	{ Key = "defense", Label = "Захист" },
	{ Key = "dodge", Label = "Ухилення" , Percent = 1 },
	{ Key = "parry", Label = "Парирування" , Percent = 1 },
	{ Key = "block", Label = "Блок" , Percent = 1 },
	{ Key = "resilience", Label = "Стійкість" },
}
GS_ServerStatsProfiles = {
	{ Key = "primary", Label = "Основні" },
	{ Key = "melee", Label = "Ближній бій" },
	{ Key = "ranged", Label = "Дальній бій" },
	{ Key = "caster", Label = "Магія" },
	{ Key = "defense", Label = "Захист" },
}
GS_ServerStatsSelectedProfile = nil
GS_ServerMetaRaceMap = {
	[1] = "Human", [2] = "Orc", [3] = "Dwarf", [4] = "Night Elf", [5] = "Undead", [6] = "Tauren",
	[7] = "Gnome", [8] = "Troll", [10] = "Blood Elf", [11] = "Draenei"
}
GS_ServerMetaClassMap = {
	[1] = "Warrior", [2] = "Paladin", [3] = "Hunter", [4] = "Rogue", [5] = "Priest",
	[6] = "Death Knight", [7] = "Shaman", [8] = "Mage", [9] = "Warlock", [11] = "Druid"
}

function GearScore_HasSelfReportedRecord(Name)
	if not Name then return false; end
	if Name == UnitName("player") then return false; end
	if not GS_Data or not GS_Data[GetRealmName()] or not GS_Data[GetRealmName()].Players then return false; end

	local Record = GS_Data[GetRealmName()].Players[Name]
	return Record and Record.Scanned == Name
end

function GearScore_HasAuthoritativeRecord(Name)
	if not Name then return false; end
	if not GS_Data or not GS_Data[GetRealmName()] or not GS_Data[GetRealmName()].Players then return false; end

	local Record = GS_Data[GetRealmName()].Players[Name]
	return Record and (Record.Scanned == Name or Record.Scanned == "Server")
end

function GearScore_HasFreshServerRecord(Name)
	if not Name then return false; end
	if not GS_Data or not GS_Data[GetRealmName()] or not GS_Data[GetRealmName()].Players then return false; end

	local Record = GS_Data[GetRealmName()].Players[Name]
	if not Record or Record.Scanned ~= "Server" or not Record.ServerCachedAt then return false; end
	if Record.ServerBridgeVersion ~= GS_ServerBridgeVersion then return false; end
	local Age = GetTime() - Record.ServerCachedAt
	return Age >= 0 and Age < GS_ServerCacheTTL
end

function GearScore_RequestServerItemData(Name, Force)
	if not Name then return; end
	if not Force and GearScore_HasFreshServerRecord(Name) then
		return
	end

	if not GS_ServerRequestThrottle then GS_ServerRequestThrottle = {}; end
	local Now = GetTime()
	local LastRequest = GS_ServerRequestThrottle[Name] or 0
	if not Force and (Now - LastRequest) < 1.5 then return; end

	GS_ServerRequestThrottle[Name] = Now
	GearScore_TransmogSetDebug("GSTMOG request -> "..tostring(Name).." force="..tostring(Force))
	SendAddonMessage(GS_ServerItemPrefix, "REQ\t"..Name, "WHISPER", UnitName("player"))
end

function GearScore_RequestSelfServerItemData(Force)
	local Name = UnitName("player")
	if Name then GearScore_RequestServerItemData(Name, Force); end
end

function GearScore_ForceRefreshSelfServerSets()
	local Name = UnitName("player")
	if not Name then return; end
	if not GS_ServerRequestThrottle then GS_ServerRequestThrottle = {}; end
	GS_ServerRequestThrottle[Name] = nil
	GS_SelfSetRefreshAt = nil
	if GS_SetRefreshThrottle then
		for Key, _ in pairs(GS_SetRefreshThrottle) do
			if string.find(Key, Name..":", 1, true) == 1 then GS_SetRefreshThrottle[Key] = nil; end
		end
	end
	GearScore_TransmogSetDebug("manual self server set refresh")
	GearScore_RequestServerItemData(Name, 1)
end

function GearScore_ForceRefreshUnitServerSets(UnitToken)
	if not UnitToken or not UnitExists(UnitToken) or not UnitIsPlayer(UnitToken) then return; end
	local Name = UnitName(UnitToken)
	if not Name then return; end
	if not GS_ServerRequestThrottle then GS_ServerRequestThrottle = {}; end
	GS_ServerRequestThrottle[Name] = nil
	if GS_SetRefreshThrottle then
		for Key, _ in pairs(GS_SetRefreshThrottle) do
			if string.find(Key, Name..":", 1, true) == 1 then GS_SetRefreshThrottle[Key] = nil; end
		end
	end
	GearScore_TransmogSetDebug("manual "..tostring(UnitToken).." server set refresh")
	GearScore_RequestServerItemData(Name, 1)
end

function GearScore_ItemCodeEntry(ItemCode)
	if not ItemCode then return "0"; end
	return string.match(tostring(ItemCode), "^([^:]+)") or tostring(ItemCode)
end

function GearScore_EquipCodesMatch(Left, Right)
	if not Left or not Right then return nil; end
	for Slot = 1, 18 do
		if GearScore_ItemCodeEntry(Left[Slot] or "0:0") ~= GearScore_ItemCodeEntry(Right[Slot] or "0:0") then return nil; end
	end
	return 1
end

function GearScore_GetItemLinkFromCode(ItemCode)
	if not ItemCode or ItemCode == "0:0" then return nil; end
	local ItemName, ItemLink = GetItemInfo("item:"..ItemCode)
	return ItemLink
end

function GearScore_GetTooltipFrame(Name)
	if not Name then return nil; end
	local Frame = _G[Name]
	return Frame
end

function GearScore_GetHiddenSetTooltip()
	if not GS_TransmogSetTooltip then
		GS_TransmogSetTooltip = CreateFrame("GameTooltip", "GS_TransmogSetTooltip", UIParent, "GameTooltipTemplate")
		GS_TransmogSetTooltip:SetOwner(UIParent, "ANCHOR_NONE")
	end
	return GS_TransmogSetTooltip
end

function GearScore_CleanTooltipText(Text)
	if not Text then return nil; end
	Text = string.gsub(Text, "|c%x%x%x%x%x%x%x%x", "")
	Text = string.gsub(Text, "|r", "")
	Text = string.gsub(Text, "|T.-|t", "")
	Text = string.gsub(Text, "^%s+", "")
	Text = string.gsub(Text, "%s+$", "")
	if Text == "" then return nil; end
	return Text
end

function GearScore_ParseItemSetFromTooltip(Tooltip)
	if not Tooltip then return nil; end
	local SetData = nil
	local ReadingItems = nil

	for i = 1, Tooltip:NumLines() do
		local Left = GearScore_GetTooltipFrame(Tooltip:GetName().."TextLeft"..i)
		local Text = Left and GearScore_CleanTooltipText(Left:GetText())
		if Text then
			local SetName, Count, Total = string.match(Text, "^(.-)%s*%((%d+)/(%d+)%)$")
			if SetName and Count and Total then
				SetData = { Name = SetName, Count = tonumber(Count), Total = tonumber(Total), Items = {}, ItemMap = {} }
				ReadingItems = 1
			elseif SetData and ReadingItems then
				if string.find(Text, "^%(") or string.find(Text, ":") or string.find(Text, "^%d") then
					ReadingItems = nil
				else
					tinsert(SetData.Items, Text)
					SetData.ItemMap[Text] = 1
				end
			end
		elseif SetData and ReadingItems then
			ReadingItems = nil
		end
	end

	if SetData and table.getn(SetData.Items) > 0 then return SetData; end
	return nil
end

function GearScore_IsSetLineHighlighted(FontString)
	if not FontString or not FontString.GetTextColor then return nil; end
	local Red, Green, Blue = FontString:GetTextColor()
	if not Red or not Green or not Blue then return nil; end
	return (Red > 0.75 and Green > 0.55 and Blue < 0.55)
end

function GearScore_ParseHighlightedSetRowsFromTooltip(Tooltip, SetName)
	local Highlighted = {}
	if not Tooltip or not SetName then return Highlighted; end

	local NameLine = GearScore_GetTooltipFrame(Tooltip:GetName().."TextLeft1")
	local ItemName = NameLine and GearScore_CleanTooltipText(NameLine:GetText())
	local NormItemName = GearScore_NormalizeSetItemName(ItemName)
	local ReadingItems = nil
	for i = 1, Tooltip:NumLines() do
		local Left = GearScore_GetTooltipFrame(Tooltip:GetName().."TextLeft"..i)
		local Text = Left and GearScore_CleanTooltipText(Left:GetText())
		if Text then
			local CurrentSetName = string.match(Text, "^(.-)%s*%(%d+/%d+%)$")
			if CurrentSetName and CurrentSetName == SetName then
				ReadingItems = 1
			elseif ReadingItems then
				if string.find(Text, "^%(") or string.find(Text, ":") or string.find(Text, "^%d") then
					ReadingItems = nil
				else
					local NormText = GearScore_NormalizeSetItemName(Text)
					local MatchesItem = NormText and NormItemName and (string.find(NormItemName, NormText, 1, true) or string.find(NormText, NormItemName, 1, true))
					if GearScore_IsSetLineHighlighted(Left) or MatchesItem then
						local Red, Green, Blue = Left:GetTextColor()
						local Row = { Red = Red or 1, Green = Green or 1, Blue = Blue or 1 }
						Highlighted[Text] = Row
						if NormText then Highlighted[NormText] = Row; end
					end
				end
			end
		elseif ReadingItems then
			ReadingItems = nil
		end
	end

	return Highlighted
end

function GearScore_GetItemSetDataFromCode(ItemCode)
	if not ItemCode or ItemCode == "0:0" then return nil; end
	if not GS_TransmogSetCache then GS_TransmogSetCache = {}; end

	local CacheEntry = GS_TransmogSetCache[ItemCode]
	if CacheEntry and (GetTime() - CacheEntry.Time) < 300 then
		GearScore_TransmogSetDebug("set cache "..ItemCode.." -> "..(CacheEntry.Data and CacheEntry.Data.Name or "none"))
		return CacheEntry.Data
	end

	local Tooltip = GearScore_GetHiddenSetTooltip()
	Tooltip:ClearLines()
	Tooltip:SetHyperlink("item:"..ItemCode)
	local SetData = GearScore_ParseItemSetFromTooltip(Tooltip)
	GearScore_TransmogSetDebug("parse item "..ItemCode.." -> "..(SetData and (SetData.Name.." "..table.getn(SetData.Items).." items") or "no set"))
	if SetData or Tooltip:NumLines() > 0 then
		GS_TransmogSetCache[ItemCode] = { Time = GetTime(), Data = SetData or false }
	end
	return SetData
end

function GearScore_GetItemNameFromCode(ItemCode)
	if not ItemCode or ItemCode == "0:0" then return nil; end
	local ItemName = GetItemInfo("item:"..ItemCode)
	return ItemName
end

function GearScore_GetTooltipItemNameFromCode(ItemCode)
	if not ItemCode or ItemCode == "0:0" then return nil; end
	local Tooltip = GearScore_GetHiddenSetTooltip()
	Tooltip:ClearLines()
	Tooltip:SetHyperlink("item:"..ItemCode)
	local Left = GearScore_GetTooltipFrame(Tooltip:GetName().."TextLeft1")
	return Left and GearScore_CleanTooltipText(Left:GetText())
end

function GearScore_GetHighlightedSetRowsFromCode(ItemCode, SetName)
	if not ItemCode or ItemCode == "0:0" or not SetName then return {}; end
	local Tooltip = GearScore_GetHiddenSetTooltip()
	Tooltip:ClearLines()
	Tooltip:SetHyperlink("item:"..ItemCode)
	return GearScore_ParseHighlightedSetRowsFromTooltip(Tooltip, SetName)
end

function GearScore_NormalizeSetItemName(Text)
	Text = GearScore_CleanTooltipText(Text)
	if not Text then return nil; end
	Text = string.lower(Text)
	Text = string.gsub(Text, "%s+", "")
	Text = string.gsub(Text, "[%(%)]", "")
	Text = string.gsub(Text, "[%[%]]", "")
	Text = string.gsub(Text, "[%.,:;%-']", "")
	return Text
end

function GearScore_SetRowMatchesEquipped(NormText, EquippedNorm)
	if not NormText or not EquippedNorm or string.len(NormText) < 8 then return nil; end

	if EquippedNorm[NormText] then return 1; end
	for EquippedName, _ in pairs(EquippedNorm) do
		if EquippedName and string.len(EquippedName) >= 8 then
			if string.find(EquippedName, NormText, 1, true) or string.find(NormText, EquippedName, 1, true) then
				return 1
			end
		end
	end

	return nil
end

function GearScore_GetSetRowsForItemName(SetData, ItemName)
	local Rows = {}
	local NormItemName = GearScore_NormalizeSetItemName(ItemName)
	if not SetData or not SetData.Items or not NormItemName then return Rows; end

	for _, RowText in ipairs(SetData.Items) do
		local NormRow = GearScore_NormalizeSetItemName(RowText)
		if NormRow and string.len(NormRow) >= 8 then
			if string.find(NormItemName, NormRow, 1, true) or string.find(NormRow, NormItemName, 1, true) then
				Rows[RowText] = 1
				Rows[NormRow] = 1
			end
		end
	end

	return Rows
end

function GearScore_FindServerSetRow(ServerSet, Text)
	if not ServerSet or not Text then return nil; end

	local NormText = GearScore_NormalizeSetItemName(Text)
	local Row = ServerSet.Rows[Text] or ServerSet.FullNames[Text]
	if not Row and NormText then
		Row = ServerSet.NormRows[NormText] or ServerSet.NormFullNames[NormText]
	end
	if not Row and ServerSet.Members then
		Row = ServerSet.Members.Rows[Text]
		if not Row and NormText then Row = ServerSet.Members.NormRows[NormText]; end
	end
	return Row
end

function GearScore_GetVisibleSetItemColor(Tooltip, SetData)
	if not Tooltip or not SetData or not SetData.Name then return nil; end

	local ReadingItems = nil
	for i = 1, Tooltip:NumLines() do
		local Left = GearScore_GetTooltipFrame(Tooltip:GetName().."TextLeft"..i)
		local Text = Left and GearScore_CleanTooltipText(Left:GetText())
		if Text then
			local SetName = string.match(Text, "^(.-)%s*%(%d+/%d+%)$")
			if SetName and SetName == SetData.Name then
				ReadingItems = 1
			elseif ReadingItems then
				if string.find(Text, "^%(") or string.find(Text, ":") or string.find(Text, "^%d") then
					ReadingItems = nil
				elseif Left.GetTextColor then
					local Red, Green, Blue = Left:GetTextColor()
					if Red and Green and Blue and not (Red < 0.65 and Green < 0.65 and Blue < 0.65) then
						return { Red = Red, Green = Green, Blue = Blue }
					end
				end
			end
		elseif ReadingItems then
			ReadingItems = nil
		end
	end

	return nil
end

function GearScore_GetCurrentVisibleSetRows(Tooltip, SetData)
	local CurrentRows = {}
	if not Tooltip or not SetData or not SetData.Name then return CurrentRows; end

	local ReadingItems = nil
	for i = 1, Tooltip:NumLines() do
		local Left = GearScore_GetTooltipFrame(Tooltip:GetName().."TextLeft"..i)
		local Text = Left and GearScore_CleanTooltipText(Left:GetText())
		if Text then
			local SetName = string.match(Text, "^(.-)%s*%(%d+/%d+%)$")
			if SetName and SetName == SetData.Name then
				ReadingItems = 1
			elseif ReadingItems then
				if string.find(Text, "^%(") or string.find(Text, ":") or string.find(Text, "^%d") then
					ReadingItems = nil
				elseif SetData.ItemMap[Text] and GearScore_IsSetLineHighlighted(Left) then
					CurrentRows[Text] = 1
					local NormText = GearScore_NormalizeSetItemName(Text)
					if NormText then CurrentRows[NormText] = 1; end
				end
			end
		elseif ReadingItems then
			ReadingItems = nil
		end
	end

	return CurrentRows
end

function GearScore_GetRealEquippedSetPieces(Record, SetData, CurrentSignature, CurrentSetId)
	local Equipped = {}
	local EquippedNorm = {}
	local EquippedRows = {}
	local EquippedDisplayNames = {}
	local EquippedSlots = {}
	local Count = 0
	if not Record or not Record.Equip or not SetData or not SetData.Name then return Equipped, EquippedNorm, EquippedRows, EquippedDisplayNames, Count; end
	GearScore_TransmogSetDebug("match begin set='"..tostring(SetData.Name).."' currentSig="..GearScore_ShortSignature(CurrentSignature))

	for Slot = 1, 18 do
		local ItemCode = Record.Equip[Slot]
		local EquippedSetData = GearScore_GetItemSetDataFromCode(ItemCode)
		local ServerRow = Record.Sets and Record.Sets.BySlot and Record.Sets.BySlot[Slot]
		local SameServerSignature = CurrentSignature and ServerRow and ServerRow.Signature and ServerRow.Signature == CurrentSignature
		local SameServerSetId = CurrentSetId and ServerRow and ServerRow.SetId == CurrentSetId
		if ServerRow then
			GearScore_TransmogSetDebug("slot "..tostring(Slot).." setId="..tostring(ServerRow.SetId).." sameSet="..tostring(SameServerSetId).." sig="..GearScore_ShortSignature(ServerRow.Signature).." sameSig="..tostring(SameServerSignature).." row='"..tostring(ServerRow.RowName).."'")
		end
		if SameServerSetId or SameServerSignature or (EquippedSetData and EquippedSetData.Name == SetData.Name) then
			EquippedRows["__slot:"..tostring(Slot)] = 1
			if (SameServerSetId or SameServerSignature) and ServerRow then
				if ServerRow.RowName then
					EquippedRows[ServerRow.RowName] = 1
					EquippedDisplayNames[ServerRow.RowName] = ServerRow.FullName or ServerRow.RowName
					local NormRow = GearScore_NormalizeSetItemName(ServerRow.RowName)
					if NormRow then
						EquippedRows[NormRow] = 1
						EquippedDisplayNames[NormRow] = ServerRow.FullName or ServerRow.RowName
					end
				end
				if ServerRow.FullName then
					Equipped[ServerRow.FullName] = 1
					local NormFullName = GearScore_NormalizeSetItemName(ServerRow.FullName)
					if NormFullName then EquippedNorm[NormFullName] = 1; end
				end
			end
			local ItemName = ServerRow and ServerRow.FullName
			if not SameServerSetId and not SameServerSignature then
				ItemName = GearScore_GetTooltipItemNameFromCode(ItemCode) or GearScore_GetItemNameFromCode(ItemCode)
				local HighlightedRows = GearScore_GetHighlightedSetRowsFromCode(ItemCode, SetData.Name)
				for RowName, _ in pairs(HighlightedRows) do
					EquippedRows[RowName] = 1
				end
				if ItemName and not Equipped[ItemName] then
					Equipped[ItemName] = 1
					local NormName = GearScore_NormalizeSetItemName(ItemName)
					if NormName then EquippedNorm[NormName] = 1; end
					local MatchedRows = GearScore_GetSetRowsForItemName(SetData, ItemName)
					for RowName, _ in pairs(MatchedRows) do
						EquippedRows[RowName] = 1
						EquippedDisplayNames[RowName] = ItemName
					end
				end
			end
			if not EquippedSlots[Slot] then
				EquippedSlots[Slot] = 1
				Count = Count + 1
			end
			GearScore_TransmogSetDebug("matched equipped set piece slot "..tostring(Slot).." "..tostring(ItemName or (ServerRow and ServerRow.FullName) or "server-row").." byName="..tostring(EquippedSetData and EquippedSetData.Name == SetData.Name).." bySet="..tostring(SameServerSetId).." bySig="..tostring(SameServerSignature))
		elseif ServerRow then
			GearScore_TransmogSetDebug("slot "..tostring(Slot).." not matched; clientSet='"..tostring(EquippedSetData and EquippedSetData.Name or "nil").."'")
		end
	end

	return Equipped, EquippedNorm, EquippedRows, EquippedDisplayNames, Count
end

function GearScore_AddVisibleSetRowsByServerSignature(SetData, Record, Signature, ServerSet, EquippedRows, EquippedDisplayNames)
	if not Record or not Record.Sets or not Signature or not EquippedRows then return; end
	if not Record.Sets.BySignature or not Record.Sets.BySignature[Signature] then
		GearScore_TransmogSetDebug("no BySignature map for sig="..GearScore_ShortSignature(Signature))
		return
	end

	local SlotCount = 0
	for Slot, EquippedServerRow in pairs(Record.Sets.BySignature[Signature]) do
		SlotCount = SlotCount + 1
		EquippedRows["__slot:"..tostring(Slot)] = 1
		local RowText = EquippedServerRow and EquippedServerRow.RowName
		if RowText then
			EquippedRows[RowText] = 1
			if EquippedDisplayNames then
				EquippedDisplayNames[RowText] = EquippedServerRow.FullName or RowText
			end
			local NormRow = GearScore_NormalizeSetItemName(RowText)
			if NormRow then
				EquippedRows[NormRow] = 1
				if EquippedDisplayNames then
					EquippedDisplayNames[NormRow] = EquippedServerRow.FullName or RowText
				end
			end
			GearScore_TransmogSetDebug("signature server row match slot="..tostring(Slot).." row='"..tostring(RowText).."' equipped='"..tostring(EquippedServerRow.FullName).."'")
		else
			GearScore_TransmogSetDebug("signature slot row miss slot="..tostring(Slot).." equipped='"..tostring(EquippedServerRow and EquippedServerRow.FullName).."'")
		end
	end
	GearScore_TransmogSetDebug("signature equipped slot count "..tostring(SlotCount).." sig="..GearScore_ShortSignature(Signature))
end

function GearScore_PatchVisibleSetTooltip(Tooltip, SetData, Equipped, EquippedNorm, EquippedRows, EquippedDisplayNames, CurrentRows, ServerSet, CurrentServerRow, EquippedCount, CurrentSlot)
	if not Tooltip or not SetData or not Equipped then return nil; end
	local Patched = nil
	local Highlighted = 0
	local EquippedColor = GearScore_GetVisibleSetItemColor(Tooltip, SetData) or { Red = 1, Green = 0.82, Blue = 0 }
	local InSetItems = nil
	local VisibleSetRowIndex = 0
	local TitleLeft = GearScore_GetTooltipFrame(Tooltip:GetName().."TextLeft1")
	local TitleText = TitleLeft and TitleLeft:GetText()
	local TitleClean = GearScore_CleanTooltipText(TitleText)
	local NormTitle = GearScore_NormalizeSetItemName(TitleClean)
	local TitleRed, TitleGreen, TitleBlue
	if TitleLeft and TitleLeft.GetTextColor then
		TitleRed, TitleGreen, TitleBlue = TitleLeft:GetTextColor()
	end

	for i = 1, Tooltip:NumLines() do
		local Left = GearScore_GetTooltipFrame(Tooltip:GetName().."TextLeft"..i)
		local Text = Left and GearScore_CleanTooltipText(Left:GetText())
		if Text then
			local SetName = string.match(Text, "^(.-)%s*%(%d+/%d+%)$")
			if SetName and SetName == SetData.Name then
				GearScore_TransmogSetDebug("tooltip set header '"..tostring(SetName).."' -> count "..tostring(EquippedCount).."/"..tostring(SetData.Total))
				Left:SetText(SetData.Name.." ("..EquippedCount.."/"..SetData.Total..")")
				Left:SetTextColor(1, 0.82, 0)
				InSetItems = 1
				VisibleSetRowIndex = 0
				Patched = 1
			elseif InSetItems then
				if string.find(Text, "^%(") or string.find(Text, ":") or string.find(Text, "^%d") then
					InSetItems = nil
				else
					VisibleSetRowIndex = VisibleSetRowIndex + 1
					local NormText = GearScore_NormalizeSetItemName(Text)
					local ServerRow = GearScore_FindServerSetRow(ServerSet, Text)
					if not ServerRow and ServerSet and ServerSet.Members then
						if ServerSet.Members.OrderedSlots then
							ServerRow = ServerSet.Members.OrderedSlots[VisibleSetRowIndex]
						elseif ServerSet.Members.Ordered then
							ServerRow = ServerSet.Members.Ordered[VisibleSetRowIndex]
						end
					end
					if not ServerRow and SetData.Total == 5 and GS_DefaultArmorSetTooltipSlots[VisibleSetRowIndex] then
						ServerRow = { Slot = GS_DefaultArmorSetTooltipSlots[VisibleSetRowIndex], RowName = Text }
					end
					GearScore_TransmogSetVerbose("row#"..tostring(VisibleSetRowIndex).." text='"..tostring(Text).."' mappedSlot="..tostring(ServerRow and ServerRow.Slot).." mappedRow='"..tostring(ServerRow and ServerRow.RowName).."'")
					local RowStyle = EquippedRows and (EquippedRows[Text] or (NormText and EquippedRows[NormText]))
					local UseServerRows = CurrentServerRow and CurrentServerRow.Signature
					local IsSetRow = SetData.ItemMap[Text] or ServerRow or RowStyle
					if not IsSetRow and not UseServerRows then
						IsSetRow = GearScore_SetRowMatchesEquipped(NormText, EquippedNorm)
					end
					GearScore_TransmogSetDebug("tooltip row '"..tostring(Text).."' isSet="..tostring(IsSetRow).." rowStyle="..tostring(RowStyle).." serverSlot="..tostring(ServerRow and ServerRow.Slot))
					if IsSetRow then
						local FullName = (ServerRow and ServerRow.FullName) or (EquippedDisplayNames and (EquippedDisplayNames[Text] or (NormText and EquippedDisplayNames[NormText])))
						local NormFullName = GearScore_NormalizeSetItemName(FullName)
						local IsCurrent = (CurrentServerRow and ServerRow and CurrentServerRow.Slot == ServerRow.Slot)
						if not IsCurrent and CurrentSlot and ServerRow and ServerRow.Slot then
							IsCurrent = CurrentSlot == ServerRow.Slot
						end
						if not IsCurrent and NormTitle then
							IsCurrent = (NormText and (string.find(NormTitle, NormText, 1, true) or string.find(NormText, NormTitle, 1, true))) or (NormFullName and (NormFullName == NormTitle or string.find(NormTitle, NormFullName, 1, true) or string.find(NormFullName, NormTitle, 1, true)))
						end
						if not IsCurrent then
							IsCurrent = CurrentRows and (CurrentRows[Text] or (NormText and CurrentRows[NormText]))
						end
						Left:SetText("  "..Text)
						local IsEquippedServerSlot = ServerRow and ServerRow.Slot and EquippedRows and EquippedRows["__slot:"..tostring(ServerRow.Slot)]
						local IsEquippedRow = Equipped[Text] or RowStyle or IsEquippedServerSlot
						if not IsEquippedRow and not UseServerRows then
							IsEquippedRow = GearScore_SetRowMatchesEquipped(NormText, EquippedNorm)
						end
						GearScore_TransmogSetVerbose("row#"..tostring(VisibleSetRowIndex).." equipped="..tostring(IsEquippedRow).." slotFlag="..tostring(IsEquippedServerSlot).." rowStyle="..tostring(RowStyle).." current="..tostring(IsCurrent))
						if IsEquippedRow then
							GearScore_TransmogSetDebug("highlight row '"..tostring(Text).."' current="..tostring(IsCurrent).." full='"..tostring(FullName).."'")
							if IsCurrent then
								Left:SetTextColor(1, 0.45, 0)
							else
								Left:SetTextColor(EquippedColor.Red, EquippedColor.Green, EquippedColor.Blue)
							end
							Highlighted = Highlighted + 1
						end
						Patched = 1
					end
				end
			end
		end
	end

	if TitleLeft then
		if TitleText then TitleLeft:SetText(TitleText); end
		if TitleRed and TitleGreen and TitleBlue then TitleLeft:SetTextColor(TitleRed, TitleGreen, TitleBlue); end
	end

	GearScore_TransmogSetDebug("visible set highlighted "..tostring(Highlighted).." lines")
	return Patched
end

function GearScore_PatchVisibleSetBonuses(Tooltip, SetData, EquippedCount)
	if not Tooltip or not SetData or not SetData.Name or not EquippedCount then return; end

	local InSetBlock = nil
	local SeenBonus = nil
	local Highlighted = 0
	for i = 1, Tooltip:NumLines() do
		local Left = GearScore_GetTooltipFrame(Tooltip:GetName().."TextLeft"..i)
		local Text = Left and GearScore_CleanTooltipText(Left:GetText())
		if Text then
			local SetName = string.match(Text, "^(.-)%s*%(%d+/%d+%)$")
			if SetName and SetName == SetData.Name then
				InSetBlock = 1
			elseif InSetBlock then
				local Required = tonumber(string.match(Text, "%((%d+)%s+"))
				if Required and string.find(Text, ":") then
					SeenBonus = 1
					if Required <= EquippedCount then
						Left:SetTextColor(0, 1, 0)
						Highlighted = Highlighted + 1
					end
				elseif SeenBonus and (string.find(Text, "^%S") and not string.find(Text, "^%(")) then
					break
				end
			end
		elseif SeenBonus then
			break
		end
	end

	GearScore_TransmogSetDebug("visible set bonuses highlighted "..tostring(Highlighted).." lines")
end

function GearScore_IsSocketBonusLine(Text)
	if not Text then return nil; end
	if string.find(Text, "соответствии цвета") then return 1; end
	if string.find(Text, "відповідності кольор") then return 1; end
	if string.find(Text, "Socket Bonus") then return 1; end
	return nil
end

function GearScore_IsGemEffectLine(Text)
	if not Text then return nil; end
	if GearScore_IsSocketBonusLine(Text) then return 1; end
	if string.find(Text, "^Комплект %(") then return nil; end
	if string.find(Text, "Socket") then return 1; end
	if string.find(Text, "Meta") then return 1; end
	if string.find(Text, "мета") then return 1; end
	if GearScore_IsMetaGemLine(Text) then return 1; end
	return nil
end

function GearScore_IsMetaGemLine(Text)
	if not Text then return nil; end
	if string.find(Text, "Требуется хотя бы") then return 1; end
	if string.find(Text, "Потріб") and string.find(Text, "кам") then return 1; end
	if string.find(Text, "Requires at least") then return 1; end
	return nil
end

function GearScore_IsMetaSocketBlockLine(Text)
	if not Text then return nil; end
	if GearScore_IsSocketBonusLine(Text) then return 1; end
	if GearScore_IsMetaGemLine(Text) then return 1; end
	return nil
end

function GearScore_GetTooltipLineColor(Tooltip, Line)
	local Left = Tooltip and GearScore_GetTooltipFrame(Tooltip:GetName().."TextLeft"..Line)
	if Left and Left.GetTextColor then
		local Red, Green, Blue = Left:GetTextColor()
		return Red, Green, Blue
	end
	return nil, nil, nil
end

function GearScore_TooltipHasCleanLine(Tooltip, CleanText)
	if not Tooltip or not CleanText then return nil; end
	for i = 1, Tooltip:NumLines() do
		local Left = GearScore_GetTooltipFrame(Tooltip:GetName().."TextLeft"..i)
		local Text = Left and GearScore_CleanTooltipText(Left:GetText())
		if Text == CleanText then return 1; end
	end
	return nil
end

function GearScore_FindSocketInsertLine(Tooltip)
	if not Tooltip then return nil; end
	for i = 1, Tooltip:NumLines() do
		local Left = GearScore_GetTooltipFrame(Tooltip:GetName().."TextLeft"..i)
		local Text = Left and GearScore_CleanTooltipText(Left:GetText())
		if GearScore_IsSocketBonusLine(Text) then return i; end
	end
	for i = 1, Tooltip:NumLines() do
		local Left = GearScore_GetTooltipFrame(Tooltip:GetName().."TextLeft"..i)
		local Text = Left and GearScore_CleanTooltipText(Left:GetText())
		if Text and string.match(Text, "^(.-)%s*%(%d+/%d+%)$") then return i; end
	end
	return Tooltip:NumLines() + 1
end

function GearScore_InsertTooltipLeftLine(Tooltip, Line, Text, Red, Green, Blue)
	if not Tooltip or not Line or not Text then return; end

	local Lines = Tooltip:NumLines()
	local Existing = {}
	for i = Line, Lines do
		local Left = GearScore_GetTooltipFrame(Tooltip:GetName().."TextLeft"..i)
		if Left then
			local R, G, B = GearScore_GetTooltipLineColor(Tooltip, i)
			Existing[i] = { Text = Left:GetText(), Red = R, Green = G, Blue = B }
		end
	end

	Tooltip:AddLine(" ")
	for i = Lines, Line, -1 do
		local Target = GearScore_GetTooltipFrame(Tooltip:GetName().."TextLeft"..(i + 1))
		local Source = Existing[i]
		if Target and Source then
			Target:SetText(Source.Text or "")
			if Source.Red and Source.Green and Source.Blue then Target:SetTextColor(Source.Red, Source.Green, Source.Blue); end
		end
	end

	local Insert = GearScore_GetTooltipFrame(Tooltip:GetName().."TextLeft"..Line)
	if Insert then
		Insert:SetText(Text)
		if Red and Green and Blue then Insert:SetTextColor(Red, Green, Blue); end
	end
end

function GearScore_PatchVisibleSocketBonus(Tooltip, RealItemCode, SocketInfo)
	if not Tooltip or not RealItemCode or RealItemCode == "0:0" then return; end

	local RealTooltip = GearScore_GetHiddenSetTooltip()
	RealTooltip:ClearLines()
	RealTooltip:SetHyperlink("item:"..RealItemCode)

	local MissingGemLines = {}
	local RealSocketLines = {}
	local RealText, RealRed, RealGreen, RealBlue = nil, nil, nil, nil
	for i = 1, RealTooltip:NumLines() do
		local Left = GearScore_GetTooltipFrame(RealTooltip:GetName().."TextLeft"..i)
		local Text = Left and GearScore_CleanTooltipText(Left:GetText())
		if GearScore_IsGemEffectLine(Text) then
			local Red, Green, Blue = GearScore_GetTooltipLineColor(RealTooltip, i)
			local GemLine = { Text = Text, Red = Red, Green = Green, Blue = Blue }
			RealSocketLines[Text] = GemLine
			local NormText = GearScore_NormalizeSetItemName(Text)
			if NormText then RealSocketLines[NormText] = GemLine; end
			if not GearScore_TooltipHasCleanLine(Tooltip, Text) then
				tinsert(MissingGemLines, GemLine)
			end
		end
		if GearScore_IsSocketBonusLine(Text) then
			RealText = Text
			if Left.GetTextColor then RealRed, RealGreen, RealBlue = Left:GetTextColor(); end
		end
	end

	local ColoredGemLines = 0
	for i = 1, Tooltip:NumLines() do
		local Left = GearScore_GetTooltipFrame(Tooltip:GetName().."TextLeft"..i)
		local Text = Left and GearScore_CleanTooltipText(Left:GetText())
		local NormText = GearScore_NormalizeSetItemName(Text)
		local RealLine = Text and (RealSocketLines[Text] or (NormText and RealSocketLines[NormText]))
		if Left and RealLine and GearScore_IsMetaSocketBlockLine(Text) then
			if GearScore_IsMetaSocketBlockLine(Text) then
				Left:SetText(Text)
				if SocketInfo and SocketInfo.MetaActive == 1 then
					Left:SetTextColor(1, 1, 1)
					GearScore_TransmogSetDebug("forced white active meta line "..tostring(i))
				elseif SocketInfo and SocketInfo.MetaActive == 0 then
					Left:SetTextColor(0.5, 0.5, 0.5)
					GearScore_TransmogSetDebug("forced gray inactive meta line "..tostring(i))
				end
			end
			ColoredGemLines = ColoredGemLines + 1
		end
	end
	if ColoredGemLines > 0 then GearScore_TransmogSetDebug("colored visible gem lines "..tostring(ColoredGemLines)); end

	if RealText then for i = 1, Tooltip:NumLines() do
		local Left = GearScore_GetTooltipFrame(Tooltip:GetName().."TextLeft"..i)
		local Text = Left and GearScore_CleanTooltipText(Left:GetText())
		if GearScore_IsSocketBonusLine(Text) then
			Left:SetText(RealText)
			if SocketInfo and SocketInfo.SocketBonusActive == 1 then
				Left:SetTextColor(1, 1, 1)
				GearScore_TransmogSetDebug("patched active visible socket bonus")
			elseif SocketInfo and SocketInfo.SocketBonusActive == 0 then
				Left:SetTextColor(0.5, 0.5, 0.5)
				GearScore_TransmogSetDebug("patched inactive visible socket bonus")
			else
				GearScore_TransmogSetDebug("patched visible socket bonus text")
			end
			break
		end
	end end

	if table.getn(MissingGemLines) > 0 then
		local InsertLine = GearScore_FindSocketInsertLine(Tooltip)
		for _, GemLine in ipairs(MissingGemLines) do
			GearScore_InsertTooltipLeftLine(Tooltip, InsertLine, GemLine.Text, GemLine.Red, GemLine.Green, GemLine.Blue)
			InsertLine = InsertLine + 1
		end
		GearScore_TransmogSetDebug("inserted missing gem lines "..tostring(table.getn(MissingGemLines)))
	end

	if RealText and table.getn(MissingGemLines) == 0 then return; end
	if RealText then return; end
	GearScore_TransmogSetDebug("real socket bonus exists but visible line is missing")
end

function GearScore_AddRealSetBlock(Tooltip, SetData, Equipped, EquippedCount)
	if not Tooltip or not SetData or not Equipped then return; end

	Tooltip:AddLine(" ")
	Tooltip:AddLine("Реальний комплект: "..SetData.Name.." ("..EquippedCount.."/"..SetData.Total..")", 1, 0.82, 0)
	for _, ItemName in ipairs(SetData.Items) do
		if Equipped[ItemName] then
			Tooltip:AddLine(ItemName, 1, 0.82, 0)
		else
			Tooltip:AddLine(ItemName, 0.5, 0.5, 0.5)
		end
	end
end

function GearScore_FixRecordItemTooltip(Tooltip, Record, Slot, Name)
	if not Tooltip or not Record or not Record.Equip or not Slot then return; end

	local RealItemCode = Record.Equip[Slot]
	if not RealItemCode or RealItemCode == "0:0" then return; end

	local SocketInfo = Record.Sockets and Record.Sockets.BySlot and Record.Sockets.BySlot[Slot]
	GearScore_PatchVisibleSocketBonus(Tooltip, RealItemCode, SocketInfo)

	local SetData = GearScore_GetItemSetDataFromCode(RealItemCode)
	if not SetData then
		GearScore_TransmogSetDebug("no set data for real item "..tostring(RealItemCode))
		Tooltip:Show()
		return
	end

	local CurrentServerRow = Record.Sets and Record.Sets.BySlot and Record.Sets.BySlot[Slot]
	local ServerSet = CurrentServerRow and Record.Sets and Record.Sets[CurrentServerRow.SetId]
	local CurrentItemName = CurrentServerRow and CurrentServerRow.FullName
	local CurrentRows = {}
	if CurrentServerRow and CurrentServerRow.RowName then
		CurrentRows[CurrentServerRow.RowName] = 1
		local NormCurrentRow = GearScore_NormalizeSetItemName(CurrentServerRow.RowName)
		if NormCurrentRow then CurrentRows[NormCurrentRow] = 1; end
	end
	if not CurrentServerRow then
		CurrentItemName = GearScore_GetTooltipItemNameFromCode(RealItemCode) or GearScore_GetItemNameFromCode(RealItemCode)
		CurrentRows = GearScore_GetSetRowsForItemName(SetData, CurrentItemName)
	end
	GearScore_TransmogSetDebug("fix tooltip name="..tostring(Name).." slot="..tostring(Slot).." set='"..tostring(SetData.Name).."' currentItem='"..tostring(CurrentItemName).."' serverSetId="..tostring(CurrentServerRow and CurrentServerRow.SetId).." sig="..GearScore_ShortSignature(CurrentServerRow and CurrentServerRow.Signature))
	local Equipped, EquippedNorm, EquippedRows, EquippedDisplayNames, EquippedCount = GearScore_GetRealEquippedSetPieces(Record, SetData, CurrentServerRow and CurrentServerRow.Signature, CurrentServerRow and CurrentServerRow.SetId)
	if ServerSet and ServerSet.Members and CurrentServerRow and CurrentServerRow.Signature and Record.Sets and Record.Sets.BySignature and Record.Sets.BySignature[CurrentServerRow.Signature] then
		GearScore_TransmogSetDebug("member cross-match available setId="..tostring(CurrentServerRow.SetId))
		local OrderedSlotsCount = ServerSet.Members.OrderedSlots and table.getn(ServerSet.Members.OrderedSlots) or 0
		local OrderedCount = ServerSet.Members.Ordered and table.getn(ServerSet.Members.Ordered) or 0
		GearScore_TransmogSetDebug("member rows orderedSlots="..tostring(OrderedSlotsCount).." ordered="..tostring(OrderedCount))
		for _, Member in pairs(ServerSet.Members.BySlot) do
			local EquippedServerRow = Record.Sets.BySignature[CurrentServerRow.Signature][Member.Slot]
			if EquippedServerRow then
				GearScore_TransmogSetDebug("member row match visible='"..tostring(Member.RowName).."' slot="..tostring(Member.Slot).." equipped='"..tostring(EquippedServerRow.FullName).."'")
				if Member.RowName then
					EquippedRows[Member.RowName] = 1
					EquippedDisplayNames[Member.RowName] = EquippedServerRow.FullName
					local NormMember = GearScore_NormalizeSetItemName(Member.RowName)
					if NormMember then
						EquippedRows[NormMember] = 1
						EquippedDisplayNames[NormMember] = EquippedServerRow.FullName
					end
				end
			end
		end
	elseif ServerSet and ServerSet.Members and CurrentServerRow and Record.Sets and Record.Sets.BySlot then
		GearScore_TransmogSetDebug("member setId cross-match available setId="..tostring(CurrentServerRow.SetId))
		for _, Member in pairs(ServerSet.Members.BySlot) do
			local EquippedServerRow = Record.Sets.BySlot[Member.Slot]
			if EquippedServerRow and EquippedServerRow.SetId == CurrentServerRow.SetId then
				GearScore_TransmogSetDebug("member setId row match visible='"..tostring(Member.RowName).."' slot="..tostring(Member.Slot).." equipped='"..tostring(EquippedServerRow.FullName).."'")
				if Member.RowName then
					EquippedRows[Member.RowName] = 1
					EquippedDisplayNames[Member.RowName] = EquippedServerRow.FullName
					local NormMember = GearScore_NormalizeSetItemName(Member.RowName)
					if NormMember then
						EquippedRows[NormMember] = 1
						EquippedDisplayNames[NormMember] = EquippedServerRow.FullName
					end
				end
			end
		end
	else
		GearScore_TransmogSetDebug("member cross-match missing serverSet="..tostring(ServerSet ~= nil).." members="..tostring(ServerSet and ServerSet.Members ~= nil).." sigMap="..tostring(Record.Sets and CurrentServerRow and CurrentServerRow.Signature and Record.Sets.BySignature and Record.Sets.BySignature[CurrentServerRow.Signature] ~= nil))
	end
	GearScore_AddVisibleSetRowsByServerSignature(SetData, Record, CurrentServerRow and CurrentServerRow.Signature, ServerSet, EquippedRows, EquippedDisplayNames)
	GearScore_TransmogSetDebug("equipped real set count "..tostring(EquippedCount).."/"..tostring(SetData.Total))
	if EquippedCount <= 0 then return; end

	if not GearScore_PatchVisibleSetTooltip(Tooltip, SetData, Equipped, EquippedNorm, EquippedRows, EquippedDisplayNames, CurrentRows, ServerSet, CurrentServerRow, EquippedCount, Slot) then
		GearScore_TransmogSetDebug("visible set block not found, adding real block")
		GearScore_AddRealSetBlock(Tooltip, SetData, Equipped, EquippedCount)
	else
		GearScore_TransmogSetDebug("patched visible set block")
	end
	GearScore_PatchVisibleSetBonuses(Tooltip, SetData, EquippedCount)
	Tooltip:Show()
end

function GearScore_FixTransmogSetTooltip(Tooltip, UnitToken, Slot)
	if not Tooltip or not UnitToken or not Slot then return; end
	if not UnitExists(UnitToken) or not UnitIsPlayer(UnitToken) then return; end

	local Name = UnitName(UnitToken)
	if not Name then return; end
	if not GS_Data or not GS_Data[GetRealmName()] or not GS_Data[GetRealmName()].Players then return; end

	local Record = GS_Data[GetRealmName()].Players[Name]
	if not Record or not Record.Equip then
		if Name == UnitName("player") then
			GearScore_GetScore(Name, "player")
			Record = GS_Data[GetRealmName()].Players[Name]
			if Record and Record.Equip then
				GearScore_TransmogSetDebug("built self record for "..Name)
			end
		end
	end
	if not Record or not Record.Equip then
		GearScore_TransmogSetDebug("no server record for "..Name..", skip item tooltip patch")
		return
	end
	if UnitToken == "player" and (not Record.Sets or not Record.Sets.BySlot or not Record.Sets.BySlot[Slot]) then
		GearScore_TransmogSetDebug("self server sets missing for slot "..tostring(Slot)..", request refresh")
		if not GS_SelfSetRefreshAt or (GetTime() - GS_SelfSetRefreshAt) > 3 then
			GS_SelfSetRefreshAt = GetTime()
			GearScore_RequestServerItemData(Name, 1)
		else
			GearScore_TransmogSetDebug("self server set refresh throttled age="..tostring(GetTime() - GS_SelfSetRefreshAt))
		end
	end
	if UnitToken ~= "player" and (not Record.Sets or not Record.Sets.BySlot or not Record.Sets.BySlot[Slot]) then
		local Now = GetTime()
		local RefreshKey = Name..":"..tostring(Slot)
		local LastRefresh = GS_SetRefreshThrottle[RefreshKey] or 0
		GearScore_TransmogSetDebug("target server sets missing for "..Name.." slot "..tostring(Slot)..", request refresh")
		if (Now - LastRefresh) > 3 then
			GS_SetRefreshThrottle[RefreshKey] = Now
			GearScore_RequestServerItemData(Name, 1)
		else
			GearScore_TransmogSetDebug("target server set refresh throttled age="..tostring(Now - LastRefresh))
		end
	end

	local RealItemCode = Record.Equip[Slot]
	if (not RealItemCode or RealItemCode == "0:0") and GetMouseFocus then
		local Focus = GetMouseFocus()
		local FocusId = Focus and Focus.GetID and Focus:GetID()
		if FocusId and FocusId ~= Slot and Record.Equip[FocusId] and Record.Equip[FocusId] ~= "0:0" then
			GearScore_TransmogSetDebug("slot fallback "..tostring(Slot).." -> focus id "..tostring(FocusId))
			Slot = FocusId
			RealItemCode = Record.Equip[Slot]
		end
	end
	if not RealItemCode or RealItemCode == "0:0" then return; end
	GearScore_TransmogSetDebug("tooltip "..Name.." slot "..tostring(Slot).." real="..tostring(RealItemCode).." source="..tostring(Record.Scanned))
	GearScore_FixRecordItemTooltip(Tooltip, Record, Slot, Name)
end

function GearScore_PrimeServerItemCache(ItemCode)
	if not ItemCode or ItemCode == "0:0" then return; end
	if not GS_ServerItemTooltip then
		GS_ServerItemTooltip = CreateFrame("GameTooltip", "GS_ServerItemTooltip", UIParent, "GameTooltipTemplate")
		GS_ServerItemTooltip:SetOwner(UIParent, "ANCHOR_NONE")
	end
	GS_ServerItemTooltip:SetHyperlink("item:"..ItemCode)
end

function GearScore_QueueServerRecordRetry(Name, Target, EquipCodes, ScanSource, ServerStats, ServerMeta)
	if not Name or not EquipCodes then return; end
	if not GS_ServerRetryQueue then GS_ServerRetryQueue = {}; end

	local Retries = 1
	if GS_ServerRetryQueue[Name] then Retries = (GS_ServerRetryQueue[Name].Retries or 0) + 1; end
	GS_ServerRetryQueue[Name] = { ["Name"] = Name, ["Target"] = Target, ["EquipCodes"] = EquipCodes, ["ScanSource"] = ScanSource, ["ServerStats"] = ServerStats, ["ServerMeta"] = ServerMeta, ["Retries"] = Retries }

	if not GS_ServerRetryFrame then
		GS_ServerRetryFrame = CreateFrame("Frame", "GS_ServerRetryFrame")
		GS_ServerRetryFrame.Time = 0
		GS_ServerRetryFrame:SetScript("OnUpdate", function(self, elapsed)
			self.Time = self.Time + elapsed
			if self.Time < 0.5 then return; end
			self.Time = 0
			if not GS_ServerRetryQueue then self:Hide(); return; end

			for RetryName, RetryData in pairs(GS_ServerRetryQueue) do
				if RetryData.Retries > 4 then
					GS_ServerRetryQueue[RetryName] = nil
				else
					if GearScore_BuildRecordFromItemCodes(RetryData.Name, RetryData.Target, RetryData.EquipCodes, RetryData.ScanSource, true, RetryData.ServerStats, RetryData.ServerMeta) then
						if ( GS_DisplayPlayer == RetryName ) and ( GS_DisplayFrame:IsVisible() ) then GearScore_DisplayUnit(RetryName, 1); end
						GS_ServerRetryQueue[RetryName] = nil
					else
						RetryData.Retries = RetryData.Retries + 1
					end
				end
			end

			local HasEntries = nil
			for RetryName, RetryData in pairs(GS_ServerRetryQueue) do HasEntries = 1; break; end
			if not HasEntries then self:Hide(); end
		end)
	end

	GS_ServerRetryFrame:Show()
end

function GearScore_GetUnitTokenByName(Name)
	if not Name then return nil; end
	if UnitName("target") == Name then return "target"; end
	if UnitName("mouseover") == Name then return "mouseover"; end
	if UnitName("player") == Name then return "player"; end
	return nil
end

function GearScore_NormalizeName(Name)
	if not Name then return UnitName("player"); end
	Name = string.gsub(Name, "^%s+", "")
	Name = string.gsub(Name, "%s+$", "")
	if Name == "" then return UnitName("player"); end
	if UnitName("player") and strlower(UnitName("player")) == strlower(Name) then return UnitName("player"); end
	if UnitName("target") and strlower(UnitName("target")) == strlower(Name) then return UnitName("target"); end
	if UnitName("mouseover") and strlower(UnitName("mouseover")) == strlower(Name) then return UnitName("mouseover"); end
	if GS_Data and GS_Data[GetRealmName()] and GS_Data[GetRealmName()].Players then
		for PlayerName, Record in pairs(GS_Data[GetRealmName()].Players) do
			if PlayerName and strlower(PlayerName) == strlower(Name) then
				return PlayerName
			end
		end
	end
	return Name
end

function GearScore_RoundStat(Value, Digits)
	if not Value then return 0; end
	local Multiplier = 10 ^ (Digits or 0)
	return floor((Value * Multiplier) + 0.5) / Multiplier
end

function GearScore_FormatStatValue(Value, IsPercent, Digits)
	if Value == nil then return "-"; end
	if type(Value) == "string" then
		if Value == "0-0" then return "Немає"; end
		return Value
	end
	if Digits then
		local Rounded = GearScore_RoundStat(Value, Digits)
		return string.format("%."..Digits.."f", Rounded)
	end
	if IsPercent then
		local Rounded = GearScore_RoundStat(Value, 2)
		return string.format("%.2f%%", Rounded)
	end
	return tostring(floor((Value or 0) + 0.5))
end

function GearScore_BuildStatsColumn(Stats, Column)
	if not Stats then return { { Label = "|cffff8080Очікування даних...|r", Value = "" } }; end

	local Rows = {}
	for _, Entry in ipairs(Column) do
		tinsert(Rows, {
			Label = "|cffffd100"..Entry.Label..":|r",
			Value = GearScore_FormatStatValue(Stats[Entry.Key], Entry.Percent, Entry.Digits)
		})
	end
	return Rows
end

function GearScore_GetDisplayClass(Name, UnitToken)
	if UnitToken and UnitExists(UnitToken) and UnitIsPlayer(UnitToken) then
		local _, EnglishClass = UnitClass(UnitToken)
		return EnglishClass
	end

	if GS_Data and GS_Data[GetRealmName()] and GS_Data[GetRealmName()].Players and GS_Data[GetRealmName()].Players[Name] then
		local Record = GS_Data[GetRealmName()].Players[Name]
		local ClassName = GS_Classes[Record.Class]
		if ClassName == "Death Knight" then return "DEATHKNIGHT"; end
		if ClassName == "Warrior" then return "WARRIOR"; end
		if ClassName == "Paladin" then return "PALADIN"; end
		if ClassName == "Hunter" then return "HUNTER"; end
		if ClassName == "Rogue" then return "ROGUE"; end
		if ClassName == "Priest" then return "PRIEST"; end
		if ClassName == "Shaman" then return "SHAMAN"; end
		if ClassName == "Mage" then return "MAGE"; end
		if ClassName == "Warlock" then return "WARLOCK"; end
		if ClassName == "Druid" then return "DRUID"; end
	end

	return nil
end

function GearScore_GetCombatStatColumn(EnglishClass, Stats)
	if EnglishClass == "HUNTER" then return GS_ServerStatsRanged; end
	if EnglishClass == "MAGE" or EnglishClass == "PRIEST" or EnglishClass == "WARLOCK" then return GS_ServerStatsCaster; end

	if EnglishClass == "SHAMAN" or EnglishClass == "DRUID" or EnglishClass == "PALADIN" then
		local SpellPower = (Stats and Stats.spellpower) or 0
		local AttackPower = (Stats and Stats.ap) or 0
		local RangedAttackPower = (Stats and Stats.ranged_ap) or 0
		local Intellect = (Stats and Stats.intellect) or 0
		local Strength = (Stats and Stats.strength) or 0
		local Agility = (Stats and Stats.agility) or 0

		if (SpellPower > AttackPower and SpellPower > RangedAttackPower) or (Intellect > Strength and Intellect > Agility and SpellPower > 0) then
			return GS_ServerStatsCaster
		end
	end

	return GS_ServerStatsMelee
end

function GearScore_GetStatsProfileRows(ProfileKey)
	if ProfileKey == "primary" then return GS_ServerStatColumns[1]; end
	if ProfileKey == "melee" then return GS_ServerStatsMelee; end
	if ProfileKey == "ranged" then return GS_ServerStatsRanged; end
	if ProfileKey == "caster" then return GS_ServerStatsCaster; end
	if ProfileKey == "defense" then return GS_ServerStatsDefense; end
	return GS_ServerStatsMelee
end

function GearScore_GetDefaultStatsProfile(EnglishClass, Stats)
	if EnglishClass == "HUNTER" then return "ranged"; end
	if EnglishClass == "MAGE" or EnglishClass == "PRIEST" or EnglishClass == "WARLOCK" then return "caster"; end
	if EnglishClass == "SHAMAN" or EnglishClass == "DRUID" or EnglishClass == "PALADIN" then
		local CombatRows = GearScore_GetCombatStatColumn(EnglishClass, Stats)
		if CombatRows == GS_ServerStatsCaster then return "caster"; end
	end
	return "melee"
end

function GearScore_ApplyStatsProfile(ProfileKey)
	GS_ServerStatsSelectedProfile = ProfileKey
	if GS_DisplayPlayer and GS_DisplayFrame and GS_DisplayFrame:IsVisible() then
		GearScore_SetDisplayStats(GS_DisplayPlayer, GearScore_GetUnitTokenByName(GS_DisplayPlayer))
	end
end

function GearScore_InitializeStatsDropDown(EnglishClass, Stats)
	if not GS_ServerStatsDropDown then
		GS_ServerStatsDropDown = CreateFrame("Frame", "GS_ServerStatsDropDown", GS_GearFrame, "UIDropDownMenuTemplate")
		GS_ServerStatsDropDown:SetPoint("TOPLEFT", GS_ServerStatsBackground, "TOPLEFT", -14, 34)
		GS_ServerStatsDropDown:SetToplevel(true)
		GS_ServerStatsDropDown:SetFrameStrata("DIALOG")
		GS_ServerStatsDropDown:SetFrameLevel(80)
	end

	GS_ServerStatsDropDown:Show()
	GS_ServerStatsDropDown:EnableMouse(true)
	GS_ServerStatsDropDown:Raise()

	GS_ServerStatsTitle:Hide()

	if GS_ServerStatsDropDownInitialized then
		local Selected = GS_ServerStatsSelectedProfile or GearScore_GetDefaultStatsProfile(EnglishClass, Stats)
		UIDropDownMenu_SetSelectedValue(GS_ServerStatsDropDown, Selected)
		for _, Profile in ipairs(GS_ServerStatsProfiles) do
			if Profile.Key == Selected then
				UIDropDownMenu_SetText(GS_ServerStatsDropDown, Profile.Label)
				break
			end
		end
		return
	end

	UIDropDownMenu_SetWidth(GS_ServerStatsDropDown, 190)
	UIDropDownMenu_Initialize(GS_ServerStatsDropDown, function(self, level)
		for _, Profile in ipairs(GS_ServerStatsProfiles) do
			local Info = UIDropDownMenu_CreateInfo()
			Info.text = Profile.Label
			Info.value = Profile.Key
			Info.func = function()
				UIDropDownMenu_SetSelectedValue(GS_ServerStatsDropDown, Profile.Key)
				UIDropDownMenu_SetText(GS_ServerStatsDropDown, Profile.Label)
				GearScore_ApplyStatsProfile(Profile.Key)
			end
			UIDropDownMenu_AddButton(Info, level)
		end
	end)
	GS_ServerStatsDropDownInitialized = true
	GearScore_InitializeStatsDropDown(EnglishClass, Stats)
end

function GearScore_BuildStatsText(Stats, EnglishClass)
	local Rows = {}
	local ProfileKey = GS_ServerStatsSelectedProfile or GearScore_GetDefaultStatsProfile(EnglishClass, Stats)
	local ProfileRows = GearScore_BuildStatsColumn(Stats, GearScore_GetStatsProfileRows(ProfileKey))
	for _, Row in ipairs(ProfileRows) do
		tinsert(Rows, Row)
	end

	return Rows
end

function GearScore_EnsureStatsRows()
	if GS_ServerStatRowLabels then return; end

	GS_ServerStatsLabels:Hide()
	GS_ServerStatsValues:Hide()

	GS_ServerStatRowLabels = {}
	GS_ServerStatRowValues = {}
	for i = 1, 16 do
		local Label = GS_GearFrame:CreateFontString("GS_ServerStatsRowLabel"..i, "OVERLAY", "GameFontHighlight")
		Label:SetWidth(118)
		Label:SetHeight(14)
		Label:SetJustifyH("LEFT")
		Label:SetJustifyV("TOP")
		if i == 1 then
			Label:SetPoint("TOPLEFT", GS_ServerStatsBackground, "TOPLEFT", 14, -12)
		else
			Label:SetPoint("TOPLEFT", GS_ServerStatRowLabels[i - 1], "BOTTOMLEFT", 0, -1)
		end

		local Value = GS_GearFrame:CreateFontString("GS_ServerStatsRowValue"..i, "OVERLAY", "GameFontHighlight")
		Value:SetWidth(78)
		Value:SetHeight(14)
		Value:SetJustifyH("RIGHT")
		Value:SetJustifyV("TOP")
		Value:SetPoint("TOPRIGHT", GS_ServerStatsBackground, "TOPRIGHT", -14, -12 - ((i - 1) * 15))

		GS_ServerStatRowLabels[i] = Label
		GS_ServerStatRowValues[i] = Value
	end
end

function GearScore_ParseServerStats(Field)
	if not Field or string.sub(Field, 1, 6) ~= "STATS@" then return nil; end

	local Stats = {}
	for Pair in string.gmatch(string.sub(Field, 7), "[^;]+") do
		local _, _, Key, RawValue = string.find(Pair, "^([^=]+)=(.+)$")
		if Key and RawValue then
			Stats[Key] = tonumber(RawValue) or RawValue
		end
	end

	if not next(Stats) then return nil; end
	return Stats
end

function GearScore_ParseServerMeta(Field)
	if not Field or string.sub(Field, 1, 5) ~= "META@" then return nil; end

	local DecodeMetaValue = function(Value)
		if not Value then return Value; end
		Value = string.gsub(Value, "%%(%x%x)", function(Hex)
			return string.char(tonumber(Hex, 16))
		end)
		return Value
	end

	local Meta = {}
	for Pair in string.gmatch(string.sub(Field, 6), "[^;]+") do
		local _, _, Key, RawValue = string.find(Pair, "^([^=]+)=(.*)$")
		if Key and RawValue then
			RawValue = DecodeMetaValue(RawValue)
			Meta[Key] = tonumber(RawValue) or RawValue
		end
	end

	if not next(Meta) then return nil; end
	return Meta
end

function GearScore_DecodeServerSetText(Text)
	if not Text then return ""; end
	Text = string.gsub(Text, "%%(%x%x)", function(Hex)
		return string.char(tonumber(Hex, 16))
	end)
	return Text
end

function GearScore_SplitServerField(Entry)
	local Parts = {}
	if not Entry then return Parts; end
	for Part in string.gmatch(Entry.."~", "([^~]*)~") do
		tinsert(Parts, Part)
	end
	return Parts
end

function GearScore_ParseServerSets(Field)
	if not Field or string.sub(Field, 1, 5) ~= "SETS@" then return nil; end

	local Sets = { BySlot = {}, BySignature = {} }
	for Entry in string.gmatch(string.sub(Field, 6), "[^^]+") do
		local Parts = GearScore_SplitServerField(Entry)
		local Slot, SetId, RowName, FullName, Signature = Parts[1], Parts[2], Parts[3], Parts[4], Parts[5]
		Slot = tonumber(Slot)
		SetId = tonumber(SetId)
		if Slot and SetId then
			RowName = RowName and GearScore_DecodeServerSetText(RowName) or nil
			FullName = FullName and GearScore_DecodeServerSetText(FullName) or RowName
			Signature = Signature ~= "" and Signature or nil
			if not Sets[SetId] then Sets[SetId] = { Rows = {}, NormRows = {}, FullNames = {}, NormFullNames = {}, Signature = Signature }; end
			local Row = { Slot = Slot, SetId = SetId, RowName = RowName, FullName = FullName, Signature = Signature }
			GearScore_TransmogSetDebug("parse SETS slot="..tostring(Slot).." setId="..tostring(SetId).." sig="..GearScore_ShortSignature(Signature).." row='"..tostring(RowName).."' full='"..tostring(FullName).."'")
			if RowName then
				Sets[SetId].Rows[RowName] = Row
				local NormRow = GearScore_NormalizeSetItemName(RowName)
				if NormRow then Sets[SetId].NormRows[NormRow] = Row; end
			end
			if FullName then
				Sets[SetId].FullNames[FullName] = Row
				local NormFullName = GearScore_NormalizeSetItemName(FullName)
				if NormFullName then Sets[SetId].NormFullNames[NormFullName] = Row; end
			end
			Sets.BySlot[Slot] = Row
			if Signature then
				if not Sets.BySignature[Signature] then Sets.BySignature[Signature] = {}; end
				Sets.BySignature[Signature][Slot] = Row
			end
		end
	end

	if not next(Sets.BySlot) then return nil; end
	return Sets
end

function GearScore_ParseServerSetMembers(Field)
	if not Field or string.sub(Field, 1, 5) ~= "MEMB@" then return nil; end

	local Members = { BySet = {}, BySignature = {} }
	for Entry in string.gmatch(string.sub(Field, 6), "[^^]+") do
		local Parts = GearScore_SplitServerField(Entry)
		local SetId = tonumber(Parts[1])
		local Signature, Slot, RowName = Parts[2], tonumber(Parts[3]), Parts[4]
		if SetId and tonumber(Parts[2]) and not Parts[3] then
			Signature = nil
			Slot = tonumber(Parts[2])
			RowName = nil
		end
		if SetId and Slot then
			RowName = RowName and GearScore_DecodeServerSetText(RowName) or nil
			Signature = Signature ~= "" and Signature or nil
			local Row = { SetId = SetId, Signature = Signature, Slot = Slot, RowName = RowName }
			GearScore_TransmogSetDebug("parse MEMB setId="..tostring(SetId).." slot="..tostring(Slot).." sig="..GearScore_ShortSignature(Signature).." row='"..tostring(RowName).."'")
			if not Members.BySet[SetId] then Members.BySet[SetId] = { Rows = {}, NormRows = {}, BySlot = {}, Ordered = {}, OrderedSlots = {} }; end
			if RowName then Members.BySet[SetId].Rows[RowName] = Row; end
			tinsert(Members.BySet[SetId].Ordered, Row)
			if not Members.BySet[SetId].BySlot[Slot] then
				Members.BySet[SetId].BySlot[Slot] = Row
				tinsert(Members.BySet[SetId].OrderedSlots, Row)
			end
			if RowName then
				local NormRow = GearScore_NormalizeSetItemName(RowName)
				if NormRow then Members.BySet[SetId].NormRows[NormRow] = Row; end
			end
			if Signature then
				if not Members.BySignature[Signature] then Members.BySignature[Signature] = {}; end
				if not Members.BySignature[Signature][SetId] then Members.BySignature[Signature][SetId] = Members.BySet[SetId]; end
			end
		end
	end

	if not next(Members.BySet) then return nil; end
	return Members
end

function GearScore_AttachServerSetMembers(Sets, Members)
	if not Sets or not Members then return Sets; end
	Sets.Members = Members
	for SetId, SetData in pairs(Sets) do
		if type(SetId) == "number" and Members.BySet[SetId] then
			SetData.Members = Members.BySet[SetId]
			local Count = 0
			for _, _ in pairs(SetData.Members.BySlot) do Count = Count + 1; end
			GearScore_TransmogSetDebug("attach members setId="..tostring(SetId).." count="..tostring(Count))
		end
	end
	return Sets
end

function GearScore_ParseServerSockets(Field)
	if not Field or string.sub(Field, 1, 5) ~= "SOCK@" then return nil; end

	local Sockets = { BySlot = {} }
	for Entry in string.gmatch(string.sub(Field, 6), "[^^]+") do
		local Slot, SocketBonusActive, MetaActive = string.match(Entry, "^(%d+)~([%-0-9]+)~([%-0-9]+)$")
		Slot = tonumber(Slot)
		SocketBonusActive = tonumber(SocketBonusActive)
		MetaActive = tonumber(MetaActive)
		if Slot then
			Sockets.BySlot[Slot] = { SocketBonusActive = SocketBonusActive or 0, MetaActive = MetaActive or -1 }
		end
	end

	if not next(Sockets.BySlot) then return nil; end
	return Sockets
end

function GearScore_SeedServerRecord(Name, Equip, ServerStats, ServerMeta, ServerSets, ServerSockets)
	if not Name or not Equip or not ServerMeta then return; end
	if not GS_Data or not GS_Data[GetRealmName()] or not GS_Data[GetRealmName()].Players then return; end

	local ExistingRecord = GS_Data[GetRealmName()].Players[Name] or {}
	local RaceEnglish = GS_ServerMetaRaceMap[tonumber(ServerMeta.race_id or 0)] or ExistingRecord.Race or "Human"
	local ClassEnglish = GS_ServerMetaClassMap[tonumber(ServerMeta.class_id or 0)] or ExistingRecord.Class or "Warrior"

	GS_Data[GetRealmName()].Players[Name] = {
		["Name"] = Name,
		["GearScore"] = ExistingRecord.GearScore or 0,
		["PVP"] = 1,
		["Level"] = ServerMeta.level or ExistingRecord.Level or 0,
		["Faction"] = ServerMeta.faction or ExistingRecord.Faction or "A",
		["Sex"] = ServerMeta.sex or ExistingRecord.Sex or 1,
		["Guild"] = ServerMeta.guild or ExistingRecord.Guild or "*",
		["Race"] = GS_Races[RaceEnglish] or ExistingRecord.Race or RaceEnglish,
		["Class"] = GS_Classes[ClassEnglish] or ExistingRecord.Class or ClassEnglish,
		["Spec"] = ExistingRecord.Spec or 1,
		["Location"] = ServerMeta.location or ExistingRecord.Location or "Unknown Location",
		["Scanned"] = "Server",
		["Date"] = GearScore_GetTimeStamp(),
		["Average"] = ExistingRecord.Average or 0,
		["Equip"] = Equip,
		["ServerCachedAt"] = GetTime(),
		["Stats"] = ServerStats or ExistingRecord.Stats,
		["Sets"] = ServerSets or ExistingRecord.Sets,
		["Sockets"] = ServerSockets or ExistingRecord.Sockets,
		["ServerBridgeVersion"] = GS_ServerBridgeVersion
	}
end

function GearScore_GetPlayerLocalStats(UnitToken)
	if UnitToken ~= "player" then return nil; end

	local _, EffectiveArmor = UnitArmor("player")
	local BaseDefense, EffectiveDefense = UnitDefense("player")
	local BaseAttackPower, PositiveAttackPower, NegativeAttackPower = UnitAttackPower("player")
	local BaseRangedAttackPower, PositiveRangedAttackPower, NegativeRangedAttackPower = UnitRangedAttackPower("player")
	local MainSpeed = UnitAttackSpeed("player") or 0
	local LowDamage, HighDamage = UnitDamage("player")
	local RangedSpeed, LowRangedDamage, HighRangedDamage = UnitRangedDamage("player")
	local MaxSpellPower = 0
	local MaxSpellCrit = 0
	local Strength = select(2, UnitStat("player", 1)) or 0
	local Agility = select(2, UnitStat("player", 2)) or 0
	local Stamina = select(2, UnitStat("player", 3)) or 0
	local Intellect = select(2, UnitStat("player", 4)) or 0
	local Spirit = select(2, UnitStat("player", 5)) or 0
	local BaseManaRegen, CastingManaRegen = GetManaRegen()
	local HealingBonus = GetSpellBonusHealing() or 0

	for School = 2, 7 do
		local SpellPower = GetSpellBonusDamage(School) or 0
		if SpellPower > MaxSpellPower then MaxSpellPower = SpellPower; end
		local SpellCrit = GetSpellCritChance(School) or 0
		if SpellCrit > MaxSpellCrit then MaxSpellCrit = SpellCrit; end
	end

	return {
		strength = Strength,
		agility = Agility,
		stamina = Stamina,
		intellect = Intellect,
		spirit = Spirit,
		armor = EffectiveArmor or 0,
		defense = EffectiveDefense or BaseDefense or 0,
		dodge = GetDodgeChance() or 0,
		parry = GetParryChance() or 0,
		block = GetBlockChance() or 0,
		resilience = GetCombatRating(CR_CRIT_TAKEN_MELEE) or 0,
		damage = string.format("%d-%d", floor((LowDamage or 0) + 0.5), floor((HighDamage or 0) + 0.5)),
		speed = GearScore_RoundStat(MainSpeed or 0, 2),
		ap = (BaseAttackPower or 0) + (PositiveAttackPower or 0) + (NegativeAttackPower or 0),
		ranged_damage = ((LowRangedDamage or 0) > 0 or (HighRangedDamage or 0) > 0) and string.format("%d-%d", floor((LowRangedDamage or 0) + 0.5), floor((HighRangedDamage or 0) + 0.5)) or "Немає",
		ranged_speed = GearScore_RoundStat(RangedSpeed or 0, 2),
		ranged_ap = (BaseRangedAttackPower or 0) + (PositiveRangedAttackPower or 0) + (NegativeRangedAttackPower or 0),
		crit = GetCritChance() or 0,
		crit_ranged = GetRangedCritChance() or 0,
		crit_spell = MaxSpellCrit,
		hit = GetCombatRatingBonus(CR_HIT_MELEE) or 0,
		hit_ranged = GetCombatRatingBonus(CR_HIT_RANGED) or 0,
		hit_spell = GetCombatRatingBonus(CR_HIT_SPELL) or 0,
		expertise = GetExpertise() or 0,
		haste = GetCombatRatingBonus(CR_HASTE_MELEE) or 0,
		haste_ranged = GetCombatRatingBonus(CR_HASTE_RANGED) or 0,
		haste_spell = GetCombatRatingBonus(CR_HASTE_SPELL) or 0,
		spellpower = MaxSpellPower,
		healpower = HealingBonus,
		mp5 = floor(((BaseManaRegen or 0) * 5)),
		mp5_casting = floor(((CastingManaRegen or 0) * 5)),
	}
end

function GearScore_SetDisplayStats(Name, UnitToken)
	local Stats = nil
	local Record = nil
	local EnglishClass = GearScore_GetDisplayClass(Name, UnitToken)
	if GS_Data and GS_Data[GetRealmName()] and GS_Data[GetRealmName()].Players then
		Record = GS_Data[GetRealmName()].Players[Name]
	end

	for i = 1, 4 do
		_G["GS_SpecBar"..i]:Hide()
	end

	if UnitToken == "player" then
		Stats = GearScore_GetPlayerLocalStats("player")
	elseif Record and Record.Stats then
		Stats = Record.Stats
	end

	GearScore_InitializeStatsDropDown(EnglishClass, Stats)
	local Rows = GearScore_BuildStatsText(Stats, EnglishClass)
	GearScore_EnsureStatsRows()
	for i = 1, 16 do
		local Row = Rows[i]
		if Row then
			GS_ServerStatRowLabels[i]:SetText(Row.Label)
			GS_ServerStatRowValues[i]:SetText(Row.Value)
			GS_ServerStatRowLabels[i]:Show()
			GS_ServerStatRowValues[i]:Show()
		else
			GS_ServerStatRowLabels[i]:Hide()
			GS_ServerStatRowValues[i]:Hide()
		end
	end
end

function GearScore_BuildRecordFromItemCodes(Name, Target, EquipCodes, ScanSource, FromRetry, ServerStats, ServerMeta)
	if not Name or not EquipCodes then return; end

	if not Target then Target = GearScore_GetUnitTokenByName(Name); end
	local ExistingRecord = nil
	if GS_Data and GS_Data[GetRealmName()] and GS_Data[GetRealmName()].Players then ExistingRecord = GS_Data[GetRealmName()].Players[Name]; end

	local GearScore = 0; local ItemCount = 0; local LevelTotal = 0; local TitanGrip = 1; local TempEquip = {}
	local MissingItems = 0
	local PlayerEnglishClass = nil
	if Target and UnitExists(Target) and UnitIsPlayer(Target) then
		local PlayerClass = nil
		PlayerClass, PlayerEnglishClass = UnitClass(Target)
	elseif ExistingRecord and ExistingRecord.Class then
		PlayerEnglishClass = GS_Classes[ExistingRecord.Class]
	end

	local MainHandLink = GearScore_GetItemLinkFromCode(EquipCodes[16])
	local OffHandLink = GearScore_GetItemLinkFromCode(EquipCodes[17])
	if EquipCodes[16] and EquipCodes[16] ~= "0:0" and not MainHandLink then MissingItems = MissingItems + 1; GearScore_PrimeServerItemCache(EquipCodes[16]); end
	if EquipCodes[17] and EquipCodes[17] ~= "0:0" and not OffHandLink then MissingItems = MissingItems + 1; GearScore_PrimeServerItemCache(EquipCodes[17]); end
	if MainHandLink and OffHandLink then
		local ItemName, ItemLink, ItemRarity, ItemLevel, ItemMinLevel, ItemType, ItemSubType, ItemStackCount, ItemEquipLoc = GetItemInfo(MainHandLink)
		if ( ItemEquipLoc == "INVTYPE_2HWEAPON" ) then TitanGrip = 0.5; end
	end

	if OffHandLink then
		local ItemName, ItemLink, ItemRarity, ItemLevel, ItemMinLevel, ItemType, ItemSubType, ItemStackCount, ItemEquipLoc = GetItemInfo(OffHandLink)
		local TempScore = 0
		if ( ItemEquipLoc == "INVTYPE_2HWEAPON" ) then TitanGrip = 0.5; end
		TempScore, ItemLevel = GearScore_GetItemScore(OffHandLink);
		if ( PlayerEnglishClass == "HUNTER" ) then TempScore = TempScore * 0.3164; end
		GearScore = GearScore + TempScore * TitanGrip; ItemCount = ItemCount + 1; LevelTotal = LevelTotal + ItemLevel
		TempEquip[17] = EquipCodes[17]
	else
		TempEquip[17] = "0:0"
	end

	for i = 1, 18 do
		if ( i ~= 4 ) and ( i ~= 17 ) then
			local ItemCode = EquipCodes[i]
			local ItemLink = GearScore_GetItemLinkFromCode(ItemCode)
			if ( ItemLink ) then
				local TempScore = 0; local ItemLevel = 0
				TempScore, ItemLevel = GearScore_GetItemScore(ItemLink);
				if ( i == 16 ) and ( PlayerEnglishClass == "HUNTER" ) then TempScore = TempScore * 0.3164; end
				if ( i == 18 ) and ( PlayerEnglishClass == "HUNTER" ) then TempScore = TempScore * 5.3224; end
				if ( i == 16 ) then TempScore = TempScore * TitanGrip; end
				GearScore = GearScore + TempScore; ItemCount = ItemCount + 1; LevelTotal = LevelTotal + ItemLevel
				TempEquip[i] = ItemCode
			else
				if ItemCode and ItemCode ~= "0:0" then MissingItems = MissingItems + 1; GearScore_PrimeServerItemCache(ItemCode); end
				TempEquip[i] = "0:0"
			end
		end
	end
	TempEquip[4] = "0:0"

	if MissingItems > 0 then
		GearScore_QueueServerRecordRetry(Name, Target, EquipCodes, ScanSource, ServerStats, ServerMeta)
		return nil
	end

	if not ( GearScore > 0 ) then return; end

	local RaceEnglish = nil; local ClassEnglish = nil; local currentzone = "Unknown Location"; local GuildName = "*"; local Level = 0; local Faction = nil; local Sex = 1
	if Target and UnitExists(Target) and UnitIsPlayer(Target) then
		local Dummy = nil
		Dummy, RaceEnglish = UnitRace(Target);
		Dummy, ClassEnglish = UnitClass(Target);
		currentzone = GetZoneText()
		if not ( GS_Zones[currentzone] ) then currentzone = "Unknown Location"; end
		GuildName = GetGuildInfo(Target); if not ( GuildName ) then GuildName = "*"; end
		Level = UnitLevel(Target)
		Faction = GS_Factions[UnitFactionGroup(Target)]
		Sex = UnitSex(Target)
	elseif ExistingRecord then
		RaceEnglish = GS_Races[ExistingRecord.Race]
		ClassEnglish = GS_Classes[ExistingRecord.Class]
		currentzone = ExistingRecord.Location
		GuildName = ExistingRecord.Guild
		Level = ExistingRecord.Level
		Faction = ExistingRecord.Faction
		Sex = ExistingRecord.Sex
	elseif ServerMeta then
		RaceEnglish = GS_ServerMetaRaceMap[tonumber(ServerMeta.race_id or 0)] or ServerMeta.race
		ClassEnglish = GS_ServerMetaClassMap[tonumber(ServerMeta.class_id or 0)] or ServerMeta.class
		currentzone = ServerMeta.location or currentzone
		GuildName = ServerMeta.guild or GuildName
		Level = ServerMeta.level or Level
		Faction = ServerMeta.faction or Faction
		Sex = ServerMeta.sex or Sex
	end

	if not RaceEnglish or not ClassEnglish or not Level or not Faction then return; end
	GS_Data[GetRealmName()].Players[Name] = { ["Name"] = Name, ["GearScore"] = floor(GearScore), ["PVP"] = 1, ["Level"] = Level, ["Faction"] = Faction, ["Sex"] = Sex, ["Guild"] = GuildName,
	["Race"] = GS_Races[RaceEnglish], ["Class"] =  GS_Classes[ClassEnglish], ["Spec"] = 1, ["Location"] = currentzone, ["Scanned"] = ScanSource or "Server", ["Date"] = GearScore_GetTimeStamp(), ["Average"] = floor((LevelTotal / ItemCount)+0.5), ["Equip"] = TempEquip, ["ServerCachedAt"] = GetTime(), ["Stats"] = ServerStats or (ExistingRecord and ExistingRecord.Stats), ["Sets"] = ExistingRecord and ExistingRecord.Sets, ["Sockets"] = ExistingRecord and ExistingRecord.Sockets, ["ServerBridgeVersion"] = GS_ServerBridgeVersion}
	return true
end

function GearScore_HandleServerItemReply(Message, Sender)
	if not Message then return; end
	local Fields = {}
	for Value in string.gmatch(Message, "[^$]+") do tinsert(Fields, Value); end
	if not Fields[1] then return; end

	local Name = Fields[1]
	GearScore_TransmogSetDebug("server reply for "..Name.." from "..tostring(Sender).." len="..tostring(string.len(Message)).." fields="..tostring(table.getn(Fields)))
	local Equip = {}
	for i = 1, 18 do
		Equip[i] = Fields[i + 1] or "0:0"
	end
	Equip[4] = "0:0"
	local ServerStats = nil
	local ServerMeta = nil
	local ServerSets = nil
	local ServerSetMembers = nil
	local ServerSockets = nil
	for i = 20, table.getn(Fields) do
		if GS_TransmogSetVerboseDebug then
			local Prefix = string.match(Fields[i], "^([^@]+)@")
			if Prefix then
				GearScore_TransmogSetVerbose("server field#"..tostring(i).." "..tostring(Prefix).." len="..tostring(string.len(Fields[i])).." head='"..tostring(string.sub(Fields[i], 1, 80)).."'")
			end
		end
		ServerStats = GearScore_ParseServerStats(Fields[i]) or ServerStats
		ServerMeta = GearScore_ParseServerMeta(Fields[i]) or ServerMeta
		ServerSets = GearScore_ParseServerSets(Fields[i]) or ServerSets
		ServerSetMembers = GearScore_ParseServerSetMembers(Fields[i]) or ServerSetMembers
		ServerSockets = GearScore_ParseServerSockets(Fields[i]) or ServerSockets
	end
	ServerSets = GearScore_AttachServerSetMembers(ServerSets, ServerSetMembers)
	if ServerSets and ServerSets.BySlot then
		local SetRows = 0
		for _, _ in pairs(ServerSets.BySlot) do SetRows = SetRows + 1; end
		GearScore_TransmogSetDebug("server set rows "..tostring(SetRows))
		if ServerSets.BySignature then
			for Signature, Slots in pairs(ServerSets.BySignature) do
				local SlotList = ""
				for Slot, Row in pairs(Slots) do
					SlotList = SlotList..(SlotList ~= "" and "," or "")..tostring(Slot)..":"..tostring(Row and Row.RowName)
				end
				GearScore_TransmogSetVerbose("BySignature "..GearScore_ShortSignature(Signature).." slots="..SlotList)
			end
		end
	else
		GearScore_TransmogSetDebug("server set rows none")
	end
	if ServerSetMembers and ServerSetMembers.BySet then
		local MemberSets = 0
		local MemberRows = 0
		for _, MemberSet in pairs(ServerSetMembers.BySet) do
			MemberSets = MemberSets + 1
			for _, _ in pairs(MemberSet.BySlot) do MemberRows = MemberRows + 1; end
		end
		GearScore_TransmogSetDebug("server member sets "..tostring(MemberSets).." rows "..tostring(MemberRows))
		for SetId, MemberSet in pairs(ServerSetMembers.BySet) do
			local SlotList = ""
			for Index, Row in ipairs(MemberSet.OrderedSlots or {}) do
				SlotList = SlotList..(SlotList ~= "" and "," or "")..tostring(Index).."=>"..tostring(Row.Slot)..":"..tostring(Row.RowName)
			end
			GearScore_TransmogSetVerbose("MEMB setId="..tostring(SetId).." orderedSlots="..SlotList)
		end
	else
		GearScore_TransmogSetDebug("server member sets none")
	end
	GearScore_SeedServerRecord(Name, Equip, ServerStats, ServerMeta, ServerSets, ServerSockets)
	GearScore_BuildRecordFromItemCodes(Name, GearScore_GetUnitTokenByName(Name), Equip, "Server", nil, ServerStats, ServerMeta)
	if ServerSets and GS_Data and GS_Data[GetRealmName()] and GS_Data[GetRealmName()].Players and GS_Data[GetRealmName()].Players[Name] then
		GS_Data[GetRealmName()].Players[Name].Sets = ServerSets
	end
	if ServerSockets and GS_Data and GS_Data[GetRealmName()] and GS_Data[GetRealmName()].Players and GS_Data[GetRealmName()].Players[Name] then
		GS_Data[GetRealmName()].Players[Name].Sockets = ServerSockets
	end
	if GS_DisplayPlayer and strlower(GS_DisplayPlayer) == strlower(Name) then GS_DisplayPlayer = Name; end
	if ( GS_DisplayPlayer == Name ) and ( GS_DisplayFrame:IsVisible() ) then GearScore_DisplayUnit(Name, 1); end
end

function GearScore_UpdateSearchBox(Box)
	if not Box then return; end
	if not GS_SBT then GS_SBT = ""; end

	local CurrentText = Box:GetText() or ""
	if CurrentText == GS_SBT then return; end
	GS_SBT = CurrentText

	GearScore_HideDatabase()
	GearScore_DisplayDatabase("Search")
end

function GearScore_RunDatabaseSearch(SortType)
	local Query = GS_SearchXBox and GS_SearchXBox:GetText() or ""
	Query = string.gsub(Query or "", "^%s+", "")
	Query = string.gsub(Query, "%s+$", "")
	GearScore_HideDatabase()
	if Query == "" then
		GearScore_DisplayDatabase(GS_LastDatabaseGroup or (GS_DisplayedGroup ~= "Search" and GS_DisplayedGroup) or "All", SortType or GS_SortedType or "GearScore")
	else
		if GS_DisplayedGroup and GS_DisplayedGroup ~= "Search" then GS_LastDatabaseGroup = GS_DisplayedGroup; end
		GearScore_DisplayDatabase("Search", SortType or "GearScore")
	end
end

function GearScore_RequestOrScan(Name, Target)
	if not Name then return; end

	if Name ~= UnitName("player") then
		GearScore_RequestServerItemData(Name)
	end

	if GearScore_HasAuthoritativeRecord(Name) then
		if GearScore_HasSelfReportedRecord(Name) then GearScore_Request(Name); end
		return
	end

	if GearScore_HasSelfReportedRecord(Name) then
		GearScore_Request(Name)
		return
	end

	if Name ~= UnitName("player") then return; end
	if not Target then return; end
	GearScore_GetScore(Name, Target)
end

function GearScore_StartProfileNotFoundTimer(Name)
	if not Name then return; end
	GS_ProfileLookupName = Name
	if not GS_ProfileLookupFrame then
		GS_ProfileLookupFrame = CreateFrame("Frame", "GS_ProfileLookupFrame")
		GS_ProfileLookupFrame.Elapsed = 0
		GS_ProfileLookupFrame:SetScript("OnUpdate", function(self, elapsed)
			self.Elapsed = (self.Elapsed or 0) + elapsed
			if self.Elapsed < 4 then return; end
			self:Hide()
			local Name = GS_ProfileLookupName
			if not Name or GS_DisplayPlayer ~= Name or not GS_DisplayFrame:IsVisible() then return; end
			if GS_Data and GS_Data[GetRealmName()] and GS_Data[GetRealmName()].Players and GS_Data[GetRealmName()].Players[Name] then return; end
			GS_GearScoreText:SetText("Не знайдено")
			GS_InfoText:SetText("")
			GS_GuildText:SetText("")
			GS_DateText:SetText("")
			GS_AverageText:SetText("")
			GS_LocationText:SetText("")
			GearScore_SetDisplayStats(Name, nil)
		end)
	end
	GS_ProfileLookupFrame.Elapsed = 0
	GS_ProfileLookupFrame:Show()
end

function GearScore_ShouldWaitForServerRecord(Name, UnitToken)
	if not Name or Name == UnitName("player") then return false; end
	if GS_Data and GS_Data[GetRealmName()] and GS_Data[GetRealmName()].Players and GS_Data[GetRealmName()].Players[Name] then return false; end
	if GearScore_HasFreshServerRecord(Name) or GearScore_HasSelfReportedRecord(Name) then return false; end
	if UnitToken and UnitExists(UnitToken) and UnitIsPlayer(UnitToken) then return true; end
	return true
end

function GearScore_GetRecordDisplayRace(Record)
	if not Record or not Record.Race then return ""; end
	return GS_Races[Record.Race] or Record.Race or ""
end

function GearScore_GetRecordDisplayClass(Record)
	if not Record or not Record.Class then return ""; end
	return GS_Classes[Record.Class] or Record.Class or ""
end

function GearScore_GetRecordClassColors(Record)
	local DisplayClass = GearScore_GetRecordDisplayClass(Record)
	if DisplayClass and GS_ClassInfo[DisplayClass] then
		return GS_ClassInfo[DisplayClass].Red, GS_ClassInfo[DisplayClass].Green, GS_ClassInfo[DisplayClass].Blue
	end
	return 1, 0.82, 0
end

function GearScore_GetRecordGuild(Record)
	if not Record or not Record.Guild or Record.Guild == "" or Record.Guild == "*" then return ""; end
	return Record.Guild
end

function GearScore_GetSortableRace(Record)
	return strlower(GearScore_GetRecordDisplayRace(Record) or "")
end

function GearScore_GetSortableClass(Record)
	return strlower(GearScore_GetRecordDisplayClass(Record) or "")
end

function GearScore_GetSortableGuild(Record)
	return strlower(GearScore_GetRecordGuild(Record) or "")
end

function GearScore_NormalizeRosterName(Name)
	if not Name then return nil; end
	Name = tostring(Name)
	Name = string.gsub(Name, "%-.+$", "")
	return Name
end

function GearScore_SameGuildName(Left, Right)
	Left = GearScore_GetRecordGuild({ Guild = Left })
	Right = GearScore_GetRecordGuild({ Guild = Right })
	if Left == "" or Right == "" then return nil; end
	return strlower(Left) == strlower(Right)
end

-------------------------- Get Mouseover Score -----------------------------------
function GearScore_GetScore(Name, Target)
	if ( UnitIsPlayer(Target) ) then
	    local ExistingRecord = GS_Data and GS_Data[GetRealmName()] and GS_Data[GetRealmName()].Players and GS_Data[GetRealmName()].Players[Name]
	    local PlayerClass, PlayerEnglishClass = UnitClass(Target);
		local GearScore = 0; local PVPScore = 0; local ItemCount = 0; local LevelTotal = 0; local TitanGrip = 1; local TempEquip = {}; local TempPVPScore = 0

		if ( GetInventoryItemLink(Target, 16) ) and ( GetInventoryItemLink(Target, 17) ) then
      		local ItemName, ItemLink, ItemRarity, ItemLevel, ItemMinLevel, ItemType, ItemSubType, ItemStackCount, ItemEquipLoc, ItemTexture = GetItemInfo(GetInventoryItemLink(Target, 16))
            local TitanGripGuess = 0
            if ( ItemEquipLoc == "INVTYPE_2HWEAPON" ) then TitanGrip = 0.5; end
		end

		if ( GetInventoryItemLink(Target, 17) ) then
			local ItemName, ItemLink, ItemRarity, ItemLevel, ItemMinLevel, ItemType, ItemSubType, ItemStackCount, ItemEquipLoc, ItemTexture = GetItemInfo(GetInventoryItemLink(Target, 17))
			if ( ItemEquipLoc == "INVTYPE_2HWEAPON" ) then TitanGrip = 0.5; end
			TempScore, ItemLevel = GearScore_GetItemScore(GetInventoryItemLink(Target, 17));
			if ( PlayerEnglishClass == "HUNTER" ) then TempScore = TempScore * 0.3164; end
			GearScore = GearScore + TempScore * TitanGrip;	ItemCount = ItemCount + 1; LevelTotal = LevelTotal + ItemLevel
            TempEquip[17] = GearScore_GetItemCode(ItemLink)
		else
      		TempEquip[17] = "0:0"
		end
		
		for i = 1, 18 do

			if ( i ~= 4 ) and ( i ~= 17 ) then
        		ItemLink = GetInventoryItemLink(Target, i)
				if ( ItemLink ) then
        			local ItemName, ItemLink, ItemRarity, ItemLevel, ItemMinLevel, ItemType, ItemSubType, ItemStackCount, ItemEquipLoc, ItemTexture = GetItemInfo(ItemLink)
     				TempScore, ItemLevel, a, b, c, d, TempPVPScore = GearScore_GetItemScore(ItemLink);
					if ( i == 16 ) and ( PlayerEnglishClass == "HUNTER" ) then TempScore = TempScore * 0.3164; end
					if ( i == 18 ) and ( PlayerEnglishClass == "HUNTER" ) then TempScore = TempScore * 5.3224; end
					if ( i == 16 ) then TempScore = TempScore * TitanGrip; end
					GearScore = GearScore + TempScore;	ItemCount = ItemCount + 1; LevelTotal = LevelTotal + ItemLevel
					--PVPScore = PVPScore + TempPVPScore
     				TempEquip[i] = GearScore_GetItemCode(ItemLink)
				else
				    TempEquip[i] = "0:0"
				end
			end;
		end
		if ( GearScore <= 0 ) and ( Name ~= UnitName("player") ) then
			GearScore = 0; return;
		elseif ( Name == UnitName("player") ) and ( GearScore <= 0 ) then
		    GearScore = 0; end
		
		--if ( GearScore < 0 ) and ( PVPScore < 0 ) then return 0, 0; end
		--if ( PVPScore < 0 ) then PVPScore = 0; end
        --print(GearScore, PVPScore)
		local __, RaceEnglish = UnitRace(Target);
		local __, ClassEnglish = UnitClass(Target);
        local currentzone = GetZoneText()
        if not ( GS_Zones[currentzone] ) then 
			--print("Alert! You have found a zone unknown to GearScore. Please report the zone '"..GetZoneText().." at gearscore.blogspot.com Thanks!"); 
			currentzone = "Unknown Location"
		end
        local GuildName = GetGuildInfo(Target); if not ( GuildName ) then GuildName = "*"; else GuildName = GuildName; end
		local KeepServerFields = ExistingRecord and ExistingRecord.ServerBridgeVersion == GS_ServerBridgeVersion and GearScore_EquipCodesMatch(ExistingRecord.Equip, TempEquip)
		GearScore_TransmogSetDebug("local score preserve server fields name="..tostring(Name).." keep="..tostring(KeepServerFields).." oldSource="..tostring(ExistingRecord and ExistingRecord.Scanned))
		GS_Data[GetRealmName()].Players[Name] = { ["Name"] = Name, ["GearScore"] = floor(GearScore), ["PVP"] = 1, ["Level"] = UnitLevel(Target), ["Faction"] = GS_Factions[UnitFactionGroup(Target)], ["Sex"] = UnitSex(Target), ["Guild"] = GuildName,
        ["Race"] = GS_Races[RaceEnglish], ["Class"] =  GS_Classes[ClassEnglish], ["Spec"] = 1, ["Location"] = GS_Zones[currentzone], ["Scanned"] = UnitName("player"), ["Date"] = GearScore_GetTimeStamp(), ["Average"] = floor((LevelTotal / ItemCount)+0.5), ["Equip"] = TempEquip,
		["Stats"] = KeepServerFields and ExistingRecord.Stats or nil, ["Sets"] = KeepServerFields and ExistingRecord.Sets or nil, ["Sockets"] = KeepServerFields and ExistingRecord.Sockets or nil, ["ServerCachedAt"] = KeepServerFields and ExistingRecord.ServerCachedAt or nil, ["ServerBridgeVersion"] = KeepServerFields and ExistingRecord.ServerBridgeVersion or nil}
	end
end

-------------------------------------------------------------------------------
	--attempt to obtain raid members GearScores
function GearScore_GetGroupScores()
	--Is this Called by anything?
end

-------------------------------------------------------------------------------
function GearScore_EquipCompare(Tooltip, ItemScore, ItemSlot, GS_ItemLink)
    if ( ItemSlot == 50 ) then return; end
    local ItemName, ItemLink, ItemRarity, ItemLevel, ItemMinLevel, ItemType, ItemSubType, ItemStackCount, ItemEquipLoc, ItemTexture = GetItemInfo(GS_ItemLink)
    local HunterMultiplier = 1
    local TokenLink, TokenNumber = GearScore_GetItemCode(ItemLink)
	if ( GS_Tokens[TokenNumber] ) then
	    ItemSlot = GS_Tokens[TokenNumber].ItemSlot
	    ItemScore = GS_Tokens[TokenNumber].ItemScore
	    ItemSubType = GS_Tokens[TokenNumber].ItemSubType
	end
    local X = ""; local Red = 0; local Blue = 0; local Green = 0; local Table = {};	local NoTable = {}; local Count = 1; local PartySize = 0; local Group = ""; local CompareScore = 0; local Percent = 0
	Tooltip:AddLine("Best Upgrade for:")
	local GSL_DataBase = GearScore_BuildDatabase("Party")
	
	for i,v in pairs(GSL_DataBase) do
 	local Difference = 0
				--print( ItemSubType )
			if ( GS_ClassInfo[GS_Classes[v.Class]].Equip[ItemSubType] ) or ( ItemEquipLoc == "INVTYPE_CLOAK" )  then
			    if ( ItemSlot == 18 ) and v.Class == "HU" then HunterMultiplier = 5.3224; end
			    if ( ( ItemSlot == 17 ) or ( ItemSlot == 16 ) or ( ItemSlot == 36 ) ) and ( v.Class == "HU" ) then HunterMultiplier = 0.3164; end
			    
			    --Code To fix 2H issue.

               		if ( ItemSlot > 20 ) or ( ItemSlot == 16 ) then
             		if ( ItemSlot == 16 ) then ItemSlot = 36; end
					local ItemName2, ItemLink2, ItemRarity2, ItemLevel2, ItemMinLevel2, ItemType2, ItemSubType2, ItemStackCount2, ItemEquipLoc2, ItemTexture2 = GetItemInfo("item:"..v.Equip[ItemSlot - 20])
 	  				local ItemName3, ItemLink3, ItemRarity3, ItemLevel3, ItemMinLevel3, ItemType3, ItemSubType3, ItemStackCount3, ItemEquipLoc3, ItemTexture3 = GetItemInfo("item:"..v.Equip[ItemSlot - 19])
     				if ( ItemLink2 ) then ItemScore2 = GearScore_GetItemScore(ItemLink2); else ItemScore2 = 0; end
	    			if ( ItemLink3 ) then ItemScore3 = GearScore_GetItemScore(ItemLink3); else ItemScore3 = 0; end
					if ( ItemScore2 > ItemScore3 ) then CompareScore = ItemScore3; else CompareScore = ItemScore2; end
					--if ( ItemEquipLoc == "INVTYPE_2HWEAPON" ) then
					if ( ItemSlot ~= 31 ) and ( ItemSlot ~= 32 ) and ( ItemSlot ~= 33 ) and ( ItemSlot ~= 34 ) then
					    Difference = floor((ItemScore - ( ItemScore2 + ItemScore3 )) * HunterMultiplier)
					else
					    Difference = floor((ItemScore - ( CompareScore )) * HunterMultiplier)
					end
     			else
        			local ItemName2, ItemLink2, ItemRarity2, ItemLevel2, ItemMinLevel2, ItemType2, ItemSubType2, ItemStackCount2, ItemEquipLoc2, ItemTexture2 = GetItemInfo("item:"..v.Equip[ItemSlot])
    	 			if ( ItemLink2 ) then ItemScore2 = GearScore_GetItemScore(ItemLink2); else ItemScore2 = 0; end
     				Difference = floor(((ItemScore) - (ItemScore2)) * HunterMultiplier )
         		end
				Percent = floor((Difference / v.GearScore) * 10000 ) / 100
				if ( Percent > 99.99 ) or ( v.GearScore == ( 4/0 ) ) then Percent = 99.99; end
				Table[Count] = { ["Name"] = v.Name, ["Percent"] = Percent, ["Difference"] = Difference, ["Class"] = GS_Classes[v.Class] }
                Count = Count + 1
	   		end
		--end
	end
    table.sort(Table, function(a, b) return a.Percent > b.Percent end)
    for i, v in ipairs(Table) do
		local Red = 0; local Blue = 0; local Green = 0; local X = ""
		if ( v.Percent > 0 ) then Green = 1; X = "+"; end
		if ( v.Percent < 0 ) then Red = 1; end
	    if ( v.Percent == 0 ) then Red = 1; Green = 1; v.Percent = "0.00"; end
  		Tooltip:AddDoubleLine(v.Name, X..v.Percent.."% ("..X..v.Difference..")", GS_ClassInfo[v.Class].Red, GS_ClassInfo[v.Class].Green, GS_ClassInfo[v.Class].Blue, Red, Green, Blue)
	end
	for i = 1, PartySize do if ( UnitName(GS_Group..i) ) and not ( GS_Data[GetRealmName()].Players[UnitName(Group..i)] ) and not ( GS_ClassInfo[GS_Data[GetRealmName()].Players[UnitName(Group..i)].Class].Equip[ItemSubType] ) then Tooltip:AddDoubleLine(UnitName(GS_Group..i), "No Data", GS_ClassInfo[UnitClass(GS_Group..i)].Red, GS_ClassInfo[UnitClass(GS_Group..i)].Green, GS_ClassInfo[UnitClass(GS_Group..i)].Blue, 1, 1, 1); end; end
end

------------------------------ Get Item Score ---------------------------------
function GearScore_GetItemScore(ItemLink)
	local QualityScale = 1; local PVPScale = 1; local PVPScore = 0; local GearScore = 0
	if not ( ItemLink ) then return 0, 0; end
	local ItemName, ItemLink, ItemRarity, ItemLevel, ItemMinLevel, ItemType, ItemSubType, ItemStackCount, ItemEquipLoc, ItemTexture = GetItemInfo(ItemLink); local Table = {}; local Scale = 1.8618
 	if ( ItemRarity == 5 ) then QualityScale = 1.3; ItemRarity = 4;
	elseif ( ItemRarity == 1 ) then QualityScale = 0.005;  ItemRarity = 2
	elseif ( ItemRarity == 0 ) then QualityScale = 0.005;  ItemRarity = 2 end
    if ( ItemRarity == 7 ) then ItemRarity = 3; ItemLevel = 187.05; end
    local TokenLink, TokenNumber = GearScore_GetItemCode(ItemLink)
	if ( GS_Tokens[TokenNumber] ) then return GS_Tokens[TokenNumber].ItemScore, GS_Tokens[TokenNumber].ItemLevel, GS_Tokens[TokenNumber].ItemSlot; end
    if ( GS_ItemTypes[ItemEquipLoc] ) then
        if ( ItemLevel > 120 ) then Table = GS_Formula["A"]; else Table = GS_Formula["B"]; end
		if ( ItemRarity >= 2 ) and ( ItemRarity <= 4 )then
            local Red, Green, Blue = GearScore_GetQuality((floor(((ItemLevel - Table[ItemRarity].A) / Table[ItemRarity].B) * 1 * Scale)) * 12.25 )
            GearScore = floor(((ItemLevel - Table[ItemRarity].A) / Table[ItemRarity].B) * GS_ItemTypes[ItemEquipLoc].SlotMOD * Scale * QualityScale)
			if ( ItemLevel == 187.05 ) then ItemLevel = 0; end
			if ( GearScore < 0 ) then GearScore = 0;   Red, Green, Blue = GearScore_GetQuality(1); end
			GearScoreTooltip:SetOwner(GS_Frame1, "ANCHOR_Right")
			if ( PVPScale == 0.75 ) then PVPScore = 1; GearScore = GearScore * 1; 
			else PVPScore = GearScore * 0; end
			GearScore = floor(GearScore)
			PVPScore = floor(PVPScore)
			return GearScore, ItemLevel, GS_ItemTypes[ItemEquipLoc].ItemSlot, Red, Green, Blue, PVPScore, ItemEquipLoc;
		end
  	end
	return -1, ItemLevel, 50, 1, 1, 1, PVPScore, ItemEquipLoc
end
-------------------------------------------------------------------------------

---------------------------- Request Information ------------------------------
function GearScore_Request(GS_Target)
	if not ( GearScoreChatMessageThrottle ) then GearScoreChatMessageThrottle = 0; end
    if ( GearScoreChatMessageThrottle >= 5 ) then return; end
	if ( GS_Settings["Communication"] == 1 ) then
		    if ( GetGuildInfo("player") ) then SendAddonMessage( "GSY_Request", GS_Target, "GUILD"); --SendAddonMessage( "GSY_Version", GS_Settings["OldVer"], "GUILD"); 
		    end
	end
end
-------------------------------------------------------------------------------
                                                
---------------------------- Send Information ------------------------------
function GearScore_Send(Name, Group, Target)
	if Group == "RAID" then Group = "GUILD"; end --Command to convert info to only Guild Channel
	if not ( GearScoreChatMessageThrottle ) then GearScoreChatMessageThrottle = 0; end
    if ( GearScoreChatMessageThrottle >= 1 ) then return; end
        
	if ( GS_PlayerIsInCombat ) then return; end
	local GS_MessageA, GS_MessageB, GS_MessageC, GS_MessageD, GS_Lenght = "", "", "", "", 0
	if ( GS_Settings["Communication"] == 1 ) then
	    GS_TempVersion = GS_VersionNum
		if ( GS_Settings["Developer"] ) then GS_TempVersion = ""; end
			if ( Name ) and ( GS_Data[GetRealmName()].Players[Name] ) then
				local A = GetRealmName()
				GS_MessageA = GS_Data[A].Players[Name].Name.."$"..GS_Data[A].Players[Name].GearScore.."$"..GS_Data[A].Players[Name].Date.."$"..GS_Data[A].Players[Name].Class.."$"
				GS_MessageB = GS_Data[A].Players[Name].Average.."$"..GS_Data[A].Players[Name].Race.."$"..GS_Data[A].Players[Name].Faction.."$"..GS_Data[A].Players[Name].Location.."$"
				--GS_MessageC = GS_Data[A].Players[Name].Level.."$"..GS_Data[A].Players[Name].Sex.."$"..GS_Data[A].Players[Name].Guild.."$"..GS_Data[A].Players[Name].Scanned
				GS_MessageC = GS_Data[A].Players[Name].Level.."$"..GS_Data[A].Players[Name].Guild.."$"..GS_Data[A].Players[Name].Scanned
				--print( GS_MessageC )
				GS_MessageD = "$"
				for i = 1, 18 do
					if ( i ~= 4 ) then
						GS_MessageD = GS_MessageD..GS_Data[A].Players[Name].Equip[i].."$"
					else
					   	GS_MessageD = GS_MessageD.."0:0".."$"
					end
				end       
			if ( strlen(GS_MessageA..GS_MessageB..GS_MessageC..GS_MessageD) >= 252 ) then GS_MessageC = GS_Data[A].Players[Name].Level.."$"..GS_Data[A].Players[Name].Guild.."$".." "; end
			GS_Length = strlen(GS_MessageA..GS_MessageB..GS_MessageC..GS_MessageD);
			end
			if not ( GS_Length ) then return; end
		if ( GS_Length ) and ( GS_Length < 252 ) then
		    if ( Group == "ALL" ) then
				if ( GetGuildInfo("player") ) then SendAddonMessage( "GSY", GS_MessageA..GS_MessageB..GS_MessageC..GS_MessageD, "Guild"); end
				SendAddonMessage( "GSY", GS_MessageA..GS_MessageB..GS_MessageC..GS_MessageD, "RAID")
			else
			    if ( Group == "GUILD" ) and not ( GetGuildInfo("player") ) then return; end
				SendAddonMessage( "GSY", GS_MessageA..GS_MessageB..GS_MessageC..GS_MessageD, Group, Target)
			end
		end
	end
end
-------------------------------------------------------------------------------

-------------------------------- Get Quality ----------------------------------

function GearScore_GetQuality(ItemScore)
	--if not ItemScore then return; end
	--ItemScore = ItemScore / 2;
	local Red = 0.1; local Blue = 0.1; local Green = 0.1; local GS_QualityDescription = "Legendary"
   	if not ( ItemScore ) then return 0, 0, 0, "Trash"; end
   	if ( ItemScore > 5999 ) then ItemScore = 5999; end
	for i = 0,6 do
		if ( ItemScore > i * 1000 ) and ( ItemScore <= ( ( i + 1 ) * 1000 ) ) then
		    local Red = GS_Quality[( i + 1 ) * 1000].Red["A"] + (((ItemScore - GS_Quality[( i + 1 ) * 1000].Red["B"])*GS_Quality[( i + 1 ) * 1000].Red["C"])*GS_Quality[( i + 1 ) * 1000].Red["D"])
            local Blue = GS_Quality[( i + 1 ) * 1000].Green["A"] + (((ItemScore - GS_Quality[( i + 1 ) * 1000].Green["B"])*GS_Quality[( i + 1 ) * 1000].Green["C"])*GS_Quality[( i + 1 ) * 1000].Green["D"])
            local Green = GS_Quality[( i + 1 ) * 1000].Blue["A"] + (((ItemScore - GS_Quality[( i + 1 ) * 1000].Blue["B"])*GS_Quality[( i + 1 ) * 1000].Blue["C"])*GS_Quality[( i + 1 ) * 1000].Blue["D"])
			return Red, Green, Blue, GS_Quality[( i + 1 ) * 1000].Description
		end
	end
return 0.1, 0.1, 0.1
end
-------------------------------------------------------------------------------

------------------------------Get Date ----------------------------------------
function GearScore_GetDate(TimeStamp)
	if not (TimeStamp) then return; end
	--Example Time Stamp 12/28/1985 10:45am--> 198512281045
	local min, hour, day, month, year, GS_Date = 0; CopyStamp = TimeStamp; meridian = "am"
	local Red, Green, Blue = 0
	year = floor(TimeStamp / 100000000); TimeStamp = TimeStamp - (year * 100000000)
	month = floor(TimeStamp / 1000000); TimeStamp = TimeStamp - (month * 1000000)
	day = floor(TimeStamp / 10000); TimeStamp = TimeStamp - (day * 10000)
	hour = floor(TimeStamp / 100); TimeStamp = TimeStamp - (hour * 100)
	min = TimeStamp
	if ( hour == 24 ) then hour = 0; end
	--if ( hour >= 12 ) then
--	    meridian = "pm"; hour = hour - 12
--		if ( hour == 0 ) then hour = 12; end
--	end
	if ( min < 10 ) then min = "0"..tonumber(min); end
	GS_Date = month.."/"..day--.."/"..year
	local TempDate = GearScore_GetTimeStamp();
 	--print(floor(CopyStamp / 10000), floor(TempDate / 10000))
	if ( floor(CopyStamp / 10000) == floor(TempDate / 10000) ) then GS_Date = hour..":"..min.." "--..meridian; 
	end

	--Add Color!
	local CurrentTime = GearScore_GetTimeStamp()
	local currentyear = floor(CurrentTime / 100000000); CurrentTime = CurrentTime - (currentyear * 100000000)
	local currentmonth = floor(CurrentTime / 1000000); CurrentTime = CurrentTime - (currentmonth * 1000000)
	local currentday = floor(CurrentTime / 10000); CurrentTime = CurrentTime - (currentday * 10000)
	local currenthour = floor(CurrentTime / 100); CurrentTime = CurrentTime - (currenthour * 100)
	local currentmin = CurrentTime
	local currentdays = ( currentmonth * 30 ) + currentday
	--print(currentyear, currentmonth, currentday, currenthour, currentmin)
	local totaldays = (month * 30 ) + day
	if currentdays < totaldays then currentdays = currentdays + 365; end
	Blue = 0; Red = 0; Green = 1
	--if ( (currentdays - totaldays) >= 1 ) then Red = 0; Green = 1; Blue = 0; end
	--if ( (currentdays - totaldays) > 3 ) then Green = 1; Red = 0; Blue = 0; end
	if ( (currentdays - totaldays) >= 7 ) then Green = 0.9; Red = .9; Blue = .0; end  
	if ( (currentdays - totaldays) >= 14 ) then Green = .5; Red = 1; Blue = .25; end
	if ( (currentdays - totaldays) >= 21 ) then Green = 0; Red = 1; Blue = 0; end
	--print("CurrentDay:", currentdays, "    RecordedDays:", totaldays)
	
	--365
	--1


	return currentdays - totaldays, Red, Green, Blue
end
-------------------------------------------------------------------------------


---------------------------- Get TimeStamp ------------------------------------
function GearScore_GetTimeStamp()
	local GS_Hour, GS_Minute = GetGameTime(); local monthago = 0
	local GS_Weekday, GS_Month, GS_Day, GS_Year = CalendarGetDate()
	local GS_TimeStamp = (GS_Year * 100000000) + (GS_Month * 1000000) + (GS_Day * 10000) + (GS_Hour * 100) + (GS_Minute)
	if ( GS_Month == 1 ) then
		monthago = ( ( GS_Year - 1 ) *100000000 ) + ( 12 * 1000000 ) + (GS_Day * 10000) + (GS_Hour * 100) + (GS_Minute)
	else
		monthago = (GS_Year * 100000000) + ((GS_Month - 1) * 1000000) + (GS_Day * 10000) + (GS_Hour * 100) + (GS_Minute)
	end
	return GS_TimeStamp, monthago
end
-------------------------------------------------------------------------------


----------------------------- Show Tooltip ------------------------------------
function GearScore_ShowTooltip(GS_Target)
	GameTooltip:SetUnit(GS_Target)
	GameTooltip:Show()
end
-------------------------------------------------------------------------------

function GearScore_GetAge(ScanDate)
	local CurrentDate = GearScore_GetTimeStamp();
	local DateSpread = CurrentDate - ScanDate;
	if ( DateSpread == 0 ) then return "*Scanned < 1 min ago.", 0,1,0, 0, "minutes"; end;
	if ( DateSpread < 60 ) then	return "*Scanned "..DateSpread.." minutes ago.", 0,1,0, DateSpread, "minutes"; end;
	DateSpread = floor((DateSpread + 40) / 100);
	if ( DateSpread < 24 ) then	return "*Scanned "..DateSpread.." hours ago.", 1,1,0, DateSpread, "hours"; end;
	DateSpread = floor(DateSpread / 100) + floor(mod(DateSpread, 100) / 24);
	if ( DateSpread < 31 ) then	return "*Scanned "..DateSpread.." days ago.", 1,0.5,0, DateSpread, "days"; end;
	return "*Scanned over 1 month ago.", 1,0,0, floor(DateSpread / 30), "months";
end

----------------------------- Hook Set Unit -----------------------------------
function GearScore_HookSetUnit(arg1, arg2)
    GS_GearScore = nil; local Name = GameTooltip:GetUnit(); GearScore_GetGroupScores(); local PreviousRecord = {}; 
    local Age = "*";
    Name = GearScore_NormalizeName(Name)
    local Realm = ""; if UnitName("mouseover") == Name then _, Realm = UnitName("mouseover"); if not Realm then Realm = GetRealmName(); end; end
	if ( UnitName("mouseover") == Name ) and UnitIsPlayer("mouseover") and not ( GS_PlayerIsInCombat ) then 
		Age = "";
		if ( GS_Data[GetRealmName()].Players[Name] ) then PreviousRecord = GS_Data[GetRealmName()].Players[Name]; end 
	end
 	if ( GS_Data[GetRealmName()].Players[Name] ) and ( GS_Data[GetRealmName()].Players[Name].GearScore > 0 ) and ( GS_Settings["Player"] == 1 ) then 
		local Red, Blue, Green = GearScore_GetQuality(GS_Data[GetRealmName()].Players[Name].GearScore)
		if ( GS_Settings["Level"] == 1 ) then 
			GameTooltip:AddDoubleLine(Age.."GearScore: "..GS_Data[GetRealmName()].Players[Name].GearScore, "(iLevel: "..GS_Data[GetRealmName()].Players[Name].Average..")", Red, Green, Blue, Red, Green, Blue)
			if ( GS_Settings["Date2"] == 1 ) and ( Age == "*" ) then 
				local NoWDate, DateRed, DateGreen, DateBlue = GearScore_GetAge(GS_Data[GetRealmName()].Players[Name].Date); 
				--print(GearScore_GetAge(GS_Data[GetRealmName()].Players[Name].Date));
				GameTooltip:AddLine(NoWDate, DateRed, DateGreen, DateBlue);
			end
		else
			GameTooltip:AddLine(Age.."GearScore: "..GS_Data[GetRealmName()].Players[Name].GearScore, Red, Green, Blue)
			if ( GS_Settings["Date2"] == 1 ) and ( Age == "*" ) then 
				local NoWDate, DateRed, DateGreen, DateBlue = GearScore_GetAge(GS_Data[GetRealmName()].Players[Name].Date); 
				--print(GearScore_GetAge(GS_Data[GetRealmName()].Players[Name].Date));
				GameTooltip:AddLine(NoWDate, DateRed, DateGreen, DateBlue); 
			end
		end
		if ( GS_Settings["Compare"] == 1 ) then
			local MyGearScore = GS_Data[GetRealmName()].Players[UnitName("player")].GearScore
			local TheirGearScore = GS_Data[GetRealmName()].Players[Name].GearScore
			if ( MyGearScore  > TheirGearScore  ) then GameTooltip:AddDoubleLine("YourScore: "..MyGearScore  , "(+"..(MyGearScore - TheirGearScore  )..")", 0,1,0, 0,1,0); end
			if ( MyGearScore   < TheirGearScore   ) then GameTooltip:AddDoubleLine("YourScore: "..MyGearScore, "(-"..(TheirGearScore - MyGearScore  )..")", 1,0,0, 1,0,0); end	
			if ( MyGearScore   == TheirGearScore   ) then GameTooltip:AddDoubleLine("YourScore: "..MyGearScore  , "(+0)", 0,1,1,0,1,1); end	
		end
		
		if ( GS_Settings["Detail"] == 1 ) then GearScore_SetDetails(GameTooltip, Name); end
		if ( GS_Settings["Special"] == 1 ) and ( GS_Special[Name] ) then if ( GS_Special[Name]["Realm"] == Realm ) then GameTooltip:AddLine(GS_Special[GS_Special[Name].Type], 1, 0, 0 ); end; end
		if ( GS_Settings["Special"] == 1 ) and ( GS_Special[GS_Data[GetRealmName()].Players[Name].Guild] ) then GameTooltip:AddLine(GS_Special[GS_Special[GS_Data[GetRealmName()].Players[Name].Guild].Type], 1, 0, 0 ); end
			if ( GS_Settings["ShowHelp"] == 1 ) then GameTooltip: AddLine("Target this player and type /gs for detailed information. You can turn this msg off in the options screen. (/gs)", 1,1,1,1); end
		end
	--GearScore_Request(Name)
end

function GearScoreChatAdd(self,event,msg,arg1,...)
if ( msg == "You aren't in a party." ) then return true; end   
if ( GS_ExchangeName ) then if ( msg == "No player named '"..GS_ExchangeName.."' is currently playing." ) then GS_ExchangeCount = nil; print("Transmission Interrupted!"); return true; end; end
if ( GS_Settings["CHAT"] == 1 ) then
	--msg = "(1234): "..msg

	    --print("A", GS_AddonMessage, "B", GS_Whisper, "C", GS_Sender)
	    local Who = arg1; local Message = msg; local ExtraMessage = ""; local ColorClass = "";
	    if GS_Data[GetRealmName()].Players[Who] then
            ColorClass = "|cff"..string.format("%02x%02x%02x", GS_ClassInfo[GS_Classes[GS_Data[GetRealmName()].Players[Who].Class]].Red * 255, GS_ClassInfo[GS_Classes[GS_Data[GetRealmName()].Players[Who].Class]].Green * 255, GS_ClassInfo[GS_Classes[GS_Data[GetRealmName()].Players[Who].Class]].Blue * 255)
			local Red, Green, Blue = GearScore_GetQuality(GS_Data[GetRealmName()].Players[Who].GearScore)
			local ColorGearScore = "|cff"..string.format("%02x%02x%02x", Red * 255, Blue * 255, Green * 255)
            ExtraMessage = "("..ColorGearScore..tostring(GS_Data[GetRealmName()].Players[Who].GearScore).."|r): " ;
            ExtraMessage = (ColorGearScore.."|Hplayer:X33"..Who.."|h("..tostring(GS_Data[GetRealmName()].Players[Who].GearScore)..")|h|r ")

		end

	    local NewMessage = ExtraMessage..Message
		--local NewMessage = Message
		--local arg1 = arg1..ExtraMessage
		--print(arg1)

--return true
	return false,NewMessage,arg1,...
else
	return false
end
end

--function GearScoreChatAddddd(self,event,msg,arg1,...)
--print("Captured Info: ", msg)
--return true
--end

ChatFrame_AddMessageEventFilter("CHAT_MSG_CHANNEL",GearScoreChatAdd)
ChatFrame_AddMessageEventFilter("CHAT_MSG_PARTY",GearScoreChatAdd)
ChatFrame_AddMessageEventFilter("CHAT_MSG_RAID",GearScoreChatAdd)
ChatFrame_AddMessageEventFilter("CHAT_MSG_GUILD",GearScoreChatAdd)
ChatFrame_AddMessageEventFilter("CHAT_MSG_SYSTEM",GearScoreChatAdd)
ChatFrame_AddMessageEventFilter("CHAT_MSG_WHISPER",GearScoreChatAdd)
--ChatFrame_AddMessageEventFilter("CHAT_MSG_CHANNEL_LIST",GearScoreChatAddddd)






function GearScoreSetItemRef(arg1, arg2, ...)
	if not arg1 then return; end
	if string.sub(arg1, 1, 10) == "player:X33" then
        GearScore_OpenProfile(string.sub(arg1, 11), 1)
        return
	end
 	--return OriginalSetItemRef(arg1, arg2, ...)
end

function GearScore_OpenProfile(Name, Auto)
	if not Name or Name == "" then Name = UnitName("player"); end
	if ( GS_OptionsFrame and GS_OptionsFrame:IsVisible() ) then GearScore_HideOptions(); end
	GearScore_HideDatabase()
	PanelTemplates_SetTab(GS_DisplayFrame, 1)
	GS_GearFrame:Show(); GS_NotesFrame:Hide(); GS_DefaultFrame:Show()
	GearScore_DisplayUnit(Name, Auto)
end



function GearScore_IsRecordTheSame(Current, Previous)
	if not ( Previous.Name ) or not ( Current.Name ) then return true; end
	if ( Previous.GearScore ~= Current.GearScore ) then return false; end
	if ( Previous.Date + 10000 <= Current.Date ) then return false; end
	if ( Previous.Guild ~= Current.Guild ) then return false; end
	if ( Previous.Level ~= Current.Level ) then return false; end
	for i = 1, 18 do
		if ( i ~= 4 ) then 
			if ( Previous.Equip[i] ~= Current.Equip[i] ) then return false; end
		end
	end
	return true
end


function GearScore_SetDetails(tooltip, Name)
    if not ( GS_Data[GetRealmName()].Players[Name] ) then return; end
  	for i = 1,18 do
  	    if not ( i == 4 ) then
    	local ItemName, ItemLink, ItemRarity, ItemLevel, ItemMinLevel, ItemType, ItemSubType, ItemStackCount, ItemEquipLoc, ItemTexture = GetItemInfo("item:"..GS_Data[GetRealmName()].Players[Name].Equip[i])
		if ( ItemLink ) then
			local GearScore, ItemLevel, EquipLoc, Red, Green, Blue = GearScore_GetItemScore(ItemLink)
			if ( GS_Data[GetRealmName()].Players[Name].Equip[i] ) and ( i ~= 4 ) then
    		   	local Add = ""
        		if ( GS_Settings["Level"] == 1 ) then Add = " (iLevel "..tostring(ItemLevel)..")"; end
             	tooltip:AddDoubleLine("["..ItemName.."]", tostring(GearScore)..Add, GS_Rarity[ItemRarity].Red, GS_Rarity[ItemRarity].Green, GS_Rarity[ItemRarity].Blue, Red, Blue, Green)
        	end
		end
		end
	end
end
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
function GearScore_HookSetItem() ItemName, ItemLink = GameTooltip:GetItem(); GearScore_HookItem(ItemName, ItemLink, GameTooltip); end
function GearScore_HookRefItem() ItemName, ItemLink = ItemRefTooltip:GetItem(); GearScore_HookItem(ItemName, ItemLink, ItemRefTooltip); end
function GearScore_HookCompareItem() ItemName, ItemLink = ShoppingTooltip1:GetItem(); GearScore_HookItem(ItemName, ItemLink, ShoppingTooltip1); end
function GearScore_HookCompareItem2() ItemName, ItemLink = ShoppingTooltip2:GetItem(); GearScore_HookItem(ItemName, ItemLink, ShoppingTooltip2); end
function GearScore_HookItem(ItemName, ItemLink, Tooltip)
	local PlayerClass, PlayerEnglishClass = UnitClass("player");
	local TokenLink, TokenNumber = GearScore_GetItemCode(ItemLink)
	if not ( IsEquippableItem(ItemLink) ) and not GS_Tokens[TokenNumber] then return; end
	local ItemScore, ItemLevel, EquipLoc, Red, Green, Blue, PVPScore, ItemEquipLoc = GearScore_GetItemScore(ItemLink);
 	if ( ItemScore >= 0 ) then
		if ( GS_Settings["Item"] == 1 ) then
  			if ( ItemLevel ) and ( GS_Settings["Level"] == 1 ) then Tooltip:AddDoubleLine("GearScore: "..ItemScore, "(iLevel "..ItemLevel..")", Red, Blue, Green, Red, Blue, Green);
				if ( PlayerEnglishClass == "HUNTER" ) then
					if ( ItemEquipLoc == "INVTYPE_RANGEDRIGHT" ) or ( ItemEquipLoc == "INVTYPE_RANGED" ) then
						Tooltip:AddLine("HunterScore: "..floor(ItemScore * 5.3224), Red, Blue, Green)
					end
					if ( ItemEquipLoc == "INVTYPE_2HWEAPON" ) or ( ItemEquipLoc == "INVTYPE_WEAPONMAINHAND" ) or ( ItemEquipLoc == "INVTYPE_WEAPONOFFHAND" ) or ( ItemEquipLoc == "INVTYPE_WEAPON" ) or ( ItemEquipLoc == "INVTYPE_HOLDABLE" )  then
						Tooltip:AddLine("HunterScore: "..floor(ItemScore * 0.3164), Red, Blue, Green)
					end
				end
			else
				Tooltip:AddLine("GearScore: "..ItemScore, Red, Blue, Green)
				if ( PlayerEnglishClass == "HUNTER" ) then
					if ( ItemEquipLoc == "INVTYPE_RANGEDRIGHT" ) or ( ItemEquipLoc == "INVTYPE_RANGED" ) then
						Tooltip:AddLine("HunterScore: "..floor(ItemScore * 5.3224), Red, Blue, Green)
					end
					if ( ItemEquipLoc == "INVTYPE_2HWEAPON" ) or ( ItemEquipLoc == "INVTYPE_WEAPONMAINHAND" ) or ( ItemEquipLoc == "INVTYPE_WEAPONOFFHAND" ) or ( ItemEquipLoc == "INVTYPE_WEAPON" ) or ( ItemEquipLoc == "INVTYPE_HOLDABLE" )  then
						Tooltip:AddLine("HunterScore: "..floor(ItemScore * 0.3164), Red, Blue, Green)
					end
				end
    		end
    		if ( Tooltip ~= ShoppingTooltip1 ) and ( Tooltip ~= ShoppingTooltip2 ) then CalculateClasicItemScore(ItemLink, Tooltip, Red, Green, Blue); end
           if ( GS_Settings["ML"] == 1 ) then GearScore_EquipCompare(Tooltip, ItemScore, EquipLoc, ItemLink); end
  		end
	else
	    if ( GS_Settings["Level"] == 1 ) and ( ItemLevel ) then
	        Tooltip:AddLine("iLevel "..ItemLevel)
		end
    end
end
function GearScore_OnEnter(Tooltip, UnitToken, ItemSlot, Argument)
	local OriginalOnEnter = GearScore_Original_SetInventoryItem(Tooltip, UnitToken, ItemSlot, Argument)
	local ResolvedUnit = UnitToken
	if not (ResolvedUnit and UnitExists(ResolvedUnit) and UnitIsPlayer(ResolvedUnit)) then
		if UnitExists("target") and UnitIsPlayer("target") then ResolvedUnit = "target"; else ResolvedUnit = nil; end
	end
	local FocusName = nil
	local FocusId = nil
	if GetMouseFocus then
		local Focus = GetMouseFocus()
		FocusName = Focus and Focus.GetName and Focus:GetName()
		FocusId = Focus and Focus.GetID and Focus:GetID()
	end
	local TooltipItemName, TooltipItemLink = (Tooltip or GameTooltip):GetItem()
	local TooltipItemCode, TooltipItemId = GearScore_GetItemCode(TooltipItemLink)
	if not TooltipItemId then return OriginalOnEnter; end
	GearScore_TransmogSetDebug("SetInventoryItem unit="..tostring(UnitToken).." resolved="..tostring(ResolvedUnit).." slot="..tostring(ItemSlot).." focus="..tostring(FocusName).."#"..tostring(FocusId).." item="..tostring(TooltipItemId))
	if ResolvedUnit and ItemSlot then
		GS_LastInventoryTooltip = { ["Name"] = UnitName(ResolvedUnit), ["UnitToken"] = ResolvedUnit, ["Slot"] = ItemSlot, ["Time"] = GetTime() }
		GearScore_FixTransmogSetTooltip(Tooltip or GameTooltip, ResolvedUnit, ItemSlot)
	end
	return OriginalOnEnter
end

function GearScore_GearFrameItemOnEnter(Frame)
	if not Frame or not GS_DisplayPlayer then return; end
	if not GS_Data or not GS_Data[GetRealmName()] or not GS_Data[GetRealmName()].Players then return; end

	local Slot = Frame:GetID()
	local Record = GS_Data[GetRealmName()].Players[GS_DisplayPlayer]
	if not Record or not Record.Equip or not Slot then return; end

	local ItemCode = Record.Equip[Slot]
	if not ItemCode or ItemCode == "0:0" then return; end

	GameTooltip:SetOwner(Frame, "ANCHOR_RIGHT")
	GameTooltip:ClearLines()
	GameTooltip:SetHyperlink("item:"..ItemCode)
	GearScore_TransmogSetDebug("GS frame tooltip "..tostring(GS_DisplayPlayer).." slot "..tostring(Slot).." real="..tostring(ItemCode).." source="..tostring(Record.Scanned))
	GearScore_FixRecordItemTooltip(GameTooltip, Record, Slot, GS_DisplayPlayer)

	GameTooltip:Show()
end

function GearScore_GearFrameItemOnLeave(Frame)
	GameTooltip:Hide()
end

function GearScore_HookGearFrameTooltips()
	if GS_GearFrameTooltipsHooked then return; end
	for i = 1, 18 do
		local Frame = _G["GS_Frame"..i]
		if Frame and i ~= 4 then
			Frame:SetScript("OnEnter", GearScore_GearFrameItemOnEnter)
			Frame:SetScript("OnLeave", GearScore_GearFrameItemOnLeave)
		end
	end
	GS_GearFrameTooltipsHooked = 1
end

function GS_TmogSetDebugToggle(Command)
	local Verbose = Command and string.find(strlower(Command), "verbose")
	if GS_TransmogSetDebug then
		GS_TransmogSetDebug = nil
		GS_TransmogSetVerboseDebug = nil
		if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cffffd100GSTSet debug disabled|r"); end
	else
		GS_TransmogSetDebug = 1
		GS_TransmogSetVerboseDebug = Verbose and 1 or nil
		if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cffffd100GSTSet debug enabled"..(GS_TransmogSetVerboseDebug and " verbose" or "").."|r"); end
	end
end

function GS_TmogSetDump(Name)
	Name = GearScore_NormalizeName(Name)
	if not Name then Name = UnitName("player"); end
	local Record = GS_Data and GS_Data[GetRealmName()] and GS_Data[GetRealmName()].Players and GS_Data[GetRealmName()].Players[Name]
	if not Record then print("GSTSet dump: no record for "..tostring(Name)); return; end
	local SetRows = 0
	local SignatureRows = 0
	local MemberSets = 0
	local MemberSlots = 0
	if Record.Sets and Record.Sets.BySlot then
		for _, _ in pairs(Record.Sets.BySlot) do SetRows = SetRows + 1; end
	end
	if Record.Sets and Record.Sets.BySignature then
		for _, Slots in pairs(Record.Sets.BySignature) do
			for _, _ in pairs(Slots) do SignatureRows = SignatureRows + 1; end
		end
	end
	if Record.Sets and Record.Sets.Members and Record.Sets.Members.BySet then
		for _, MemberSet in pairs(Record.Sets.Members.BySet) do
			MemberSets = MemberSets + 1
			for _, _ in pairs(MemberSet.BySlot or {}) do MemberSlots = MemberSlots + 1; end
		end
	end
	print("GSTSet dump "..tostring(Name)..": scanned="..tostring(Record.Scanned).." setRows="..tostring(SetRows).." sigRows="..tostring(SignatureRows).." memberSets="..tostring(MemberSets).." memberSlots="..tostring(MemberSlots))
end

function GS_TmogSetRefresh(Command)
	local Name = GearScore_NormalizeName(Command)
	if not Name and UnitExists("target") and UnitIsPlayer("target") then Name = UnitName("target"); end
	if not Name then Name = UnitName("player"); end
	if not Name then return; end

	if not GS_ServerRequestThrottle then GS_ServerRequestThrottle = {}; end
	GS_ServerRequestThrottle[Name] = nil
	if GS_SetRefreshThrottle then
		for Key, _ in pairs(GS_SetRefreshThrottle) do
			if string.find(Key, Name..":", 1, true) == 1 then GS_SetRefreshThrottle[Key] = nil; end
		end
	end

	GearScore_TransmogSetDebug("direct refresh request for "..tostring(Name))
	if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cffffd100GSTSet refresh -> "..tostring(Name).."|r"); end
	GearScore_RequestServerItemData(Name, 1)
end

function MyPaperDoll()
	GearScore_GetScore(UnitName("player"), "player"); GearScore_RequestSelfServerItemData(1); GearScore_Send(UnitName("player"), "ALL"); 
	--SendAddonMessage( "GSY_Version", GS_Settings["OldVer"], "GUILD")
	local Red, Blue, Green = GearScore_GetQuality(GS_Data[GetRealmName()].Players[UnitName("player")].GearScore)
    PersonalGearScore:SetText(GS_Data[GetRealmName()].Players[UnitName("player")].GearScore); PersonalGearScore:SetTextColor(Red, Green, Blue, 1)
end
-------------------------------------------------------------------------------

----------------------------- Reports -----------------------------------------
function GearScore_ManualReport(Group, Who, Target)   --Please Rewrite All of this Code. It sucks.

--/gspam raid whisper bob
--
--	GearScore_BuildDatabase()	
--	GearScore_SendReport("Manual", Group, Who, G_Direction)
		
end	

---------------GS-SPAM Slasch Command--------------------------------------
function GS_SPAM(Command)
	local tbl = {}
	for v in string.gmatch(Command, "[^ ]+") do tinsert(tbl, v); end
	if ( strlower(Command) == "group" ) then
		if ( UnitName("raid1") ) then Command = "raid"; else Command = "party"; end
	end
	if ( strlower(Command) == "party" ) then
        local GspamDatabase = GearScore_BuildDatabase("Party"); table.sort(GspamDatabase, function(a, b) return a.GearScore > b.GearScore end);
		GearScore_SendSpamReport("PARTY", nil, GspamDatabase)
		--GearScore_SendSpamReport(Target, Who, Database)
	end
	if ( strlower(Command) == "raid" ) then
        local GspamDatabase = GearScore_BuildDatabase("Party"); table.sort(GspamDatabase, function(a, b) return a.GearScore > b.GearScore end);
		GearScore_SendSpamReport("RAID", nil, GspamDatabase)
	end
	if ( tbl[1] == "party" ) or ( tbl[1] == "raid" ) then
	    if ( tbl[2] ) then
            tbl[1] = strupper(string.sub(tbl[1], 1, 1))..strlower(string.sub(tbl[1], 2))
			tbl[2] = strupper(string.sub(tbl[2], 1, 1))..strlower(string.sub(tbl[2], 2))
	        if ( tbl[2] == "Party" ) then local GspamDatabase = GearScore_BuildDatabase(tbl[1]); table.sort(GspamDatabase, function(a, b) return a.GearScore > b.GearScore end); GearScore_SendSpamReport("PARTY", nil, GspamDatabase); end
	        if ( tbl[2] == "Raid" ) then local GspamDatabase = GearScore_BuildDatabase(tbl[1]); table.sort(GspamDatabase, function(a, b) return a.GearScore > b.GearScore end); GearScore_SendSpamReport("RAID", nil, GspamDatabase); end
	        if ( tbl[2] == "Guild" ) then local GspamDatabase = GearScore_BuildDatabase(tbl[1]); table.sort(GspamDatabase, function(a, b) return a.GearScore > b.GearScore end); GearScore_SendSpamReport("GUILD", nil, GspamDatabase); end
	        if ( tbl[2] == "Officer" ) then local GspamDatabase = GearScore_BuildDatabase(tbl[1]); table.sort(GspamDatabase, function(a, b) return a.GearScore > b.GearScore end); GearScore_SendSpamReport("OFFICER", nil, GspamDatabase); end
	        if ( tbl[2] == "Say" ) then local GspamDatabase = GearScore_BuildDatabase(tbl[1]); table.sort(GspamDatabase, function(a, b) return a.GearScore > b.GearScore end); GearScore_SendSpamReport("SAY", nil, GspamDatabase); end
	        if ( tbl[2] == "Whisper" ) then local GspamDatabase = GearScore_BuildDatabase(tbl[1]); table.sort(GspamDatabase, function(a, b) return a.GearScore > b.GearScore end); GearScore_SendSpamReport("WHISPER", tbl[3], GspamDatabase); end
	        if ( tbl[2] == "Channel" ) then local GspamDatabase = GearScore_BuildDatabase(tbl[1]); table.sort(GspamDatabase, function(a, b) return a.GearScore > b.GearScore end); GearScore_SendSpamReport("CHANNEL", tbl[3], GspamDatabase); end
         end
	end
end

function GS_BANSET(Command)
	if not ( GS_Settings["BlackList"] ) then GS_Settings["BlackList"] = {}; end
	if ( GS_Settings["BlackList"][Command] ) then GS_Settings["BlackList"][Command] = nil; print(Command.." removed from GearScore's Communication Ban list.")
	else GS_Settings["BlackList"][Command] = 1; print(Command.." added to GearScore's Communication Ban list."); end
end

function GS_MANSET(Command)
	if ( strlower(Command) == "" ) or ( strlower(Command) == "options" ) or ( strlower(Command) == "option" ) or ( strlower(Command) == "help" ) then for i,v in ipairs(GS_CommandList) do print(v); end; return end
	if ( strlower(Command) == "show" ) then GS_Settings["Player"] = GS_ShowSwitch[GS_Settings["Player"]]; if ( GS_Settings["Player"] == 1 ) or ( GS_Settings["Player"] == 2 ) then print("Player Scores: On"); else print("Player Scores: Off"); end; return; end
	if ( strlower(Command) == "log_error" ) then GS_TmogSetDebugToggle(Command); return; end
	if ( strlower(Command) == "setdebug" ) or ( strlower(Command) == "setdebug verbose" ) then GS_TmogSetDebugToggle(Command); return; end
	if ( strlower(Command) == "setdump" ) then GS_TmogSetDump(); return; end
	if ( strlower(Command) == "refreshsets" ) then
		GearScore_ForceRefreshSelfServerSets()
		if UnitExists("target") and UnitIsPlayer("target") and UnitName("target") ~= UnitName("player") then GearScore_ForceRefreshUnitServerSets("target"); end
		return
	end
	if ( strlower(Command) == "player" ) then GS_Settings["Player"] = GS_ShowSwitch[GS_Settings["Player"]]; if ( GS_Settings["Player"] == 1 ) or ( GS_Settings["Player"] == 2 ) then print("Player Scores: On"); else print("Player Scores: Off"); end; return; end
    if ( strlower(Command) == "item" ) then GS_Settings["Item"] = GS_ItemSwitch[GS_Settings["Item"]]; if ( GS_Settings["Item"] == 1 ) or ( GS_Settings["Item"] == 3 ) then print("Item Scores: On"); else print("Item Scores: Off"); end; return; end
	if ( strlower(Command) == "describe" ) then GS_Settings["Description"] = GS_Settings["Description"] * -1; if ( GS_Settings["Description"] == 1 ) then print ("Descriptions: On"); else print ("Descriptions: Off"); end; return; end
	if ( strlower(Command) == "level" ) then GS_Settings["Level"] = GS_Settings["Level"] * -1; if ( GS_Settings["Level"] == 1 ) then print ("Item Levels: On"); else print ("Item Levels: Off"); end; return; end
	if ( strlower(Command) == "communicate" ) then GS_Settings["Communication"] = GS_Settings["Communication"] * -1; if ( GS_Settings["Communication"] == 1 ) then print ("Communication: On"); else print ("Communication: Off"); end; return; end
	if ( strlower(Command) == "compare" ) then GS_Settings["Compare"] = GS_Settings["Compare"] * -1; if ( GS_Settings["Compare"] == 1 ) then print ("Comparisons: On"); else print ("Comparisons: Off"); end; return; end
    --if ( strlower(Command) == "average" ) then GS_Settings["Average"] = GS_Settings["Average"] * -1; if ( GS_Settings["Average"] == 1 ) then print ("Average ItemLevels: On"); else print ("Average ItemLevels: Off"); end; return; end
    if ( strlower(Command) == "date" ) then GS_Settings["Date"] = GS_Settings["Date"] * -1; if ( GS_Settings["Date"] == 1 ) then print ("Date/Time: On"); else print ("Date/Time: Off"); end; return; end
    if ( strlower(Command) == "chat" ) then GS_Settings["CHAT"] = GS_Settings["CHAT"] * -1; if ( GS_Settings["CHAT"] == 1 ) then print ("Chat Scores: On"); else print ("ChatScores: Off"); end; return; end
	if ( strlower(Command) == "time" ) then GS_Settings["Date"] = GS_Settings["Date"] * -1; if ( GS_Settings["Date"] == 1 ) then print ("Date/Time: On"); else print ("Date/Time: Off"); end; return; end
    if ( strlower(Command) == "ml" ) then GS_Settings["ML"] = GS_Settings["ML"] * -1; if ( GS_Settings["ML"] == 1 ) then print ("MasterLooting: On"); else print ("MasterLooting: Off"); end; return; end
    if ( strlower(Command) == "detail" ) then GS_Settings["Detail"] = GS_Settings["Detail"] * -1; if ( GS_Settings["Detail"] == 1 ) then print ("Details: On"); else print ("Details: Off"); end; return; end
    if ( strlower(Command) == "details" ) then GS_Settings["Detail"] = GS_Settings["Detail"] * -1; if ( GS_Settings["Detail"] == 1 ) then print ("Details: On"); else print ("Details: Off"); end; return; end
	if ( strlower(Command) == "reset" ) then GS_Settings = GS_DefaultSettings; print("All Settings returned to Default"); return end
	if ( strlower(Command) == "purge" ) then print ("WARNING! This will remove your entire GearScore Database. To continue please type '/gset purge 314159265"); return; end
	if ( strlower(Command) == "purge 314159265" ) then GS_Data = nil; ReloadUI(); return; end
	local tbl = {}
    for v in string.gmatch(Command, "[^ ]+") do tinsert(tbl, v); end
 	if ( strlower(tbl[1]) == "transmit" ) and (tbl[2]) then
       if tbl[2] == "end" then GS_ExchangeCount = nil; print("Ending Transmission"); return; end
	     if  GS_ExchangeDatabase then print("You are already transmitting your database!"); return; end

--		if
--	        	tbl[2] = (strupper(string.sub(tbl[2], 1, 1))..strlower(string.sub(tbl[2], 2)))
--				local Message = floor(GearScore_GetTimeStamp()/314159265)
--				print(Message)
--				SendAddonMessage("GSYTRANSMIT", Message, "WHISPER", tbl[2])
		GearScore_Exchange("DATABASE", tbl[2])
		return
    end
	print("GearScore: Unknown Command. Type '/gset' for a list of options")
 	
end
function GS_SCANSET(Command)
		if Command and strlower(Command) == "refreshsets" then
			GearScore_ForceRefreshSelfServerSets()
			if UnitExists("target") and UnitIsPlayer("target") and UnitName("target") ~= UnitName("player") then GearScore_ForceRefreshUnitServerSets("target"); end
			return
		end
		if ( GS_OptionsFrame:IsVisible() ) then GearScore_HideOptions(); end		
		PanelTemplates_SetTab(GS_DisplayFrame, 1)
		GS_DisplayFrame:Hide();
		GS_GearFrame:Show(); GS_NotesFrame:Hide(); GS_DefaultFrame:Show()
		GS_GearScoreText:Show(); GS_LocationText:Show(); GS_DateText:Show(); GS_AverageText: Show();
		
	    if ( UnitName("target") ) and ( not Command or Command == "" ) then 
		 	 if not ( UnitIsPlayer("target") ) then GearScore_DisplayUnit(UnitName("player")) else GearScore_DisplayUnit(UnitName("target")); end
	    else
         	Command = GearScore_NormalizeName(Command)
         	GearScore_DisplayUnit(Command); return
	    end
end

------------------------ GUI PROGRAMS -------------------------------------------------------
function GearScore_GetRaidColor(Raid, Score)
	local Red = 0; local Blue = 0; local Green = 0
		if not (Raid) then return; end
		if ( (Raid - Score) >= 200 ) then return 1, 0, 0; end
		if ( (Score - Raid) >= 400 ) then return 0, 1, 0; end
		if ( (Score - Raid) >= 0 ) and ( (Score - Raid) <= 300 ) then return 1, 1, 0; end
  		if ( (Score - Raid) >= 0 ) and ( (Score - Raid) > 300 ) then return ( 400 - (Score - Raid) )/200 , 1, 0; end
        if ( (Raid - Score) < 200 ) then return 1, ((Score - (Raid - 200))/200), 0; end
	return 0, 0, 0
end
													

function GearScore_DisplayUnit(Name, Auto)
	GearScore_HookGearFrameTooltips()
	if not ( Name ) then Name = UnitName("player"); end
	Name = GearScore_NormalizeName(Name)
	if ( Name == UnitName("player") ) then GearScore_GetScore(UnitName("player"), "player"); end
	--or not ( GS_Data[GetRealmName()].Players[Name] ) then return; end
	GearScore_HideDatabase(1)
	GS_DisplayPlayer = Name
	local UnitToken = GearScore_GetUnitTokenByName(Name)
	if Name ~= UnitName("player") then
		GearScore_RequestOrScan(Name, UnitToken)
	end
	GS_DatabaseFrame.tooltip = nil
	GearScore_SetDisplayStats(Name, UnitToken)
--	if GS_GearFrame:IsVisible() then GS_DatabaseFrame.tooltip:Show(); end
 	--GearScore_Send(Name, "ALL")
	if not ( Auto ) then GearScore_Request(Name); end
	local Textures = {}
--	if ( Race == "Orc" ) then Scale = 0.8; end
    GS_EditBox1:SetText(Name)
	GS_DisplayFrame:Show()
	GS_Model:SetModelScale(1)
    GS_Model:SetCamera(1)
	GS_Model:SetLight(1, 0, 0, -0.707, -0.707, 0.7, 1.0, 1.0, 1.0, 0.8, 1.0, 1.0, 0.8)
	if UnitToken and UnitExists(UnitToken) then GS_Model:SetUnit(UnitToken); else GS_Model:SetUnit("player"); end
	GS_Model:Undress()
 	GS_Model:EnableMouse(0)
    GS_Model:SetPosition(0,0,0)
	for i = 1, 18 do
		if ( i ~= 4 ) and _G["GS_Frame"..i] then
			_G["GS_Frame"..i]:SetParent(GS_GearFrame)
			_G["GS_Frame"..i]:SetToplevel(true)
			_G["GS_Frame"..i]:EnableMouse(true)
			_G["GS_Frame"..i]:SetFrameStrata("HIGH")
			_G["GS_Frame"..i]:SetFrameLevel(40)
			_G["GS_Frame"..i]:Raise()
		end
	end

	if GearScore_ShouldWaitForServerRecord(Name, UnitToken) then
		GS_InfoText:SetText("")
		GS_NameText:SetText(Name)
		GS_GuildText:SetText("")
		GS_DateText:SetText("")
		GS_AverageText:SetText("")
		GS_LocationText:SetText("")
		GS_GearScoreText:SetText("Очікування даних...")
		GearScore_StartProfileNotFoundTimer(Name)
		GearScore_SetDisplayStats(Name, UnitToken)
		local backdrop = {}
		for i = 1, 18 do if ( i ~=4 ) then backdrop = { bgFile = GS_TextureFiles[i] }; _G["GS_Frame"..i]:SetBackdrop(backdrop); end; end
	elseif ( GS_Data[GetRealmName()].Players[Name] ) then
		local Record = GS_Data[GetRealmName()].Players[Name]
		if Record.Scanned == "Server" and (not Record.GearScore or Record.GearScore <= 0) and Record.Equip then
			if GearScore_BuildRecordFromItemCodes(Name, UnitToken, Record.Equip, "Server", true, Record.Stats) then
				Record = GS_Data[GetRealmName()].Players[Name]
			end
		end
		local DisplayRace = GearScore_GetRecordDisplayRace(Record)
		local DisplayClass = GearScore_GetRecordDisplayClass(Record)
		local ClassRed, ClassGreen, ClassBlue = GearScore_GetRecordClassColors(Record)
	    for i = 1, 18 do
	    	if ( i ~= 4 ) then
	            local ItemName, ItemLink, ItemRarity, ItemLevel, ItemMinLevel, ItemType, ItemSubType, ItemStackCount, ItemEquipLoc, ItemTexture = GetItemInfo("item:"..Record.Equip[i])
				local backdrop = {}
				if ( ItemLink ) then GS_Model:TryOn(ItemLink); end
	    		if ( ItemTexture ) then backdrop = { bgFile = ItemTexture }; _G["GS_Frame"..i]:SetBackdrop(backdrop); else backdrop = { bgFile = GS_TextureFiles[i] }; _G["GS_Frame"..i]:SetBackdrop(backdrop);end
			end
		end
	    GS_InfoText:SetText((Record.Level or "").." "..DisplayRace.." "..DisplayClass)
	    GS_InfoText:SetTextColor(ClassRed, ClassGreen, ClassBlue, 1)
		GS_NameText:SetText(Record.Name or Name)
	    GS_NameText:SetTextColor(ClassRed, ClassGreen, ClassBlue, 1)
		Red, Green, Blue = GearScore_GetQuality(Record.GearScore)
		GS_GearScoreText:SetText("GearScore: "..(Record.GearScore or "немає запису"))
		GS_GearScoreText:SetTextColor(Red,Blue,Green)
		GS_GuildText:SetTextColor(ClassRed, ClassGreen, ClassBlue, 1)
		GS_GuildText:SetText(Record.Guild or "")
		local Date, DateRed, DateGreen, DateBlue = GearScore_GetDate(Record.Date)
		ColorStringDate = "|cff"..string.format("%02x%02x%02x", DateRed * 255, DateGreen * 255, DateBlue * 255) 
		local MyDateText = Date.." дн. тому"; if ( tonumber(Date) == 0 ) then MyDateText = "Сьогодні"; end
		GS_DateText:SetText("Скановано "..ColorStringDate..MyDateText.."|r, ким: "..(Record.Scanned or "невідомо"))
		GS_AverageText:SetText("Сер. рівень речей:|cFFFFFFFF "..(Record.Average or "-"))
		GS_LocationText:SetText(GS_Zones[Record.Location] or Record.Location or "")
		GearScore_SetDisplayStats(Name, UnitToken)
	else
		GS_InfoText:SetText("")
		GS_NameText:SetText(Name)
		GS_GuildText:SetText("")
		GS_DateText:SetText("")
		GS_AverageText:SetText("")
		GS_LocationText:SetText("")
		GS_GearScoreText:SetText("Немає запису")
		GearScore_SetDisplayStats(Name, UnitToken)
		local backdrop = {}
		for i = 1, 18 do if ( i ~=4 ) then backdrop = { bgFile = GS_TextureFiles[i] }; _G["GS_Frame"..i]:SetBackdrop(backdrop); end; end
		--GS_Slot1:Hide(); GS_Slot2:Hide(); GS_Slot3:Hide(); GS_Slot5:Hide(); GS_Slot6:Hide(); GS_Slot7:Hide(); GS_Slot8:Hide(); GS_Slot9:Hide(); GS_Slot10:Hide(); GS_Slot11:Hide(); GS_Slot12:Hide(); GS_Slot13:Hide(); GS_Slot14:Hide(); GS_Slot15:Hide(); GS_Slot16:Hide(); GS_Slot17:Hide(); GS_Slot18:Hide()
	end


 	GS_EditBox1:SetAutoFocus(0)
 end

function GearScore_ShowOptions()
	GS_OptionalDisplayed = 	GS_Displayed
	GS_Displayed = nil
	if ( GS_Settings["Restrict"] == 1 ) then GS_None:SetChecked(true); GS_Light:SetChecked(false); GS_Heavy:SetChecked(false); end
	if ( GS_Settings["Restrict"] == 2 ) then GS_Light:SetChecked(true); GS_None:SetChecked(false); GS_Heavy:SetChecked(false);end
	if ( GS_Settings["Restrict"] == 3 ) then GS_Heavy:SetChecked(true); GS_Light:SetChecked(false); GS_None:SetChecked(false);end
	if ( GS_Settings["Player"] == 1 ) then GS_ShowPlayerCheck:SetChecked(true); else GS_ShowPlayerCheck:SetChecked(false); end
	if ( GS_Settings["Item"] == 1 ) then GS_ShowItemCheck:SetChecked(true); else GS_ShowItemCheck:SetChecked(false); end
	if ( GS_Settings["Detail"] == 1 ) then GS_DetailCheck:SetChecked(true); else GS_DetailCheck:SetChecked(false); end
	if ( GS_Settings["Level"] == 1 ) then GS_LevelCheck:SetChecked(true); else GS_LevelCheck:SetChecked(false); end
	if ( GS_Settings["Date2"] == 1 ) then GS_DateCheck:SetChecked(true); else GS_DateCheck:SetChecked(false); end
	if ( GS_Settings["AutoPrune"] == 1 ) then GS_PruneCheck:SetChecked(true); else GS_PruneCheck:SetChecked(false); end	
	if ( GS_Settings["ShowHelp"] == 1 ) then GS_HelpCheck:SetChecked(true); else GS_HelpCheck:SetChecked(false); end
	if ( GS_Settings["KeepFaction"] == 1 ) then GS_FactionCheck:SetChecked(true); else GS_FactionCheck:SetChecked(false); end
	if ( GS_Settings["ML"] == 1 ) then GS_MasterlootCheck:SetChecked(true); else GS_MasterlootCheck:SetChecked(false); end
	if ( GS_Settings["CHAT"] == 1 ) then GS_ChatCheck:SetChecked(true); else GS_ChatCheck:SetChecked(false); end
	GS_DatabaseAgeSliderText:SetText("Зберігати дані: "..(GS_Settings["DatabaseAgeSlider"] or 30).." дн.")
	GS_DatabaseAgeSlider:SetValue(GS_Settings["DatabaseAgeSlider"] or 30)
	GS_LevelEditBox:SetText(GS_Settings["MinLevel"])
	--Set SpecScore Options--
	local class, englishClass = UnitClass("player")
	for i = 1,4 do _G["GS_SpecFontString"..i]:Hide(); _G["GS_SpecScoreCheck"..i]:Hide(); end
    for i, v in ipairs(GearScoreClassSpecList[englishClass]) do
    _G["GS_SpecFontString"..i]:SetText("Показувати SpecScore: "..GearScoreClassSpecList[englishClass][i])
   		_G["GS_SpecScoreCheck"..i]:SetText(GearScoreClassSpecList[englishClass][i])
   		_G["GS_SpecFontString"..i]:Show(); _G["GS_SpecScoreCheck"..i]:Show()
    	if not ( GS_Settings["ShowSpecScores"] ) then GS_Settings["ShowSpecScores"] = {}; end
    	if not ( GS_Settings["ShowSpecScores"][GearScoreClassSpecList[englishClass][i]] ) then GS_Settings["ShowSpecScores"][GearScoreClassSpecList[englishClass][i]] = 1; end
    	if ( GS_Settings["ShowSpecScores"][GearScoreClassSpecList[englishClass][i]] == 1 ) then _G["GS_SpecScoreCheck"..i]:SetChecked(1); else _G["GS_SpecScoreCheck"..i]:SetChecked(0); end
    end
	
	GS_Displayed = 1; GS_OptionsFrame:Show(); GS_GearFrame:Hide()
end 
 
function GearScore_HideOptions()
	if ( GS_ShowItemCheck:GetChecked() ) then GS_Settings["Item"] = 1; else GS_Settings["Item"] = -1; end
	if ( GS_None:GetChecked() ) then GearScore_SetNone(); end												
	if ( GS_Light:GetChecked() ) then GearScore_SetLight(); end												
	if ( GS_Heavy:GetChecked() ) then GearScore_SetHeavy(); end	
	if ( GS_HelpCheck:GetChecked() ) then GS_Settings["ShowHelp"] = 1; else GS_Settings["ShowHelp"] = -1; end
	if ( GS_ShowPlayerCheck:GetChecked() ) then GS_Settings["Player"] = 1; else GS_Settings["Player"] = -1; end											
	if ( GS_DetailCheck:GetChecked() ) then GS_Settings["Detail"] = 1; else GS_Settings["Detail"] = -1; end											
	if ( GS_LevelCheck:GetChecked() ) then GS_Settings["Level"] = 1; else GS_Settings["Level"] = -1; end	
	if ( GS_ChatCheck:GetChecked() ) then GS_Settings["CHAT"] = 1; else GS_Settings["CHAT"] = -1; end
	if ( GS_ShowItemCheck:GetChecked() ) then GS_Settings["Item"] = 1; else GS_Settings["Item"] = -1; end
	if ( GS_DateCheck:GetChecked() ) then GS_Settings["Date2"] = 1; else GS_Settings["Date2"] = -1; end
	if ( GS_PruneCheck:GetChecked() ) then GS_Settings["AutoPrune"] = 1; else GS_Settings["AutoPrune"] = -1; end		
	if ( GS_FactionCheck:GetChecked() ) then GS_Settings["KeepFaction"] = 1; else GS_Settings["KeepFaction"] = -1; end
	if ( GS_MasterlootCheck:GetChecked() ) then GS_Settings["ML"] = 1; else GS_Settings["ML"] = -1; end
	GS_Settings["MinLevel"] = tonumber(GS_LevelEditBox:GetText());
	GS_Settings["DatabaseAgeSlider"] = ( GS_DatabaseAgeSlider:GetValue() or 30 )
	GS_OptionsFrame:Hide()		
	if (GS_Displayed) then GearScore_DisplayUnit(GS_DisplayPlayer); end
	GS_Displayed = nil
	
	--Update Settings for new SpecScore Options--
	local class, englishClass = UnitClass("player")
	for i, v in ipairs(GearScoreClassSpecList[englishClass]) do
		if ( _G["GS_SpecScoreCheck"..i]:GetChecked() ) then GS_Settings["ShowSpecScores"][GearScoreClassSpecList[englishClass][i]] = 1; else GS_Settings["ShowSpecScores"][GearScoreClassSpecList[englishClass][i]] = 0; end
	end
	
	
end
 

function GearScore_SetHeavy()
	GS_Settings["Restrict"] = 3
	GS_ClassInfo["Warrior"].Equip["Cloth"] = nil
	GS_ClassInfo["Warrior"].Equip["Mail"] = nil
	GS_ClassInfo["Warrior"].Equip["Leather"] = nil
	GS_ClassInfo["Paladin"].Equip["Cloth"] = nil
	GS_ClassInfo["Paladin"].Equip["Mail"] = nil
	GS_ClassInfo["Paladin"].Equip["Leather"] = nil
	GS_ClassInfo["Death Knight"].Equip["Cloth"] = nil
	GS_ClassInfo["Death Knight"].Equip["Mail"] = nil
	GS_ClassInfo["Death Knight"].Equip["Leather"] = nil
	GS_ClassInfo["Hunter"].Equip["Cloth"] = nil
	GS_ClassInfo["Hunter"].Equip["Leather"] = nil
	GS_ClassInfo["Shaman"].Equip["Cloth"] = nil
	GS_ClassInfo["Shaman"].Equip["Leather"] = nil
	GS_ClassInfo["Rogue"].Equip["Cloth"] = nil
	GS_ClassInfo["Druid"].Equip["Cloth"] = nil
end

function GearScore_SetLight()
	GS_Settings["Restrict"] = 2
	GS_ClassInfo["Warrior"].Equip["Cloth"] = nil
	GS_ClassInfo["Warrior"].Equip["Mail"] = nil
	GS_ClassInfo["Warrior"].Equip["Leather"] = nil
	GS_ClassInfo["Paladin"].Equip["Cloth"] = 1
	GS_ClassInfo["Paladin"].Equip["Mail"] = 1
	GS_ClassInfo["Paladin"].Equip["Leather"] = 1
	GS_ClassInfo["Death Knight"].Equip["Cloth"] = nil
	GS_ClassInfo["Death Knight"].Equip["Mail"] = nil
	GS_ClassInfo["Death Knight"].Equip["Leather"] = nil
	GS_ClassInfo["Hunter"].Equip["Cloth"] = nil
	GS_ClassInfo["Hunter"].Equip["Leather"] = 1
	GS_ClassInfo["Shaman"].Equip["Cloth"] = 1
	GS_ClassInfo["Shaman"].Equip["Leather"] = 1
	GS_ClassInfo["Rogue"].Equip["Cloth"] = nil
	GS_ClassInfo["Druid"].Equip["Cloth"] = 1
end

function GearScore_SetNone()
	GS_Settings["Restrict"] = 1
	GS_ClassInfo["Warrior"].Equip["Cloth"] = 1
	GS_ClassInfo["Warrior"].Equip["Mail"] = 1
	GS_ClassInfo["Warrior"].Equip["Leather"] = 1
	GS_ClassInfo["Paladin"].Equip["Cloth"] = 1
	GS_ClassInfo["Paladin"].Equip["Mail"] = 1
	GS_ClassInfo["Paladin"].Equip["Leather"] = 1
	GS_ClassInfo["Death Knight"].Equip["Cloth"] = 1
	GS_ClassInfo["Death Knight"].Equip["Mail"] = 1
	GS_ClassInfo["Death Knight"].Equip["Leather"] = 1
	GS_ClassInfo["Hunter"].Equip["Cloth"] = 1
	GS_ClassInfo["Hunter"].Equip["Leather"] = 1
	GS_ClassInfo["Shaman"].Equip["Cloth"] = 1
	GS_ClassInfo["Shaman"].Equip["Leather"] = 1
	GS_ClassInfo["Rogue"].Equip["Cloth"] = 1
	GS_ClassInfo["Druid"].Equip["Cloth"] = 1
end

function GearScore_DisplayDatabase(Group, SortType, Auto, GSX_StartPage)
	--GS_HighlightedColNum = 1
	if not ( Group ) then Group = "Party"; end
	if GS_DisplayedGroup and GS_DisplayedGroup ~= Group then
		GSX_DataBase = nil
	end
	if Group ~= "Search" then GS_LastDatabaseGroup = Group; end
	GS_StartPage = GSX_StartPage
	if not ( GS_StartPage ) or ( GS_StartPage < 0 ) then GS_StartPage = 0; end
	
	GS_DisplayedGroup = Group; GS_DisplayFrame:Hide(); 	GS_DatabaseFrame:Show(); GS_DatabaseDisplayed =  1 
	if not ( SortType ) then SortType = "GearScore"; end
	GS_SortedType = SortType
	LibQTip:Release(GS_DatabaseFrame.tooltip)
   	GS_DatabaseFrame.tooltip = nil
	local tooltip = LibQTip:Acquire("GearScoreTooltip", 10, "CENTER", "CENTER", "CENTER", "CENTER", "CENTER", "CENTER", "CENTER", "CENTER", "CENTER", "CENTER")
	tooltip:SetCallback("OnMouseUp", GearScore_DatabaseOnClick)
	GS_DatabaseFrame.tooltip = tooltip 
	
--	GS_DatabaseFrame.tooltip:SetCell(lineNum, GS_HighlightedColNum, value[, font][, justification][, colSpan][, provider][, left][, rightPadding][, maxWidth, ...][, minWidth])

	tooltip:SetPoint("TOPLEFT", GS_DatabaseFrame, 10, -10)
				--tooltip:SetFrameStrata("LOW");
	tooltip:SetPoint("TOPRIGHT", GS_DatabaseFrame, -10, 0)
			--tooltip:SetPoint("BOTTOMLEFT", GS_DatabaseFrame, 0, 40)
    tooltip:SetFrameStrata("DIALOG")
	tooltip:SetHeight(420)
	tooltip:SetAlpha(100)
	tooltip:SetScale(1)
	tooltip:AddLine('#', 'GearScore', "Ім'я", "Ілвл", 'Рівень', 'Раса', 'Клас', 'Гільдія', 'Днів', 'Ким'); tooltip:AddSeparator(1, 1, 1, 1)
	tooltip:SetColumnLayout(10, "CENTER", "CENTER", "LEFT", "CENTER", "CENTER", "LEFT", "LEFT", "CENTER", "CENTER", "LEFT") 


	local count = 1; local ColorString1 = ""; local ColorString2 = ""; local gsfunc = ""; local PartySize = 0; local GroupType = ""; local FactionColor = nil
	if not ( GSX_DataBase ) then GSX_DataBase = {}; GSX_DataBase = GearScore_BuildDatabase(Group); Auto = 0; end
	
	if not ( GS_SortDirection ) then GS_SortDirection = {}; end
	if ( Auto ~= 1 ) then 
		if ( GS_SortDirection[SortType] ) then GS_SortDirection[SortType] = GS_SortDirection[SortType] * -1; else GS_SortDirection[SortType] = 1; end
		if ( SortType == "Name" ) then GS_HighlightedColNum = 3; if ( GS_SortDirection[SortType] == 1 ) then table.sort(GSX_DataBase, function(a, b) return a.Name < b.Name end); else table.sort(GSX_DataBase, function(a, b) return a.Name > b.Name end); end; end
		if ( SortType == "GearScore" ) then GS_HighlightedColNum = 2; if ( GS_SortDirection[SortType] == 1 ) then table.sort(GSX_DataBase, function(a, b) return a.GearScore > b.GearScore end); else table.sort(GSX_DataBase, function(a, b) return a.GearScore < b.GearScore end); end; end
		if ( SortType == "iLevel" ) then GS_HighlightedColNum = 4; if ( GS_SortDirection[SortType] == 1 ) then table.sort(GSX_DataBase, function(a, b) return a.Average > b.Average end); else table.sort(GSX_DataBase, function(a, b) return a.Average < b.Average end); end; end
		if ( SortType == "Level" ) then GS_HighlightedColNum = 5; if ( GS_SortDirection[SortType] == 1 ) then table.sort(GSX_DataBase, function(a, b) return tonumber(a.Level) > tonumber(b.Level) end); else table.sort(GSX_DataBase, function(a, b) return tonumber(a.Level) < tonumber(b.Level) end); end; end
		if ( SortType == "Guild" ) then GS_HighlightedColNum = 8; if ( GS_SortDirection[SortType] == 1 ) then table.sort(GSX_DataBase, function(a, b) return GearScore_GetSortableGuild(a) < GearScore_GetSortableGuild(b) end); else table.sort(GSX_DataBase, function(a, b) return GearScore_GetSortableGuild(a) > GearScore_GetSortableGuild(b) end); end; end
		if ( SortType == "Class" ) then GS_HighlightedColNum = 7; if ( GS_SortDirection[SortType] == 1 ) then table.sort(GSX_DataBase, function(a, b) return GearScore_GetSortableClass(a) < GearScore_GetSortableClass(b) end); else table.sort(GSX_DataBase, function(a, b) return GearScore_GetSortableClass(a) > GearScore_GetSortableClass(b) end); end; end
		if ( SortType == "Date" ) then GS_HighlightedColNum = 9; if ( GS_SortDirection[SortType] == 1 ) then table.sort(GSX_DataBase, function(a, b) return a.Date > b.Date end); else table.sort(GSX_DataBase, function(a, b) return a.Date < b.Date end); end; end
		if ( SortType == "Race" ) then GS_HighlightedColNum = 6; if ( GS_SortDirection[SortType] == 1 ) then table.sort(GSX_DataBase, function(a, b) return GearScore_GetSortableRace(a) < GearScore_GetSortableRace(b) end); else table.sort(GSX_DataBase, function(a, b) return GearScore_GetSortableRace(a) > GearScore_GetSortableRace(b) end); end; end
		if ( SortType == "Scanned" ) then GS_HighlightedColNum = 10; if ( GS_SortDirection[SortType] == 1 ) then table.sort(GSX_DataBase, function(a, b) return a.Scanned < b.Scanned end); else table.sort(GSX_DataBase, function(a, b) return a.Scanned > b.Scanned end); end; end
	end		
	if ( GS_StartPage > (#(GSX_DataBase))) then GS_StartPage = GS_StartPage - 25; end
	local Recount = GS_StartPage
	for i,v in pairs(GSX_DataBase) do
	if ( i > GS_StartPage ) then
		local Red, Green, Blue = GearScore_GetQuality(v.GearScore) 
		local DisplayRace = GearScore_GetRecordDisplayRace(v)
		local DisplayClass = GearScore_GetRecordDisplayClass(v)
		local DisplayGuild = GearScore_GetRecordGuild(v)
		local ClassRed, ClassGreen, ClassBlue = GearScore_GetRecordClassColors(v)
	
    	--if ( Red ) and ( Green ) and ( Blue ) then
    		Recount = Recount + 1
    		if ( v.Faction == "H" ) then FactionColor = "|cff"..string.format("%02x%02x%02x", 1 * 255, 0 * 255, 0 * 255); else  FactionColor = "|cff"..string.format("%02x%02x%02x", 0 , 162, 255); end   
  			ColorString1 = "|cff"..string.format("%02x%02x%02x", ClassRed * 255, ClassGreen * 255, ClassBlue * 255)
  			local NowDate, NoWRed, NowGreen, NowBlue = GearScore_GetDate(v.Date) 
--  			print(NowDate, NoWRed, NowGreen, NowBlue)
			ColorStringDate = "|cff"..string.format("%02x%02x%02x", NoWRed * 255, NowGreen * 255, NowBlue * 255) 
--			ColorStringDate..NowDate
			local Red, Green, Blue = GearScore_GetQuality(v.GearScore) 
			ColorString2 = "|cff"..string.format("%02x%02x%02x", Red * 255, Blue * 255, Green * 255)
    	   	tooltip:AddLine(Recount, ColorString2..(v.GearScore or 0), ColorString1..(v.Name or ""), (v.Average or 0), ColorString1..(v.Level or ""), ColorString1..DisplayRace, ColorString1..DisplayClass, FactionColor..(DisplayGuild ~= "" and ("<"..DisplayGuild..">") or ""), ColorStringDate..NowDate, (v.Scanned or ""))
    	   	if ( i >= ( GS_StartPage + 25 ) ) then break; end
       	--else
		  -- print(v.Name, "doesn't have a GearScore!") 
	end
	end
	local SubRecount = ((Recount - (floor(Recount/25) * 25) ))
	if SubRecount == 0 then SubRecount = 25; end
	
	
	for i = count + SubRecount, 25 do 
		if ( i >= 26 ) then break; end
		tooltip:AddLine("    ", "                        ", "   ", "  ", "       ", "            ", "          "); 
	end
	tooltip:Show()
	--tooltip:SetColumnColor(GS_HighlightedColNum, 1, 1, 1, .5);
	tooltip:SetBackdropColor(.1,.1,.2,1)
end

function GearScore_SetSortingColor(ColNum, AlphaDirection, tooltip)

end

function GearScore_HideDatabase(erase)
	LibQTip.OnLeave()
    --GearScoreTooltip:ClearLines()
	local keepreport = nil
	if ( GS_ReportFrame:IsVisible() ) then keepreport = 1; end
   	--LibQTip:ReleaseAllCallbacks(GS_DatabaseFrame.tooltip)
    LibQTip:Release(GS_DatabaseFrame.tooltip)
   	GS_DatabaseFrame.tooltip = nil
   	GS_SortDirection = nil
   	GS_DatabaseFrame:Hide()
   	GS_ReportFrame:Hide()
	
	if ( keepreport == 1 ) then GS_ReportFrame:Show(); end
	if not (erase) then GS_DatabaseDisplayed =  nil; GSX_DataBase = nil; end
   
 end
 
 function GearScore_BuildDatabase(Group, Auto)
 	--print("Compiling Database")
 	local count = 1; local GSL_DataBase = {}
 	if ( Group == "Party" ) then 
	    if ( UnitName("raid1") ) then GroupType = "raid"; PartySize = 40; else GroupType = "party"; PartySize = 5; end
	    count = 0; for i = 1, PartySize do 
			if ( GS_Data[GetRealmName()].Players[UnitName(GroupType..i)] ) then 
				count = count + 1; GSL_DataBase[count] = GS_Data[GetRealmName()].Players[UnitName(GroupType..i)]; 
			else
				--GearScore_Request(UnitName(GroupType..i))
			end; 
		end
		if ( GroupType == "party" ) then GSL_DataBase[count+1] = GS_Data[GetRealmName()].Players[UnitName("player")]; end
	end
	if ( Group == "All" ) then count = 0;
		for i,v in pairs(GS_Data[GetRealmName()].Players) do
            if ( GS_Settings["AutoPrune"] == 1 ) then
				if ( GearScore_GetDate(v.Date) > (GS_Settings["DatabaseAgeSlider"] or 30 ) ) then
				    GS_Data[GetRealmName()].Players[i] = nil
				else
                    count = count+1; GSL_DataBase[count] = v;
				end
			else
			count = count+1; GSL_DataBase[count] = v;
			end
		end;
	end

	if ( Group == "Guild" ) then
		count = 0
		local PlayerGuild = GetGuildInfo("player")
		if PlayerGuild then
			GuildRoster()
			local RosterNames = {}
			for i = 1, GetNumGuildMembers(1) do
				local RosterName = GearScore_NormalizeRosterName(GetGuildRosterInfo(i))
				if RosterName then RosterNames[RosterName] = 1; end
			end
			for Name, Record in pairs(GS_Data[GetRealmName()].Players) do
				if RosterNames[Name] or (GearScore_NormalizeRosterName(Record.Name) and RosterNames[GearScore_NormalizeRosterName(Record.Name)]) or GearScore_SameGuildName(Record.Guild, PlayerGuild) then
					count = count + 1
					GSL_DataBase[count] = Record
				end
			end
		end
	end
	if ( Group == "Search" ) then
		count = 0
		local Query = GS_SearchXBox and GS_SearchXBox:GetText() or ""
		Query = string.gsub(Query or "", "^%s+", "")
		Query = string.gsub(Query, "%s+$", "")
		if Query ~= "" then
			for i,v in pairs(GS_Data[GetRealmName()].Players) do
				local DataString = tostring((v.GearScore or 0)..(v.Name or "")..(v.Level or "")..GearScore_GetRecordGuild(v)..GearScore_GetRecordDisplayClass(v)..GearScore_GetRecordDisplayRace(v))
				if string.find(strlower(DataString), strlower(Query), 1, true) then count = count + 1; GSL_DataBase[count] = v; end
			end
		end
	end
    if ( Group == "Friends" ) then count = 0; for i = 1, GetNumFriends(1) do local FriendName = GearScore_NormalizeRosterName(GetFriendInfo(i)); if FriendName and GS_Data[GetRealmName()].Players[FriendName] then count = count + 1; GSL_DataBase[count] = GS_Data[GetRealmName()].Players[FriendName]; end; end; end
	
	if Group == "All" then GSDatabaseInfoString:SetText("База: "..count.." записів. (прибл. "..floor(0.8372131704586988304093567251462 * count).." КБ)"); GS_Settings["DatabaseSize"] = count;
	else if GS_Settings["DatabaseSize"] then GSDatabaseInfoString:SetText("База: "..GS_Settings["DatabaseSize"].." записів. (прибл. "..floor(0.8372131704586988304093567251462 * GS_Settings["DatabaseSize"]).." КБ)"); end
	end
	return GSL_DataBase
end

 function GearScore_ShowReport()
 	GS_ReportFrame:Show()
 	GS_SliderText:SetText("Топ: "..GS_Settings["Slider"])
 	GS_Slider:SetValue(GS_Settings["Slider"])
 end
 
 function GearScore_SendReport(Manual, G_Target, G_Who, G_Direction)
 	local Target = ""; local Who = ""; local Direction = ""; local Extra = ""
 	if ( GSXSayCheck:GetChecked() ) then Target = "SAY"; end
 	if ( GSXPartyCheck:GetChecked() ) then Target = "PARTY"; end
 	if ( GSXRaidCheck:GetChecked() ) then Target = "RAID"; end
 	if ( GSXGuildCheck:GetChecked() ) then Target = "GUILD"; end
 	if ( GSXOfficerCheck:GetChecked() ) then Target = "OFFICER"; end
	if ( GSXWhisperCheck:GetChecked() ) then Target = "WHISPER"; Who = GSX_WhisperEditBox:GetText(); end 	
	if ( GSXWhisperTargetCheck:GetChecked() ) then Target = "WHISPER"; Who = UnitName("target"); end 	
	if ( GSXChannelCheck:GetChecked() ) then Target = "CHANNEL"; Who = GSX_ChannelEditBox:GetText(); end 


	if ( Target == "" ) then print("Please check the box for where you would like the report to go."); return; end
	if not ( Who ) then return; end	
	if ( GS_SortDirection[GS_SortedType] == 1 ) then Direction = "Top"; else Direction = "Bottom"; end
	if ( GS_DisplayedGroup == "Search" ) then Extra = "'"..GS_SearchXBox:GetText().."'"; else Extra = GS_DisplayedGroup; end
	if ( GS_DisplayedGroup == "All" ) then Extra = "Entire Database"; end
	if ( Manual ) then Target = G_Target; Who = G_Who; Direction = "Top"; Extra = "GearScore"; end

	SendChatMessage(Direction.." ".." GearScore Reports for "..Extra.." sorted by "..GS_SortedType..".", Target, nil, Who);


	for i,v in ipairs(GSX_DataBase) do
		local DaysOld = GearScore_GetDate(v.Date)
		SendChatMessage("#"..i..".  "..v.GearScore.."    (iLevel "..v.Average..")     "..v.Name, Target, nil, Who)
	--	SendChatMessage("#"..i.." "..v.Name.."   "..v.GearScore.."  ("..v.Average..")   "..v.Level.." "..GS_Races[v.Race].." "..GS_Classes[v.Class], Target, nil, Who)
		if ( i >= GS_Settings["Slider"] ) then break; end
	end
 end
 
 function GearScore_SendSpamReport(Target, Who, Database)
 	SendChatMessage("Top".." ".." GearScore Reports for ".."group".." sorted by ".."GearScore"..".", Target, nil, Who);
 	for i,v in ipairs(Database) do
 		local DaysOld = GearScore_GetDate(v.Date)
		SendChatMessage("#"..i..".  "..v.GearScore.."    (iLevel "..v.Average..")     "..v.Name, Target, nil, Who)
		--SendChatMessage("#"..i.." "..v.Name.."   "..v.GearScore.."  ("..v.Average..")   "..v.Level.." "..GS_Races[v.Race].." "..GS_Classes[v.Class], Target, nil, Who)
		if ( i >= 26 ) then break; end
	end
 end
 
--------------------------------SETUP-----------------------------------------

function GearScore_TextureOnEnter()
--print("OnEnter!")
end

function GearScore_DatabaseOnClick(Event, Cell, Misc, Button)
	--LibQTip:Release(GearScoreTooltip)
	if ( Button == "RightButton" ) and ( Cell["_line"] > 2 ) and ( Cell["_column"] == 3 ) and ( GSX_DataBase[Cell["_line"]-2+GS_StartPage] )	then ChatFrameEditBox:Show(); ChatFrameEditBox:Insert("/t "..GSX_DataBase[Cell["_line"]-2+GS_StartPage].Name.." "); return; end
	
	if ( Cell["_line"] == 1 ) and ( Cell["_column"] == 2 ) then GearScore_DisplayDatabase(GS_DisplayedGroup, "GearScore", nil, GS_StartPage); return; end
	if ( Cell["_line"] == 1 ) and ( Cell["_column"] == 3 ) then GearScore_DisplayDatabase(GS_DisplayedGroup, "Name", nil, GS_StartPage); return; end
	if ( Cell["_line"] == 1 ) and ( Cell["_column"] == 4 ) then GearScore_DisplayDatabase(GS_DisplayedGroup, "iLevel", nil, GS_StartPage); return; end
	if ( Cell["_line"] == 1 ) and ( Cell["_column"] == 5 ) then GearScore_DisplayDatabase(GS_DisplayedGroup, "Level", nil, GS_StartPage); return; end
	if ( Cell["_line"] == 1 ) and ( Cell["_column"] == 6 ) then GearScore_DisplayDatabase(GS_DisplayedGroup, "Race", nil, GS_StartPage); return; end
	if ( Cell["_line"] == 1 ) and ( Cell["_column"] == 7 ) then GearScore_DisplayDatabase(GS_DisplayedGroup, "Class", nil, GS_StartPage); return; end
	if ( Cell["_line"] == 1 ) and ( Cell["_column"] == 8 ) then GearScore_DisplayDatabase(GS_DisplayedGroup, "Guild", nil, GS_StartPage); return; end
	if ( Cell["_line"] == 1 ) and ( Cell["_column"] == 9 ) then GearScore_DisplayDatabase(GS_DisplayedGroup, "Date", nil, GS_StartPage); return; end	
	if ( Cell["_line"] == 1 ) and ( Cell["_column"] == 10 ) then GearScore_DisplayDatabase(GS_DisplayedGroup, "Scanned", nil, GS_StartPage); return; end
	--print("pie", Cell["_line"], Cell["_column"]) 
	local LineCount = GS_DatabaseFrame.tooltip:GetLineCount(); if not ( LineCount ) then LineCount = 0; end
	--print(LineCount)
	if ( Cell["_line"] > 2 ) and ( Cell["_column"] == 3 ) and ( GSX_DataBase[Cell["_line"]-2] ) and ( Cell["_line"] ~= 28 ) then --GearScore_Send(GSX_DataBase[Cell["_line"]-2+GS_StartPage].Name, "ALL"); 
	GearScore_OpenProfile(GSX_DataBase[Cell["_line"]-2+GS_StartPage].Name); return; end
	if ( Cell["_line"] > 2 ) and ( Cell["_column"] == 6 ) and ( GSX_DataBase[Cell["_line"]-2] ) then GS_SearchXBox:SetText(GearScore_GetRecordDisplayRace(GSX_DataBase[Cell["_line"]-2+GS_StartPage])); GearScore_HideDatabase(); GearScore_DisplayDatabase("Search"); return; end
	if ( Cell["_line"] > 2 ) and ( Cell["_column"] == 7 ) and ( GSX_DataBase[Cell["_line"]-2] ) then GS_SearchXBox:SetText(GearScore_GetRecordDisplayClass(GSX_DataBase[Cell["_line"]-2+GS_StartPage])); GearScore_HideDatabase(); GearScore_DisplayDatabase("Search"); return; end
	if ( Cell["_line"] > 2 ) and ( Cell["_column"] == 8 ) and ( GSX_DataBase[Cell["_line"]-2] ) then GS_SearchXBox:SetText(GearScore_GetRecordGuild(GSX_DataBase[Cell["_line"]-2+GS_StartPage])); GearScore_HideDatabase(); GearScore_DisplayDatabase("Search"); return; end
--tooltip:AddHeader('#', 'GearScore', '  Name ', "iLevel", 'Level', '  Race   ', ' Class   ', 'Date'); tooltip:AddSeparator(1, 1, 1, 1)
end

function GearScore_Exchange(Type, Who)
 	if Type == "DATABASE" then
	    GS_ExchangeDatabase =  GearScore_BuildDatabase("All")
		GS_ExchangeName = Who
		GS_ExchangeCount = 1
		GearScore_ContinueExchange()
		print("GearScore Database Transmission In Progress")
    end
end

function GearScore_ContinueExchange()
 	for i = 1,5 do
 	if not GS_ExchangeCount then return; end
	if ( GS_ExchangeDatabase[GS_ExchangeCount] ) then
   			GearScore_Send(GS_ExchangeDatabase[GS_ExchangeCount].Name, "WHISPER", GS_ExchangeName)
			GS_ExchangeCount = GS_ExchangeCount + 1
		else
		print("GearScore Database Transmission complete!")
		GS_ExchangeCount = nil
		GS_ExchangeName = nil
		GS_ExchangeDatabase = nil
		GearScore_TimerFrame:Hide()
		end
	end
	GearScore_TimerFrame:Show()
end


if not GearScore_TimerFrame then GearScore_TimerFrame = CreateFrame("Frame") end

hooksecurefunc("SetItemRef",GearScoreSetItemRef)

GearScore_TimerFrame:Hide()
GearScore_TimerFrame:SetScript("OnUpdate", GearScore_OnUpdate)
local f = CreateFrame("Frame", "GearScore", UIParent);
f:SetScript("OnUpdate", GearScore_ThrottleUpdate)
f:SetScript("OnEvent", GearScore_OnEvent);
f:RegisterEvent("PLAYER_EQUIPMENT_CHANGED");
f:RegisterEvent("CHAT_MSG_ADDON");
f:RegisterEvent("PLAYER_TARGET_CHANGED")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_REGEN_ENABLED")
f:RegisterEvent("PLAYER_REGEN_DISABLED")
GameTooltip:HookScript("OnTooltipSetUnit", GearScore_HookSetUnit)
GameTooltip:HookScript("OnTooltipSetItem", GearScore_HookSetItem)
ShoppingTooltip1:HookScript("OnTooltipSetItem", GearScore_HookCompareItem)
ShoppingTooltip2:HookScript("OnTooltipSetItem", GearScore_HookCompareItem2)
PaperDollFrame:HookScript("OnShow", MyPaperDoll)
PaperDollFrame:CreateFontString("PersonalGearScore")
PersonalGearScore:SetFont("Fonts\\FRIZQT__.TTF", 10)
PersonalGearScore:SetText("GS: 0")
PersonalGearScore:SetPoint("BOTTOMLEFT",PaperDollFrame,"TOPLEFT",72,-253)
PersonalGearScore:Show()
PaperDollFrame:CreateFontString("GearScore2")
GearScore2:SetFont("Fonts\\FRIZQT__.TTF", 10)
GearScore2:SetText("GearScore")
GearScore2:SetPoint("BOTTOMLEFT",PaperDollFrame,"TOPLEFT",72,-265)
GearScore2:Show()
ItemRefTooltip:HookScript("OnTooltipSetItem", GearScore_HookRefItem)
GearScore_Original_SetInventoryItem = GameTooltip.SetInventoryItem
GameTooltip.SetInventoryItem = GearScore_OnEnter
SlashCmdList["MYSCRIPT"] = GS_SPAM
SLASH_MYSCRIPT1 = "/gspam";
SlashCmdList["MY2SCRIPT"] = GS_MANSET
SLASH_MY2SCRIPT1 = "/gset"
SLASH_MY2SCRIPT3 = "/gearscore"
SlashCmdList["MY3SCRIPT"] = GS_SCANSET
SLASH_MY3SCRIPT3 = "/gs"
SLASH_MY3SCRIPT1 = "/gscan"
SLASH_MY3SCRIPT2 = "/gsearch"
SlashCmdList["GSTSETDEBUG"] = GS_TmogSetDebugToggle
SLASH_GSTSETDEBUG1 = "/gstsetdebug"
SlashCmdList["GSTSETREFRESH"] = GS_TmogSetRefresh
SLASH_GSTSETREFRESH1 = "/gstsetrefresh"
SlashCmdList["MY4SCRIPT"] = GS_BANSET
SLASH_MY4SCRIPT1 = "/gsban"
GS_DisplayFrame:Hide()
LibQTip = LibStub("LibQTipClick-1.1")



